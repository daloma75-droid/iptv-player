package com.dani.iptvplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

/** Zoom suave al recibir el foco (mando de TV box). */
fun View.zoomOnFocus(scale: Float = 1.05f) {
    setOnFocusChangeListener { v, hasFocus ->
        val s = if (hasFocus) scale else 1f
        v.animate().scaleX(s).scaleY(s).setDuration(120).start()
    }
}

/**
 * Lista/rejilla de contenido. Con poster = true muestra carátulas (películas y series);
 * con poster = false muestra filas con logo (TV en directo y favoritos).
 */
class ChannelAdapter(
    private val poster: Boolean,
    private val cellWidthPx: Int,
    private val favorites: Set<String>,
    private val onClick: (Int) -> Unit,
    private val onLongClick: (Int) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    private var items: List<Channel> = emptyList()

    fun submit(list: List<Channel>) {
        items = list
        notifyDataSetChanged()
    }

    fun itemAt(position: Int): Channel = items[position]

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val group: TextView? = v.findViewById(R.id.group)
        val star: TextView = v.findViewById(R.id.star)
        val watched: TextView? = v.findViewById(R.id.watched)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (poster) R.layout.item_poster else R.layout.item_channel
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        v.zoomOnFocus(if (poster) 1.06f else 1.02f)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        holder.name.text = c.name
        holder.group?.text = c.group
        holder.star.visibility = if (c.key in favorites) View.VISIBLE else View.GONE
        holder.watched?.visibility = if (poster && Watched.isWatched(holder.itemView.context, c)) View.VISIBLE else View.GONE

        if (poster) {
            // Carátula con proporción 2:3 según el ancho de la celda
            val lp = holder.logo.layoutParams
            lp.height = ((cellWidthPx - dp(holder.itemView, 8)) * 3) / 2
            holder.logo.layoutParams = lp
            if (c.logo.isNotEmpty()) {
                holder.logo.load(c.logo) {
                    crossfade(true)
                    placeholder(R.drawable.poster_empty)
                    error(R.drawable.poster_empty)
                }
            } else {
                holder.logo.load(R.drawable.poster_empty)
            }
        } else {
            if (c.logo.isNotEmpty()) {
                holder.logo.load(c.logo) {
                    placeholder(R.drawable.ic_tv)
                    error(R.drawable.ic_tv)
                }
            } else {
                holder.logo.load(R.drawable.ic_tv)
            }
        }

        holder.itemView.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        holder.itemView.setOnLongClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(p)
            true
        }
    }

    private fun dp(v: View, n: Int): Int = (n * v.resources.displayMetrics.density).toInt()
}

/** Columna de categorías (izquierda). */
class CategoryAdapter(
    private val onClick: (String) -> Unit,
    private val onLongClick: (String) -> Unit = {},
    private val isLocked: (String) -> Boolean = { false }
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    private var names: List<String> = emptyList()
    private var counts: Map<String, Int> = emptyMap()
    private var selected = 0

    fun submit(list: List<String>, countMap: Map<String, Int>) {
        names = list
        counts = countMap
        selected = 0
        notifyDataSetChanged()
    }

    fun refresh() = notifyDataSetChanged()

    /** Selecciona una categoría por nombre. Devuelve su posición o -1 si no existe. */
    fun select(name: String): Int {
        val p = names.indexOf(name)
        if (p < 0) return -1
        val old = selected
        selected = p
        notifyItemChanged(old)
        notifyItemChanged(p)
        return p
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.catName)
        val count: TextView = v.findViewById(R.id.catCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false))

    override fun getItemCount(): Int = names.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val n = names[position]
        holder.name.text = if (isLocked(n)) "🔒 $n" else n
        holder.count.text = counts[n]?.toString().orEmpty()
        holder.itemView.isSelected = position == selected
        holder.itemView.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(names[p])
        }
        holder.itemView.setOnLongClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(names[p])
            true
        }
    }
}
