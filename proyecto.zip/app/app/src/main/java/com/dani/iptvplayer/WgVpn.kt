package com.dani.iptvplayer

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream

/**
 * VPN propia de la app con WireGuard. Se usa el archivo .conf que Proton VPN genera en la cuenta del
 * usuario. Como la VPN la crea la propia app, se conecta directamente, sin abrir la app de Proton.
 * (Android pide una única vez un permiso de VPN del sistema.)
 */
object WgVpn {
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "iptvplayer"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    private fun backend(ctx: Context): GoBackend {
        val b = backend ?: GoBackend(ctx.applicationContext)
        backend = b
        return b
    }

    private fun prefs(ctx: Context) = Repo.prefs(ctx)

    private fun parse(text: String): Config = Config.parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))

    /** true si el túnel WireGuard de esta app está conectado (no la VPN de otra app). */
    fun isUp(ctx: Context): Boolean = try {
        // Sin configuración ni túnel creado no hace falta cargar la librería nativa
        if (backend == null && !hasConfig(ctx)) false else backend(ctx).getState(tunnel) == Tunnel.State.UP
    } catch (e: Throwable) {
        false
    }

    fun hasConfig(ctx: Context): Boolean = !prefs(ctx).getString("wg_conf", "").isNullOrBlank()

    /** Preguntar «¿Activar la VPN?» al abrir la app. */
    fun askAtStart(ctx: Context): Boolean = prefs(ctx).getBoolean("wg_ask", true)

    fun setAskAtStart(ctx: Context, value: Boolean) {
        prefs(ctx).edit().putBoolean("wg_ask", value).apply()
    }

    /** Valida y guarda la configuración. Devuelve null si va bien, o el motivo del error. */
    fun saveConfig(ctx: Context, text: String): String? {
        // Los .conf.txt pueden traer una marca BOM al principio o saltos de línea de Windows
        val clean = text.removePrefix("\uFEFF").replace("\r\n", "\n").replace("\r", "\n").trim()
        if (clean.isEmpty()) return "La configuración está vacía"
        return try {
            parse(clean)
            prefs(ctx).edit().putString("wg_conf", clean).apply()
            null
        } catch (e: Throwable) {
            "No es una configuración WireGuard válida" + (e.message?.let { " ($it)" } ?: "")
        }
    }

    fun clear(ctx: Context) {
        prefs(ctx).edit().remove("wg_conf").apply()
    }

    /** Conecta la VPN. [cb] se llama desde un hilo secundario. Necesita el permiso de VPN ya concedido. */
    fun connect(ctx: Context, cb: (Boolean, String) -> Unit) {
        val text = prefs(ctx).getString("wg_conf", "").orEmpty()
        val app = ctx.applicationContext
        Thread {
            try {
                backend(app).setState(tunnel, Tunnel.State.UP, parse(text))
                cb(true, "")
            } catch (e: Throwable) {
                cb(false, e.message ?: e.javaClass.simpleName)
            }
        }.start()
    }

    fun disconnect(ctx: Context, cb: (Boolean, String) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            try {
                backend(app).setState(tunnel, Tunnel.State.DOWN, null)
                cb(true, "")
            } catch (e: Throwable) {
                cb(false, e.message ?: e.javaClass.simpleName)
            }
        }.start()
    }
}
