package com.dani.iptvplayer

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import java.io.File

/** Descargas: progreso, pausar/reanudar/borrar y reproducción sin conexión. */
class DownloadsActivity : AppCompatActivity() {

    private lateinit var adapter: DlAdapter
    private lateinit var info: TextView
    private lateinit var empty: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)
        info = findViewById(R.id.info)
        empty = findViewById(R.id.empty)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        adapter = DlAdapter(this, onClick = { d -> onItem(d) }, onLong = { d -> confirmDelete(d) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun order(d: Dl): Int = when (d.status) {
        Downloads.DOWNLOADING -> 0
        Downloads.QUEUED -> 1
        Downloads.PAUSED -> 2
        Downloads.ERROR -> 3
        else -> 4
    }

    private fun refresh() {
        // El control parental también afecta a lo descargado (ocultos, idiomas bloqueados, adultos…)
        val list = Downloads.all(this)
            .filter { Parental.allowed(this, Downloads.asOriginal(it)) }
            .sortedWith(compareBy<Dl>({ order(it) }, { it.title.lowercase() }))
        adapter.submit(list)
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE

        val used = list.sumOf { d -> val f = File(d.path); if (f.exists()) f.length() else 0L }
        val free = Downloads.dir(this).usableSpace
        info.text = "${list.size} descargas · ${Formatter.formatFileSize(this, used)} usados · " +
            "${Formatter.formatFileSize(this, free)} libres"
    }

    private fun onItem(d: Dl) {
        when (d.status) {
            Downloads.DONE -> play(d)
            Downloads.DOWNLOADING, Downloads.QUEUED -> {
                AlertDialog.Builder(this)
                    .setTitle(d.title)
                    .setItems(arrayOf("Pausar", "Cancelar y borrar")) { _, which ->
                        if (which == 0) Downloads.pause(this, d.id) else Downloads.cancel(this, d.id)
                        refresh()
                    }
                    .setNegativeButton("Cerrar", null)
                    .show()
            }
            else -> {
                val first = if (d.status == Downloads.ERROR) "Reintentar" else "Reanudar"
                AlertDialog.Builder(this)
                    .setTitle(d.title)
                    .setMessage(if (d.status == Downloads.ERROR) d.error else null)
                    .setItems(arrayOf(first, "Borrar")) { _, which ->
                        if (which == 0) {
                            if (Vpn.blocked(this)) {
                                Toast.makeText(this, "Conecta la VPN para descargar", Toast.LENGTH_LONG).show()
                            } else {
                                Downloads.resume(this, d.id)
                            }
                        } else {
                            Downloads.cancel(this, d.id)
                        }
                        refresh()
                    }
                    .setNegativeButton("Cerrar", null)
                    .show()
            }
        }
    }

    private fun confirmDelete(d: Dl) {
        AlertDialog.Builder(this)
            .setTitle("Borrar descarga")
            .setMessage(d.title)
            .setPositiveButton("Borrar") { _, _ ->
                Downloads.cancel(this, d.id)
                refresh()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun play(d: Dl) {
        if (!File(d.path).exists()) {
            Toast.makeText(this, "El archivo ya no existe", Toast.LENGTH_LONG).show()
            Downloads.removeNow(this, d.id)
            refresh()
            return
        }
        val done = adapter.items.filter { it.status == Downloads.DONE && File(it.path).exists() }
        Playlist.channels = done.map { Downloads.toChannel(it) }
        Playlist.index = done.indexOfFirst { it.id == d.id }.coerceAtLeast(0)
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}

private class DlAdapter(
    private val ctx: AppCompatActivity,
    private val onClick: (Dl) -> Unit,
    private val onLong: (Dl) -> Unit
) : RecyclerView.Adapter<DlAdapter.VH>() {

    var items: List<Dl> = emptyList()
        private set

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val state: TextView = v.findViewById(R.id.state)
        val bar: ProgressBar = v.findViewById(R.id.bar)
    }

    fun submit(list: List<Dl>) {
        val same = list.size == items.size && list.indices.all { list[it].id == items[it].id }
        items = list
        // Si no cambia el orden solo se refrescan los datos (así no se pierde el foco del mando)
        if (same) notifyItemRangeChanged(0, list.size) else notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_download, parent, false)
        v.zoomOnFocus(1.02f)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = items[position]
        holder.name.text = d.title
        if (d.logo.isNotEmpty()) {
            holder.logo.load(d.logo) {
                placeholder(R.drawable.poster_empty)
                error(R.drawable.poster_empty)
            }
        } else {
            holder.logo.setImageResource(R.drawable.ic_movie)
        }
        val pct = if (d.total > 0) (d.bytes * 100 / d.total).toInt() else 0
        val size = Formatter.formatFileSize(ctx, d.bytes)
        val totalText = if (d.total > 0) Formatter.formatFileSize(ctx, d.total) else "?"
        holder.state.text = when (d.status) {
            Downloads.DONE -> "Descargado · $size"
            Downloads.DOWNLOADING -> "Descargando · $pct% · $size de $totalText"
            Downloads.QUEUED -> "En cola"
            Downloads.PAUSED -> "En pausa · $pct%"
            else -> "Error: ${d.error.ifEmpty { "desconocido" }}"
        }
        holder.bar.visibility = if (d.status == Downloads.DONE) View.GONE else View.VISIBLE
        holder.bar.isIndeterminate = d.status == Downloads.DOWNLOADING && d.total <= 0
        holder.bar.progress = pct
        holder.itemView.setOnClickListener { onClick(d) }
        holder.itemView.setOnLongClickListener {
            onLong(d)
            true
        }
    }
}
