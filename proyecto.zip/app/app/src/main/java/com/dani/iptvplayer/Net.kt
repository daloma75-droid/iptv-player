package com.dani.iptvplayer

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import coil.imageLoader
import okhttp3.ConnectionPool
import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.io.IOException
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.TimeUnit

/**
 * Red compartida para carátulas, logotipos y TMDB.
 *
 * Con la VPN activa fallaban las portadas por tres motivos:
 *  1. Las conexiones guardadas en el pool eran de antes de la VPN y quedaban muertas.
 *  2. El DNS de la VPN a veces no resuelve o tarda (se prueba DNS sobre HTTPS como respaldo).
 *  3. Un fallo puntual no se reintentaba y la imagen se quedaba vacía para siempre.
 * Además, cuando la VPN se conecta o se desconecta se avisa a las pantallas para que vuelvan a pedir las imágenes.
 */
object Net {
    const val UA_BROWSER =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36"

    /** Sube cada vez que cambia la VPN (conexión o desconexión). */
    @Volatile
    var epoch = 0
        private set

    @Volatile
    private var lastVpn: Boolean? = null

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<Runnable>()
    private val fireListeners = Runnable { listeners.forEach { it.run() } }

    // ---------------------------------------------------------------- DNS con respaldo

    private val doh: Dns? by lazy {
        try {
            DnsOverHttps.Builder()
                .client(OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build())
                .url("https://cloudflare-dns.com/dns-query".toHttpUrl())
                .bootstrapDnsHosts(InetAddress.getByName("1.1.1.1"), InetAddress.getByName("1.0.0.1"))
                .includeIPv6(false)
                .build()
        } catch (e: Throwable) {
            null
        }
    }

    private val fallbackDns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            try {
                return Dns.SYSTEM.lookup(hostname)
            } catch (e: UnknownHostException) {
                val d = doh ?: throw e
                return try {
                    d.lookup(hostname)
                } catch (_: Exception) {
                    throw e
                }
            }
        }
    }

    // ---------------------------------------------------------------- Reintentos

    private val retry = Interceptor { chain ->
        var attempt = 0
        var last: IOException? = null
        while (attempt < 3) {
            try {
                return@Interceptor chain.proceed(chain.request())
            } catch (e: IOException) {
                last = e
                if (chain.call().isCanceled()) throw e
                attempt++
                try {
                    Thread.sleep(400L * attempt)
                } catch (_: InterruptedException) {
                    throw e
                }
            }
        }
        throw last ?: IOException("Sin respuesta")
    }

    /** Cliente base de la app para imágenes y TMDB. */
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .dns(fallbackDns)
        // Conexiones guardadas poco tiempo: así no se arrastran sockets de antes de la VPN
        .connectionPool(ConnectionPool(5, 45, TimeUnit.SECONDS))
        .addInterceptor(retry)
        .build()

    /** Cliente de Coil: igual que [http] pero con cabeceras de navegador. */
    val imageClient: OkHttpClient = http.newBuilder()
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder()
                    .header("User-Agent", UA_BROWSER)
                    .header("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
                    .build()
            )
        }
        .build()

    // ---------------------------------------------------------------- Cambios de red / VPN

    /** Las pantallas se registran para recargar las imágenes cuando cambia la VPN. */
    fun addListener(r: Runnable) { listeners.add(r) }
    fun removeListener(r: Runnable) { listeners.remove(r) }

    /** Tira las conexiones guardadas (están ligadas a la red anterior). */
    fun dropConnections() {
        try {
            http.connectionPool.evictAll()
        } catch (_: Throwable) {
        }
    }

    /** Llamar cuando se sospecha que la red cambió. Si la VPN cambió de estado avisa a las pantallas. */
    fun onNetworkChanged(vpnNow: Boolean) {
        dropConnections()
        val before = lastVpn
        lastVpn = vpnNow
        if (before != null && before != vpnNow) {
            epoch++
            main.removeCallbacks(fireListeners)
            main.postDelayed(fireListeners, 1200)
        }
    }

    /** Vigila la red desde que arranca la app. */
    fun watch(app: Context) {
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
            lastVpn = Vpn.isActive(app)
            // Por defecto una petición excluye las redes VPN; hay que quitar ese filtro
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()
            cm.registerNetworkCallback(req, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = onNetworkChanged(Vpn.isActive(app))
                override fun onLost(network: Network) = onNetworkChanged(Vpn.isActive(app))
            })
        } catch (_: Throwable) {
            // sin permiso o móvil raro: la app sigue funcionando, solo sin el aviso automático
        }
    }

    /** Vacía las carátulas guardadas (memoria y disco) y las búsquedas de TMDB para que se vuelvan a pedir. */
    fun clearImageCaches(ctx: Context) {
        try {
            val loader = ctx.applicationContext.imageLoader
            loader.memoryCache?.clear()
            loader.diskCache?.clear()
        } catch (_: Throwable) {
        }
        TmdbPosters.clearCache(ctx)
        dropConnections()
    }
}
