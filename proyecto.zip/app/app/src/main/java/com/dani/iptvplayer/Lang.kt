package com.dani.iptvplayer

import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Detecta el idioma de cada canal, película o serie. Las listas IPTV casi siempre lo indican en el
 * nombre de la categoría ("ES | PELÍCULAS", "[EN] Movies", "FR - Séries", "Latino") o en el propio
 * nombre ("|ES| La 1"). Si no hay forma de saberlo, el idioma es [UNKNOWN].
 */
object Lang {
    const val UNKNOWN = "??"

    val NAMES = mapOf(
        "es" to "Español", "en" to "Inglés", "fr" to "Francés", "de" to "Alemán", "it" to "Italiano",
        "pt" to "Portugués", "ar" to "Árabe", "tr" to "Turco", "nl" to "Neerlandés", "pl" to "Polaco",
        "ru" to "Ruso", "ro" to "Rumano", "el" to "Griego", "sv" to "Sueco", "no" to "Noruego",
        "da" to "Danés", "fi" to "Finés", "hu" to "Húngaro", "cs" to "Checo", "sk" to "Eslovaco",
        "bg" to "Búlgaro", "sr" to "Balcánico (serbio, croata…)", "sq" to "Albanés", "hi" to "Hindi (India)",
        "ur" to "Urdu (Pakistán)", "fa" to "Persa", "he" to "Hebreo", "ko" to "Coreano", "ja" to "Japonés",
        "zh" to "Chino", "uk" to "Ucraniano", "ca" to "Catalán", "th" to "Tailandés", "vi" to "Vietnamita",
        "id" to "Indonesio"
    )

    private val TOKENS = HashMap<String, String>()

    private fun add(code: String, vararg words: String) {
        for (w in words) TOKENS[w] = code
    }

    init {
        add("es", "es", "esp", "espana", "spain", "spanish", "espanol", "castellano", "lat", "latino", "latam", "mx", "mex", "arg", "hispano")
        add("en", "en", "eng", "uk", "gb", "us", "usa", "au", "english", "ingles")
        add("fr", "fr", "fra", "fre", "france", "french", "francais", "frances")
        add("de", "de", "ger", "deu", "germany", "german", "deutsch", "aleman", "alemania")
        add("it", "it", "ita", "italy", "italian", "italiano", "italia")
        add("pt", "pt", "prt", "portugal", "portuguese", "portugues", "br", "bra", "brasil", "brazil")
        add("ar", "ar", "ara", "arab", "arabic", "arabe", "arabia")
        add("tr", "tr", "tur", "turkey", "turkish", "turk", "turco", "turquia")
        add("nl", "nl", "nld", "dut", "netherlands", "dutch", "holandes", "holanda")
        add("pl", "pl", "pol", "poland", "polish", "polaco", "polonia")
        add("ru", "ru", "rus", "russia", "russian", "ruso", "rusia")
        add("ro", "ro", "rou", "romania", "romanian", "rumano")
        add("el", "gr", "gre", "greece", "greek", "griego", "grecia")
        add("sv", "se", "swe", "sweden", "swedish", "sueco")
        add("no", "nor", "norway", "norwegian", "noruego")
        add("da", "dk", "denmark", "danish", "danes")
        add("fi", "fi", "finland", "finnish")
        add("hu", "hu", "hun", "hungary", "hungarian")
        add("cs", "cz", "cs", "cze", "czech", "checo")
        add("sk", "sk", "svk", "slovak", "slovakia")
        add("bg", "bg", "bul", "bulgaria", "bulgarian")
        add("sr", "rs", "sr", "srb", "hr", "hrv", "ba", "bih", "mk", "balkan", "balkans", "exyu", "serbia", "croatia", "bosnia", "macedonia")
        add("sq", "al", "alb", "albania", "albanian")
        add("hi", "india", "indian", "hindi")
        add("ur", "pk", "pak", "urdu", "pakistan")
        add("fa", "ir", "iran", "persian", "farsi")
        add("he", "il", "isr", "israel", "hebrew")
        add("ko", "kr", "kor", "korea", "korean", "coreano")
        add("ja", "jp", "jpn", "japan", "japanese", "japones")
        add("zh", "cn", "chn", "china", "chinese", "chino")
        add("uk", "ua", "ukr", "ukraine", "ukrainian")
        add("ca", "catala", "catalan", "catalunya")
        add("th", "thai")
        add("vi", "vietnam")
        add("id", "indonesia")
    }

    // Código entre corchetes, paréntesis o barras: [ES]  (EN)  |FR|
    private val BRACKET = Regex("[\\[(|{]\\s*([a-z]{2,10})\\s*[\\])|}]")
    // Código de 2 letras al principio, solo si va seguido de un separador: "ES | ", "ES - ", "ES: "
    private val LEAD_SEP = Regex("^[^a-z0-9]*([a-z]{2})\\s*(?:[|:\\-–/·\\]).]|\$)")
    // Palabra de 3 o más letras al principio: "Latino Series", "FRA Cine"
    private val LEAD_WORD = Regex("^[^a-z0-9]*([a-z]{3,10})(?=[^a-z]|\$)")
    // Código al final tras un separador: "Movies | ES"
    private val TRAIL = Regex("[|:\\-–/·]\\s*([a-z]{2,10})\\s*[\\])]?\\s*\$")
    // Palabras largas (países/idiomas) en cualquier parte del nombre de la categoría
    private val WORD = Regex("[a-z]{5,12}")
    private val HINT_ES = Regex(
        "(?<![a-z])(?:peliculas|pelis|accion|infantiles|deportes|noticias|documentales|estrenos|novelas|cine|temporadas)(?![a-z])"
    )

    private val groupCache = ConcurrentHashMap<String, String>()

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT)

    private fun positional(t: String): String? {
        for (m in BRACKET.findAll(t)) TOKENS[m.groupValues[1]]?.let { return it }
        LEAD_SEP.find(t)?.let { m -> TOKENS[m.groupValues[1]]?.let { return it } }
        LEAD_WORD.find(t)?.let { m -> TOKENS[m.groupValues[1]]?.let { return it } }
        TRAIL.find(t)?.let { m -> TOKENS[m.groupValues[1]]?.let { return it } }
        return null
    }

    private fun detectGroup(group: String): String {
        val t = norm(group)
        positional(t)?.let { return it }
        for (m in WORD.findAll(t)) TOKENS[m.value]?.let { return it }
        if (HINT_ES.containsMatchIn(t)) return "es"
        return ""
    }

    /** Idioma de un elemento: primero por su categoría, y si no se sabe, por su nombre. */
    fun of(ch: Channel): String {
        val g = groupCache.getOrPut(ch.group) { detectGroup(ch.group) }
        if (g.isNotEmpty()) return g
        return positional(norm(ch.name)) ?: UNKNOWN
    }

    fun name(code: String): String =
        if (code == UNKNOWN) "Sin idioma detectado" else NAMES[code] ?: code.uppercase()

    fun typeLabel(t: ContentType): String = when (t) {
        ContentType.LIVE -> "TV en directo"
        ContentType.MOVIE -> "Películas"
        ContentType.SERIES -> "Series"
    }

    /** Idiomas encontrados en la lista, por tipo de contenido, con su número de elementos (de más a menos). */
    fun analyze(): Map<ContentType, List<Pair<String, Int>>> {
        val counts = HashMap<ContentType, HashMap<String, Int>>()
        for (c in Repo.all) {
            val m = counts.getOrPut(c.type) { HashMap() }
            val l = of(c)
            m[l] = (m[l] ?: 0) + 1
        }
        return counts.mapValues { entry ->
            entry.value.entries
                .map { it.key to it.value }
                .sortedWith(compareBy<Pair<String, Int>>({ it.first == UNKNOWN }, { -it.second }))
        }
    }
}

/**
 * Pregunta qué idiomas se quieren ver en TV, películas y series. Los que no se eligen quedan
 * bloqueados en el control parental (totalmente ocultos) y se gestionan desde allí.
 */
object LangPicker {

    private fun toast(a: AppCompatActivity, msg: String) = Toast.makeText(a, msg, Toast.LENGTH_LONG).show()

    /** [intro]: primera vez, con una explicación previa y la opción «Ahora no». */
    fun start(a: AppCompatActivity, intro: Boolean, onDone: () -> Unit) {
        Parental.markLangAsked(a)
        if (Repo.all.isEmpty()) {
            toast(a, "Primero carga una lista")
            return
        }
        toast(a, "Analizando idiomas de la lista…")
        Thread {
            val stats = Lang.analyze()
            a.runOnUiThread { afterAnalysis(a, stats, intro, onDone) }
        }.start()
    }

    private fun afterAnalysis(
        a: AppCompatActivity,
        stats: Map<ContentType, List<Pair<String, Int>>>,
        intro: Boolean,
        onDone: () -> Unit
    ) {
        val types = listOf(ContentType.LIVE, ContentType.MOVIE, ContentType.SERIES)
            .filter { (stats[it]?.size ?: 0) >= 2 }
        if (types.isEmpty()) {
            AlertDialog.Builder(a)
                .setTitle("Idiomas")
                .setMessage("He analizado la lista y solo hay un idioma (o no se distingue ninguno). No hace falta elegir.")
                .setPositiveButton("Aceptar", null)
                .show()
            return
        }
        val begin = {
            Parental.requirePin(a, "PIN para elegir idiomas") {
                ask(a, types, 0, stats, HashSet(), null, onDone)
            }
        }
        if (!intro) {
            begin()
            return
        }
        val summary = types.joinToString("\n") { t ->
            "• ${Lang.typeLabel(t)}: ${stats[t]!!.size} idiomas"
        }
        AlertDialog.Builder(a)
            .setTitle("¿En qué idioma quieres ver todo?")
            .setMessage(
                "He analizado tu lista y he encontrado varios idiomas:\n\n$summary\n\n" +
                    "Elige los que quieras ver en TV, películas y series. Los demás quedarán bloqueados y " +
                    "ocultos en el control parental."
            )
            .setPositiveButton("Elegir") { _, _ -> begin() }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    private fun ask(
        a: AppCompatActivity,
        types: List<ContentType>,
        i: Int,
        stats: Map<ContentType, List<Pair<String, Int>>>,
        blocked: MutableSet<String>,
        initial: BooleanArray?,
        onDone: () -> Unit
    ) {
        if (i >= types.size) {
            finish(a, blocked, onDone)
            return
        }
        val t = types[i]
        val entries = stats[t]!!
        val labels = entries.map { (code, n) -> "${Lang.name(code)}  ·  ${"%,d".format(n)}" }.toTypedArray()
        val checked = initial ?: defaultChecked(a, t, entries)
        val last = i == types.size - 1

        AlertDialog.Builder(a)
            .setTitle("${Lang.typeLabel(t)} (${i + 1}/${types.size}): ¿qué idiomas quieres ver?")
            .setMultiChoiceItems(labels, checked) { _, idx, on -> checked[idx] = on }
            .setPositiveButton(if (last) "Guardar" else "Siguiente") { _, _ ->
                if (checked.none { it }) {
                    toast(a, "Elige al menos un idioma")
                    ask(a, types, i, stats, blocked, checked, onDone)
                } else {
                    entries.forEachIndexed { k, e -> if (!checked[k]) blocked.add("${t.name}|${e.first}") }
                    ask(a, types, i + 1, stats, blocked, null, onDone)
                }
            }
            .setNeutralButton("Ver todos") { _, _ ->
                ask(a, types, i + 1, stats, blocked, null, onDone)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /** Primera vez: español (o el idioma del móvil) y «sin idioma». Después: lo que ya estaba elegido. */
    private fun defaultChecked(a: AppCompatActivity, t: ContentType, entries: List<Pair<String, Int>>): BooleanArray {
        val result = BooleanArray(entries.size)
        if (Parental.langSaved(a)) {
            val blocked = Parental.blockedLangs(a)
            entries.forEachIndexed { k, e -> result[k] = "${t.name}|${e.first}" !in blocked }
        } else {
            val mine = Locale.getDefault().language
            entries.forEachIndexed { k, e -> result[k] = e.first == Lang.UNKNOWN || e.first == "es" || e.first == mine }
        }
        if (result.none { it }) result.fill(true)
        return result
    }

    private fun finish(a: AppCompatActivity, blocked: Set<String>, onDone: () -> Unit) {
        Parental.saveBlockedLangs(a, blocked)
        onDone()
        if (blocked.isEmpty()) {
            toast(a, "Se mostrarán todos los idiomas")
            return
        }
        toast(a, "Idiomas guardados. Los demás están bloqueados en el control parental")
        if (!Parental.hasPin(a)) {
            AlertDialog.Builder(a)
                .setTitle("Crea un PIN")
                .setMessage("Los idiomas que no has elegido están ocultos. Con un PIN solo tú podrás volver a verlos desde Control parental.")
                .setPositiveButton("Crear PIN") { _, _ -> Parental.createPin(a) { onDone() } }
                .setNegativeButton("Ahora no", null)
                .show()
        }
    }
}
