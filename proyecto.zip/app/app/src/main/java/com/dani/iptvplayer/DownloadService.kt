package com.dani.iptvplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Descarga de películas y episodios en segundo plano, de una en una, con notificación de progreso.
 * Si se corta o se pausa, continúa por donde iba (cabecera Range).
 */
class DownloadService : Service() {

    companion object {
        private const val CHANNEL = "downloads"
        private const val NOTIF_ID = 4711
        private const val DONE = 0
        private const val PAUSED = 1
        private const val CANCELED = 2
        private const val FAILED = 3
        private const val RETRY_UA = 4
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var wake: PowerManager.WakeLock? = null

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Descargas", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            notification("Preparando la descarga…", 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        executor.execute {
            runQueue()
            // Solo se detiene si no ha llegado otra petición mientras tanto
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    // ---------- Cola ----------

    private fun runQueue() {
        acquireWake()
        try {
            while (true) {
                val dl = Downloads.nextQueued(this) ?: break
                process(dl)
            }
        } finally {
            releaseWake()
        }
    }

    private fun acquireWake() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "iptvplayer:download").apply {
                acquire(6 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWake() {
        try {
            if (wake?.isHeld == true) wake?.release()
        } catch (_: Exception) {
        }
        wake = null
    }

    private fun process(dl: Dl) {
        val result = try {
            if (Vpn.blocked(this)) {
                dl.error = "VPN no conectada"
                FAILED
            } else {
                fetch(dl)
            }
        } catch (e: Throwable) {
            dl.error = e.message ?: e.javaClass.simpleName
            FAILED
        }
        when (result) {
            DONE -> {
                dl.status = Downloads.DONE
                dl.bytes = File(dl.path).length()
                dl.total = dl.bytes
                Downloads.control.remove(dl.id)
                Downloads.save(this)
                notifyDone(dl)
            }
            PAUSED -> {
                dl.status = Downloads.PAUSED
                Downloads.control.remove(dl.id)
                Downloads.save(this)
            }
            CANCELED -> Downloads.removeNow(this, dl.id)
            else -> {
                dl.status = Downloads.ERROR
                Downloads.control.remove(dl.id)
                Downloads.save(this)
            }
        }
    }

    // ---------- Descarga ----------

    private fun fetch(dl: Dl): Int {
        val file = File(dl.path)
        file.parentFile?.mkdirs()
        if (dl.url.substringBefore('?').lowercase().endsWith(".m3u8")) {
            dl.error = "Es una emisión HLS (.m3u8): no se puede descargar como archivo"
            return FAILED
        }
        val uas = listOf(
            dl.ua.ifEmpty { Repo.userAgent(this) },
            Repo.UA_SMARTERS, Repo.UA_CHROME, Repo.UA_LAVF, Repo.UA_DALVIK, Repo.UA_OKHTTP
        )
        var lastError = "Error de red"
        for (ua in uas) {
            val r = attempt(dl, file, ua)
            if (r != RETRY_UA) return r
            lastError = dl.error
        }
        dl.error = lastError
        return FAILED
    }

    /** Un intento con un User-Agent. RETRY_UA = falló antes de recibir datos: se prueba con otro. */
    private fun attempt(dl: Dl, file: File, ua: String): Int {
        val existing = if (file.exists()) file.length() else 0L
        val rb = Request.Builder().url(dl.url).header("User-Agent", ua)
        for ((k, v) in dl.headers) {
            try {
                rb.header(k, v)
            } catch (_: Exception) {
            }
        }
        if (existing > 0) rb.header("Range", "bytes=$existing-")
        val resp = try {
            client.newCall(rb.build()).execute()
        } catch (e: Exception) {
            dl.error = e.message ?: "Sin conexión"
            return RETRY_UA
        }
        return resp.use { r -> readBody(dl, file, existing, r) }
    }

    private fun readBody(dl: Dl, file: File, existing: Long, r: Response): Int {
        if (r.code == 416 && existing > 0) {
            // Ya estaba completo
            dl.bytes = existing
            dl.total = existing
            return DONE
        }
        if (!r.isSuccessful) {
            dl.error = "El servidor respondió ${r.code}"
            return RETRY_UA
        }
        val body = r.body
        if (body == null) {
            dl.error = "Respuesta vacía"
            return RETRY_UA
        }
        val ct = body.contentType()
        if (ct != null && (ct.type == "text" || ct.subtype == "json")) {
            dl.error = "El servidor no devolvió un vídeo"
            return RETRY_UA
        }

        val partial = r.code == 206
        if (existing > 0 && !partial) file.delete() // el servidor no admite reanudar: se empieza de cero
        val start = if (partial) existing else 0L
        val len = body.contentLength()
        val rangeTotal = r.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
        dl.total = rangeTotal ?: if (len > 0) start + len else 0L
        dl.bytes = start

        val usable = file.parentFile?.usableSpace ?: Long.MAX_VALUE
        if (dl.total > 0 && dl.total - start > usable - 50L * 1024 * 1024) {
            dl.error = "No hay espacio suficiente en el dispositivo"
            return FAILED
        }
        Downloads.save(this)

        val out = FileOutputStream(file, start > 0)
        var lastNotif = 0L
        try {
            val input = body.byteStream()
            val buf = ByteArray(64 * 1024)
            while (true) {
                val ctl = Downloads.control[dl.id]
                if (ctl != null) return if (ctl == "cancel") CANCELED else PAUSED
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                dl.bytes += n
                val now = System.currentTimeMillis()
                if (now - lastNotif > 1000) {
                    lastNotif = now
                    updateNotification(dl)
                }
            }
        } catch (e: IOException) {
            dl.error = "Conexión interrumpida"
            return if (dl.bytes > start) FAILED else RETRY_UA
        } finally {
            try {
                out.close()
            } catch (_: Exception) {
            }
        }
        if (dl.total > 0 && dl.bytes < dl.total) {
            dl.error = "Descarga incompleta"
            return FAILED
        }
        if (dl.total <= 0) dl.total = dl.bytes
        return DONE
    }

    // ---------- Notificaciones ----------

    private fun notification(text: String, pct: Int, indeterminate: Boolean): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, DownloadsActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Descargando")
            .setContentText(text)
            .setProgress(100, pct, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(dl: Dl) {
        val pct = if (dl.total > 0) (dl.bytes * 100 / dl.total).toInt() else 0
        val n = notification(dl.title, pct, dl.total <= 0)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }

    private fun notifyDone(dl: Dl) {
        val pi = PendingIntent.getActivity(
            this, 1, Intent(this, DownloadsActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Descarga completada")
            .setContentText(dl.title)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        getSystemService(NotificationManager::class.java).notify(dl.id.hashCode(), n)
    }
}
