package com.dani.iptvplayer

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Una descarga (película o episodio). Los campos que cambian mientras se descarga son volátiles. */
class Dl(
    val id: String,
    val title: String,
    val url: String,
    val logo: String,
    val group: String,
    val type: ContentType,
    val ua: String,
    val headers: Map<String, String>,
    val path: String,
    @Volatile var status: String,
    @Volatile var bytes: Long = 0L,
    @Volatile var total: Long = 0L,
    @Volatile var error: String = ""
)

/** Lista de descargas guardada en las preferencias y acciones sobre ella. */
object Downloads {
    const val QUEUED = "queued"
    const val DOWNLOADING = "downloading"
    const val PAUSED = "paused"
    const val DONE = "done"
    const val ERROR = "error"

    private val lock = Any()
    private var items: MutableList<Dl>? = null
    private var askedNotifications = false

    /** Peticiones para detener una descarga en curso: id → "pause" o "cancel". */
    val control = ConcurrentHashMap<String, String>()

    private fun prefs(ctx: Context) = Repo.prefs(ctx)

    private fun load(ctx: Context): MutableList<Dl> {
        synchronized(lock) {
            items?.let { return it }
            val list = ArrayList<Dl>()
            try {
                val arr = JSONArray(prefs(ctx).getString("downloads", "[]"))
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val h = HashMap<String, String>()
                    val ho = o.optJSONObject("headers")
                    if (ho != null) {
                        val keys = ho.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            h[k] = ho.optString(k)
                        }
                    }
                    // Lo que estaba en curso cuando se cerró la app queda en pausa
                    var st = o.optString("status", PAUSED)
                    if (st == DOWNLOADING || st == QUEUED) st = PAUSED
                    val type = ContentType.values().firstOrNull { it.name == o.optString("type") } ?: ContentType.MOVIE
                    list.add(
                        Dl(
                            id = o.getString("id"),
                            title = o.optString("title"),
                            url = o.optString("url"),
                            logo = o.optString("logo"),
                            group = o.optString("group"),
                            type = type,
                            ua = o.optString("ua"),
                            headers = h,
                            path = o.optString("path"),
                            status = st,
                            bytes = o.optLong("bytes"),
                            total = o.optLong("total"),
                            error = o.optString("error")
                        )
                    )
                }
            } catch (_: Exception) {
            }
            items = list
            return list
        }
    }

    fun save(ctx: Context) {
        synchronized(lock) {
            val arr = JSONArray()
            for (d in load(ctx)) {
                val o = JSONObject()
                o.put("id", d.id)
                o.put("title", d.title)
                o.put("url", d.url)
                o.put("logo", d.logo)
                o.put("group", d.group)
                o.put("type", d.type.name)
                o.put("ua", d.ua)
                o.put("headers", JSONObject(d.headers))
                o.put("path", d.path)
                o.put("status", d.status)
                o.put("bytes", d.bytes)
                o.put("total", d.total)
                o.put("error", d.error)
                arr.put(o)
            }
            prefs(ctx).edit().putString("downloads", arr.toString()).apply()
        }
    }

    fun all(ctx: Context): List<Dl> = synchronized(lock) { ArrayList(load(ctx)) }

    fun idFor(url: String): String =
        MessageDigest.getInstance("MD5").digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(12)

    /** Carpeta propia de la app: no necesita permisos de almacenamiento. */
    fun dir(ctx: Context): File {
        val base = ctx.getExternalFilesDir("downloads") ?: File(ctx.filesDir, "downloads")
        base.mkdirs()
        return base
    }

    private fun fileName(title: String, id: String, url: String): String {
        val safe = title.replace(Regex("[^\\p{L}\\p{N} ._()-]"), "_").trim().take(80).ifEmpty { "video" }
        val ext = url.substringBefore('?').substringAfterLast('/', "").substringAfterLast('.', "").lowercase()
        val known = setOf("mkv", "mp4", "avi", "mov", "m4v", "wmv", "flv", "webm", "ts")
        return "$safe [$id].${if (ext in known) ext else "mp4"}"
    }

    private fun askNotificationPermission(a: Activity) {
        if (Build.VERSION.SDK_INT >= 33 && !askedNotifications &&
            a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotifications = true
            a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
    }

    fun startService(ctx: Context) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
    }

    /** Añade a la cola de descargas. Devuelve cuántas se han puesto en cola. */
    fun enqueue(a: Activity, chs: List<Channel>, titleFor: (Channel) -> String = { it.name }): Int {
        if (Vpn.blocked(a)) {
            Toast.makeText(a, "Conecta la VPN para descargar", Toast.LENGTH_LONG).show()
            return 0
        }
        askNotificationPermission(a)
        var n = 0
        synchronized(lock) {
            val l = load(a)
            for (ch in chs) {
                if (ch.url.startsWith("file:")) continue
                val id = idFor(ch.url)
                val existing = l.firstOrNull { it.id == id }
                if (existing != null) {
                    if (existing.status == ERROR || existing.status == PAUSED) {
                        existing.status = QUEUED
                        existing.error = ""
                        control.remove(id)
                        n++
                    }
                    continue
                }
                val title = titleFor(ch)
                l.add(
                    Dl(
                        id = id,
                        title = title,
                        url = ch.url,
                        logo = ch.logo,
                        group = ch.group,
                        type = ch.type,
                        ua = ch.userAgent,
                        headers = ch.headers,
                        path = File(dir(a), fileName(title, id, ch.url)).absolutePath,
                        status = QUEUED
                    )
                )
                n++
            }
        }
        save(a)
        if (n > 0) {
            startService(a)
            Toast.makeText(
                a,
                if (n == 1) "Añadido a descargas" else "$n añadidas a descargas",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(a, "Ya está en descargas", Toast.LENGTH_SHORT).show()
        }
        return n
    }

    /** El servicio coge la siguiente descarga en cola y la marca como en curso. */
    fun nextQueued(ctx: Context): Dl? {
        synchronized(lock) {
            val d = load(ctx).firstOrNull { it.status == QUEUED } ?: return null
            d.status = DOWNLOADING
            d.error = ""
            control.remove(d.id)
            save(ctx)
            return d
        }
    }

    fun pause(ctx: Context, id: String) {
        val d = all(ctx).firstOrNull { it.id == id } ?: return
        if (d.status == DOWNLOADING) {
            control[id] = "pause"
        } else if (d.status == QUEUED) {
            d.status = PAUSED
            save(ctx)
        }
    }

    fun resume(ctx: Context, id: String) {
        val d = all(ctx).firstOrNull { it.id == id } ?: return
        if (d.status == PAUSED || d.status == ERROR) {
            d.status = QUEUED
            d.error = ""
            control.remove(id)
            save(ctx)
            startService(ctx)
        }
    }

    /** Cancela (si está en curso) y borra la descarga y su archivo. */
    fun cancel(ctx: Context, id: String) {
        val d = all(ctx).firstOrNull { it.id == id } ?: return
        if (d.status == DOWNLOADING) {
            control[id] = "cancel"
        } else {
            removeNow(ctx, id)
        }
    }

    fun removeNow(ctx: Context, id: String) {
        synchronized(lock) {
            val l = load(ctx)
            val d = l.firstOrNull { it.id == id }
            if (d != null) {
                try {
                    File(d.path).delete()
                } catch (_: Exception) {
                }
                l.remove(d)
            }
            control.remove(id)
        }
        save(ctx)
    }

    /** Elemento reproducible sin conexión a partir de una descarga terminada. */
    fun toChannel(d: Dl): Channel =
        Channel(
            name = d.title,
            url = Uri.fromFile(File(d.path)).toString(),
            group = d.group,
            logo = d.logo,
            type = d.type
        )

    /** Lo mismo que el original, para comprobar el control parental (ocultos, idioma, adultos…). */
    fun asOriginal(d: Dl): Channel =
        Channel(name = d.title, url = d.url, group = d.group, logo = d.logo, type = d.type)
}
