package com.dani.iptvplayer

object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(text: String): List<Channel> = parse(text.lineSequence())

    fun parse(lines: Sequence<String>): List<Channel> {
        val out = ArrayList<Channel>()
        var name = ""
        var group = ""
        var logo = ""
        var ua = ""
        var headers = LinkedHashMap<String, String>()
        var pending = false

        for (raw in lines) {
            val line = raw.trim().trimStart('﻿')
            if (line.isEmpty()) continue

            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val attrs = attrRegex.findAll(line)
                    .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                group = attrs["group-title"].orEmpty().trim()
                logo = Repo.fixImage("", attrs["tvg-logo"])
                name = titleAfterLastComma(line)
                if (name.isEmpty()) name = attrs["tvg-name"].orEmpty().trim()
                pending = true
            } else if (line.startsWith("#EXTGRP:", ignoreCase = true)) {
                if (group.isEmpty()) group = line.substringAfter(':').trim()
            } else if (line.startsWith("#EXTVLCOPT:", ignoreCase = true)) {
                val kv = line.substringAfter(':')
                val key = kv.substringBefore('=').trim().lowercase()
                val value = kv.substringAfter('=', "").trim()
                when (key) {
                    "http-user-agent" -> ua = value
                    "http-referrer", "http-referer" -> headers["Referer"] = value
                    "http-origin" -> headers["Origin"] = value
                }
            } else if (line.startsWith("#KODIPROP:", ignoreCase = true)) {
                val kv = line.substringAfter(':')
                val key = kv.substringBefore('=').trim().lowercase()
                if (key == "inputstream.adaptive.stream_headers") {
                    parseHeaderString(kv.substringAfter('=', "")) { k, v ->
                        if (k.equals("user-agent", true)) ua = v else headers[k] = v
                    }
                }
            } else if (line.startsWith("#")) {
                continue
            } else if (pending || line.contains("://")) {
                // Formato Kodi: url|User-Agent=xxx&Referer=yyy
                var url = line
                if (line.contains('|') && line.contains("://")) {
                    url = line.substringBefore('|')
                    parseHeaderString(line.substringAfter('|')) { k, v ->
                        if (k.equals("user-agent", true)) ua = v else headers[k] = v
                    }
                }
                // Multicast típico: udp://@239.0.0.1:1234
                url = url.replace("udp://@", "udp://").replace("rtp://@", "udp://")

                out.add(
                    Channel(
                        name = name.ifEmpty { url },
                        url = url,
                        group = group.ifEmpty { "Sin grupo" },
                        logo = logo,
                        userAgent = ua,
                        headers = headers,
                        type = Classifier.classify(url, group)
                    )
                )
                name = ""
                group = ""
                logo = ""
                ua = ""
                headers = LinkedHashMap()
                pending = false
            }
        }
        return out
    }

    private fun parseHeaderString(s: String, onPair: (String, String) -> Unit) {
        for (part in s.split('&')) {
            val k = part.substringBefore('=').trim()
            val v = part.substringAfter('=', "").trim()
            if (k.isEmpty() || v.isEmpty()) continue
            val key = when (k.lowercase()) {
                "referer", "referrer" -> "Referer"
                "origin" -> "Origin"
                "cookie" -> "Cookie"
                "user-agent" -> "User-Agent"
                else -> k
            }
            onPair(key, v)
        }
    }

    /** El título es lo que hay tras la última coma que no esté dentro de comillas. */
    private fun titleAfterLastComma(line: String): String {
        var inQuotes = false
        var last = -1
        for (i in line.indices) {
            when (line[i]) {
                '"' -> inQuotes = !inQuotes
                ',' -> if (!inQuotes) last = i
            }
        }
        return if (last >= 0) line.substring(last + 1).trim() else ""
    }
}
