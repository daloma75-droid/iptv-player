package com.dani.iptvplayer

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.widget.Toast

/**
 * Exige una VPN activa. Android no deja que una app conecte la VPN de otra, así que
 * la app detecta si hay VPN, abre Proton VPN para que el usuario se conecte y espera.
 */
object Vpn {
    const val PROTON = "ch.protonvpn.android"

    /** Se activa si el usuario pulsa "Continuar sin VPN" (solo hasta cerrar la app). */
    var bypass = false

    /** Para abrir Proton VPN solo una vez por arranque. */
    var autoOpened = false

    fun required(ctx: Context): Boolean = Repo.prefs(ctx).getBoolean("vpn_required", true)

    fun setRequired(ctx: Context, value: Boolean) {
        Repo.prefs(ctx).edit().putBoolean("vpn_required", value).apply()
        if (value) bypass = false
    }

    fun isActive(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    }

    fun blocked(ctx: Context): Boolean = required(ctx) && !bypass && !isActive(ctx)

    /**
     * Ajustes de VPN de Android: pulsa el engranaje de Proton VPN y activa "VPN siempre activa".
     * Así Android la conecta solo al encender el móvil y la app ya no tiene que pedírtelo.
     */
    fun openAlwaysOnSettings(ctx: Context) {
        try {
            ctx.startActivity(Intent("android.settings.VPN_SETTINGS"))
            Toast.makeText(ctx, "Pulsa ⚙ junto a Proton VPN y activa «VPN siempre activa»", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "No se pudieron abrir los ajustes de VPN", Toast.LENGTH_LONG).show()
        }
    }

    fun openProton(ctx: Context) {
        try {
            val launch = ctx.packageManager.getLaunchIntentForPackage(PROTON)
            if (launch != null) {
                ctx.startActivity(launch)
            } else {
                Toast.makeText(ctx, "Proton VPN no está instalada: abro los ajustes de VPN", Toast.LENGTH_LONG).show()
                ctx.startActivity(Intent("android.settings.VPN_SETTINGS"))
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "No se pudo abrir la VPN", Toast.LENGTH_LONG).show()
        }
    }
}
