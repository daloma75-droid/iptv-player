package com.dani.iptvplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Vídeo de bienvenida al abrir la app. Se salta tocando la pantalla o con cualquier tecla del mando. */
class SplashActivity : AppCompatActivity() {

    private var done = false
    private lateinit var video: VideoView

    companion object {
        fun enabled(ctx: android.content.Context): Boolean =
            Repo.prefs(ctx).getBoolean("intro_video", true)

        fun setEnabled(ctx: android.content.Context, on: Boolean) {
            Repo.prefs(ctx).edit().putBoolean("intro_video", on).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!enabled(this)) {
            goHome()
            return
        }

        setContentView(R.layout.activity_splash)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        video = findViewById(R.id.introVideo)
        findViewById<View>(R.id.splashRoot).setOnClickListener { goHome() }
        video.setOnClickListener { goHome() }
        video.setOnCompletionListener { goHome() }
        video.setOnErrorListener { _, _, _ ->
            goHome()
            true
        }
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.intro}"))
        video.setOnPreparedListener { it.isLooping = false }
        video.start()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE ->
                super.onKeyDown(keyCode, event)
            else -> {
                goHome()
                true
            }
        }
    }

    private fun goHome() {
        if (done) return
        done = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onPause() {
        super.onPause()
        if (!done && ::video.isInitialized) video.pause()
    }

    override fun onResume() {
        super.onResume()
        if (!done && ::video.isInitialized) video.start()
    }
}
