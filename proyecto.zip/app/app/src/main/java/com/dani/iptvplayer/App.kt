package com.dani.iptvplayer

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

/**
 * Cargador de imágenes de toda la app. Muchos servidores rechazan el User-Agent genérico
 * de las apps, así que las carátulas se piden como si fuera un navegador. El cliente de red
 * es el de [Net]: reintenta, tiene DNS de respaldo y se recupera al conectar o quitar la VPN.
 */
class App : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        Net.watch(this)
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .okHttpClient(Net.imageClient)
            .respectCacheHeaders(false)
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.20).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("img"))
                    .maxSizePercent(0.03)
                    .build()
            }
            .build()
    }
}
