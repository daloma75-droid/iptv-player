package com.dani.iptvplayer

import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * Servicio mínimo que Android avisa cuando el usuario cierra la app deslizándola desde recientes.
 * En ese momento se corta la VPN propia (WireGuard), si así está ajustado.
 */
class CloseWatcherService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onTaskRemoved(rootIntent: Intent?) {
        WgVpn.closeIfNeeded(this, blocking = true)
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }
}
