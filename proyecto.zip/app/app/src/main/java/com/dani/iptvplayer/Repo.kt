package com.dani.iptvplayer

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.JsonReader
import android.util.JsonToken
import android.util.JsonWriter
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.zip.GZIPInputStream

class XtreamCreds(val host: String, val user: String, val pass: String)

/** Datos de la lista cargada, descarga de listas (M3U y Xtream) y caché en disco. */
object Repo {
    const val UA_VLC = "VLC/3.0.20 LibVLC/3.0.20"
    const val UA_CHROME =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    const val UA_LAVF = "Lavf/60.3.100"
    const val UA_SMARTERS = "IPTVSmartersPro"
    const val UA_DALVIK = "Dalvik/2.1.0 (Linux; U; Android 13; Pixel 7 Build/TQ3A.230901.001)"
    const val UA_OKHTTP = "okhttp/4.12.0"

    @Volatile
    var all: List<Channel> = emptyList()

    fun ofType(t: ContentType): List<Channel> = all.filter { it.type == t }

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("iptv", Context.MODE_PRIVATE)

    fun userAgent(ctx: Context): String =
        prefs(ctx).getString("ua", "").orEmpty().ifBlank { UA_VLC }

    // ---------- Red ----------

    /** Abre una URL siguiendo redirecciones (también http<->https) y descomprime gzip si hace falta. */
    fun open(startUrl: String, ua: String): InputStream {
        var current = startUrl
        repeat(8) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", ua)
            conn.setRequestProperty("Accept-Encoding", "gzip")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: throw Exception("Redirección sin destino")
                current = URL(URL(current), loc).toString()
                conn.disconnect()
            } else {
                if (code !in 200..299) throw Exception("El servidor respondió HTTP $code")
                val bis = BufferedInputStream(conn.inputStream, 65536)
                bis.mark(2)
                val b0 = bis.read()
                val b1 = bis.read()
                bis.reset()
                return if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(bis) else bis
            }
        }
        throw Exception("Demasiadas redirecciones")
    }

    private fun readText(url: String, ua: String): String =
        open(url, ua).bufferedReader(Charsets.UTF_8).use { it.readText() }

    // ---------- Caché ----------

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "channels.json")

    fun save(ctx: Context, list: List<Channel>) {
        val tmp = File(ctx.filesDir, "channels.json.tmp")
        JsonWriter(tmp.bufferedWriter()).use { w ->
            w.beginArray()
            for (c in list) {
                w.beginObject()
                w.name("n").value(c.name)
                w.name("u").value(c.url)
                w.name("g").value(c.group)
                w.name("l").value(c.logo)
                if (c.userAgent.isNotEmpty()) w.name("ua").value(c.userAgent)
                if (c.headers.isNotEmpty()) {
                    w.name("h").beginObject()
                    for ((k, v) in c.headers) w.name(k).value(v)
                    w.endObject()
                }
                w.name("t").value(c.type.name)
                if (c.addedAt > 0L) w.name("a").value(c.addedAt)
                if (c.seriesId.isNotEmpty()) w.name("s").value(c.seriesId)
                w.endObject()
            }
            w.endArray()
        }
        tmp.renameTo(cacheFile(ctx))
    }

    /** Carga la última lista guardada. Devuelve true si había algo. */
    fun loadCache(ctx: Context): Boolean {
        val f = cacheFile(ctx)
        if (f.exists()) {
            try {
                val out = ArrayList<Channel>()
                JsonReader(f.bufferedReader()).use { r ->
                    r.beginArray()
                    while (r.hasNext()) {
                        var n = ""
                        var u = ""
                        var g = ""
                        var l = ""
                        var ua = ""
                        var t = "LIVE"
                        var s = ""
                        var a = 0L
                        val h = LinkedHashMap<String, String>()
                        r.beginObject()
                        while (r.hasNext()) {
                            when (r.nextName()) {
                                "n" -> n = r.nextString()
                                "u" -> u = r.nextString()
                                "g" -> g = r.nextString()
                                "l" -> l = r.nextString()
                                "ua" -> ua = r.nextString()
                                "t" -> t = r.nextString()
                                "s" -> s = r.nextString()
                                "a" -> a = try { r.nextLong() } catch (_: Exception) { 0L }
                                "h" -> {
                                    r.beginObject()
                                    while (r.hasNext()) {
                                        val k = r.nextName()
                                        h[k] = r.nextString()
                                    }
                                    r.endObject()
                                }
                                else -> r.skipValue()
                            }
                        }
                        r.endObject()
                        val type = try {
                            ContentType.valueOf(t)
                        } catch (e: Exception) {
                            ContentType.LIVE
                        }
                        out.add(Channel(n, u, g, l, ua, h, type, s, a))
                    }
                    r.endArray()
                }
                all = out
                return out.isNotEmpty()
            } catch (e: Exception) {
                // caché corrupta: se ignora
            }
        }
        // Migración desde la versión anterior de la app (playlist.m3u)
        val old = File(ctx.filesDir, "playlist.m3u")
        if (old.exists()) {
            try {
                val list = M3uParser.parse(old.readText())
                if (list.isNotEmpty()) {
                    all = list
                    save(ctx, list)
                    prefs(ctx).edit().putString("src", "m3u").apply()
                    return true
                }
            } catch (e: Exception) {
            }
        }
        return false
    }

    fun clear(ctx: Context) {
        all = emptyList()
        cacheFile(ctx).delete()
        File(ctx.filesDir, "playlist.m3u").delete()
        prefs(ctx).edit().remove("src").remove("url").remove("xt_host").remove("xt_user").remove("xt_pass").remove("last_update").apply()
    }

    // ---------- Actualización automática ----------

    const val DEFAULT_AUTO_DAYS = 3

    /** Cada cuántos días se actualiza sola la lista (0 = nunca). Por defecto, 3. */
    fun autoDays(ctx: Context): Int = prefs(ctx).getInt("auto_days", DEFAULT_AUTO_DAYS)

    fun setAutoDays(ctx: Context, days: Int) {
        prefs(ctx).edit().putInt("auto_days", days).apply()
    }

    /** Momento (ms) de la última carga correcta de la lista; 0 si no se sabe. */
    fun lastUpdate(ctx: Context): Long = prefs(ctx).getLong("last_update", 0L)

    /** Solo las listas con URL o Xtream se pueden volver a descargar solas (no las de archivo). */
    fun canRefresh(ctx: Context): Boolean = prefs(ctx).getString("src", "") in listOf("xtream", "m3u")

    fun updateDue(ctx: Context): Boolean {
        val days = autoDays(ctx)
        if (days <= 0 || !canRefresh(ctx)) return false
        return System.currentTimeMillis() - lastUpdate(ctx) >= days * 24L * 60 * 60 * 1000
    }

    private fun commit(ctx: Context, list: List<Channel>): Int {
        all = list
        prefs(ctx).edit().putLong("last_update", System.currentTimeMillis()).apply()
        save(ctx, list)
        return list.size
    }

    // ---------- Listas M3U ----------

    /** Carga desde una URL. Si parece una URL de Xtream (get.php?username=…) usa la API, que es más rápida. */
    fun loadFromUrl(ctx: Context, url: String, progress: (String) -> Unit): Int {
        val ua = userAgent(ctx)
        val xt = xtreamFromUrl(url)
        if (xt != null) {
            try {
                return loadXtream(ctx, xt, progress)
            } catch (e: Exception) {
                progress("La API Xtream falló (${e.message}). Probando como lista M3U…")
            }
        }
        progress("Descargando lista…")
        val text = readText(url, ua)
        val n = loadFromText(ctx, text, url)
        prefs(ctx).edit().putString("src", "m3u").putString("url", url).apply()
        return n
    }

    fun loadFromText(ctx: Context, text: String, source: String): Int {
        // Si la URL es directamente un stream HLS (no una lista de canales), se trata como un único canal
        val isHlsStream = source.isNotEmpty() &&
            (text.contains("#EXT-X-STREAM-INF") || text.contains("#EXT-X-TARGETDURATION"))
        val channels = if (isHlsStream) {
            val n = source.substringBefore('?').substringAfterLast('/').ifEmpty { "Stream" }
            listOf(Channel(n, source, "Directo", ""))
        } else {
            M3uParser.parse(text)
        }
        if (channels.isEmpty()) throw Exception("La lista no tiene canales (¿es un M3U válido?)")
        return commit(ctx, channels)
    }

    fun loadFromFileText(ctx: Context, text: String): Int {
        val n = loadFromText(ctx, text, "")
        prefs(ctx).edit().putString("src", "file").remove("url").apply()
        return n
    }

    /** Vuelve a descargar la lista de origen. */
    fun refresh(ctx: Context, progress: (String) -> Unit): Int {
        val p = prefs(ctx)
        when (p.getString("src", "")) {
            "xtream" -> {
                val c = savedXtream(ctx) ?: throw Exception("Faltan los datos del servidor Xtream")
                return loadXtream(ctx, c, progress)
            }
            "m3u" -> {
                val url = p.getString("url", "").orEmpty()
                if (url.isEmpty()) throw Exception("No hay URL guardada")
                return loadFromUrl(ctx, url, progress)
            }
            else -> throw Exception("Esta lista viene de un archivo; vuelve a elegirlo")
        }
    }

    // ---------- Xtream Codes ----------

    fun savedXtream(ctx: Context): XtreamCreds? {
        val p = prefs(ctx)
        val h = p.getString("xt_host", "").orEmpty()
        val u = p.getString("xt_user", "").orEmpty()
        val s = p.getString("xt_pass", "").orEmpty()
        return if (h.isEmpty() || u.isEmpty()) null else XtreamCreds(h, u, s)
    }

    fun normalizeHost(input: String): String {
        var h = input.trim()
        if (!h.contains("://")) h = "http://$h"
        h = h.substringBefore("/player_api.php").substringBefore("/get.php").substringBefore("/panel_api.php")
        return h.trimEnd('/')
    }

    fun xtreamFromUrl(url: String): XtreamCreds? {
        if (!url.contains("get.php") && !url.contains("player_api.php")) return null
        val uri = Uri.parse(url)
        val u = uri.getQueryParameter("username") ?: return null
        val p = uri.getQueryParameter("password") ?: return null
        val authority = uri.encodedAuthority ?: return null
        val scheme = uri.scheme ?: "http"
        return XtreamCreds("$scheme://$authority", u, p)
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun api(c: XtreamCreds, action: String): String {
        val base = "${c.host}/player_api.php?username=${enc(c.user)}&password=${enc(c.pass)}"
        return if (action.isEmpty()) base else "$base&action=$action"
    }

    /** Lee un array JSON de objetos sin cargarlo entero en memoria. Cada objeto llega como mapa de textos. */
    private fun forEachObject(stream: InputStream, onObj: (Map<String, String>) -> Unit) {
        JsonReader(InputStreamReader(stream, Charsets.UTF_8)).use { r ->
            if (r.peek() != JsonToken.BEGIN_ARRAY) {
                r.skipValue()
                return@use
            }
            r.beginArray()
            while (r.hasNext()) {
                if (r.peek() != JsonToken.BEGIN_OBJECT) {
                    r.skipValue()
                    continue
                }
                val m = HashMap<String, String>()
                r.beginObject()
                while (r.hasNext()) {
                    val name = r.nextName()
                    when (r.peek()) {
                        JsonToken.STRING, JsonToken.NUMBER -> m[name] = r.nextString()
                        JsonToken.BOOLEAN -> m[name] = r.nextBoolean().toString()
                        else -> r.skipValue()
                    }
                }
                r.endObject()
                onObj(m)
            }
            r.endArray()
        }
    }

    private fun categories(c: XtreamCreds, action: String, ua: String): Map<String, String> {
        val m = HashMap<String, String>()
        try {
            forEachObject(open(api(c, action), ua)) { o ->
                m[o["category_id"].orEmpty()] = o["category_name"].orEmpty()
            }
        } catch (e: Exception) {
            // sin categorías: se usará "Sin categoría"
        }
        return m
    }

    fun loadXtream(ctx: Context, c: XtreamCreds, progress: (String) -> Unit): Int {
        val ua = userAgent(ctx)

        progress("Comprobando usuario…")
        val authText = readText(api(c, ""), ua)
        val auth = try {
            JSONObject(authText)
        } catch (e: Exception) {
            throw Exception("El servidor no respondió como Xtream Codes")
        }
        val info = auth.optJSONObject("user_info")
        if (info == null || info.optString("auth") == "0") throw Exception("Usuario o contraseña incorrectos")
        val status = info.optString("status")
        if (status.isNotEmpty() && !status.equals("Active", true)) throw Exception("La cuenta no está activa ($status)")

        val out = ArrayList<Channel>()
        val errors = ArrayList<String>()

        try {
            progress("Descargando TV en directo…")
            val cats = categories(c, "get_live_categories", ua)
            forEachObject(open(api(c, "get_live_streams"), ua)) { o ->
                val id = o["stream_id"]
                if (id != null) {
                    out.add(
                        Channel(
                            name = o["name"].orEmpty(),
                            url = "${c.host}/live/${c.user}/${c.pass}/$id.ts",
                            group = cats[o["category_id"].orEmpty()].orEmpty().ifEmpty { "Sin categoría" },
                            logo = fixImage(c.host, o["stream_icon"]),
                            type = ContentType.LIVE
                        )
                    )
                }
            }
        } catch (e: Exception) {
            errors.add("directo: ${e.message}")
        }

        try {
            progress("Descargando películas…")
            val cats = categories(c, "get_vod_categories", ua)
            forEachObject(open(api(c, "get_vod_streams"), ua)) { o ->
                val id = o["stream_id"]
                if (id != null) {
                    val ext = o["container_extension"].orEmpty().ifEmpty { "mp4" }
                    out.add(
                        Channel(
                            name = o["name"].orEmpty(),
                            url = "${c.host}/movie/${c.user}/${c.pass}/$id.$ext",
                            group = cats[o["category_id"].orEmpty()].orEmpty().ifEmpty { "Sin categoría" },
                            logo = fixImage(c.host, o["stream_icon"]),
                            type = ContentType.MOVIE,
                            addedAt = ContentDate.parse(o["added"] ?: o["last_modified"])
                        )
                    )
                }
            }
        } catch (e: Exception) {
            errors.add("películas: ${e.message}")
        }

        try {
            progress("Descargando series…")
            val cats = categories(c, "get_series_categories", ua)
            forEachObject(open(api(c, "get_series"), ua)) { o ->
                val id = o["series_id"]
                if (id != null) {
                    out.add(
                        Channel(
                            name = o["name"].orEmpty(),
                            url = "",
                            group = cats[o["category_id"].orEmpty()].orEmpty().ifEmpty { "Sin categoría" },
                            logo = fixImage(c.host, o["cover"]),
                            type = ContentType.SERIES,
                            seriesId = id,
                            addedAt = ContentDate.parse(o["added"] ?: o["last_modified"] ?: o["releaseDate"])
                        )
                    )
                }
            }
        } catch (e: Exception) {
            errors.add("series: ${e.message}")
        }

        if (out.isEmpty()) {
            throw Exception(if (errors.isEmpty()) "El servidor no devolvió contenido" else errors.joinToString("; "))
        }

        prefs(ctx).edit()
            .putString("src", "xtream")
            .putString("xt_host", c.host)
            .putString("xt_user", c.user)
            .putString("xt_pass", c.pass)
            .remove("url")
            .apply()
        progress("Guardando ${out.size} elementos…")
        return commit(ctx, out)
    }

    /** Deja una URL de imagen lista para descargar: rutas relativas, sin protocolo, "null", espacios… */
    fun fixImage(host: String, raw: String?): String {
        var u = raw.orEmpty().trim().replace("\\/", "/")
        if (u.isEmpty() || u.equals("null", true)) return ""
        u = when {
            u.startsWith("//") -> "https:$u"
            u.startsWith("/") -> host.trimEnd('/') + u
            u.contains("://") -> u
            u.substringBefore('/').contains('.') -> "http://$u"   // dominio sin protocolo
            else -> host.trimEnd('/') + "/" + u
        }
        return u.replace(" ", "%20")
    }

    /** Episodios de una serie de Xtream, ordenados por temporada y número. */
    fun loadEpisodes(c: XtreamCreds, seriesId: String, ua: String): List<Channel> {
        val text = readText(api(c, "get_series_info&series_id=$seriesId"), ua)
        val root = JSONObject(text)
        val eps = root.opt("episodes")
        val found = ArrayList<Triple<Int, Int, Channel>>()

        fun add(o: JSONObject, seasonHint: String) {
            val id = o.optString("id")
            if (id.isEmpty()) return
            val ext = o.optString("container_extension").ifEmpty { "mp4" }
            val season = o.optString("season").ifEmpty { seasonHint }
            val num = o.optString("episode_num")
            val title = o.optString("title")
            val img = o.optJSONObject("info")?.optString("movie_image").orEmpty()
            val label = "T$season E$num" + if (title.isNotEmpty()) " · $title" else ""
            found.add(
                Triple(
                    season.toIntOrNull() ?: 0,
                    num.toIntOrNull() ?: 0,
                    Channel(
                        name = label,
                        url = "${c.host}/series/${c.user}/${c.pass}/$id.$ext",
                        group = "Temporada $season",
                        logo = img,
                        type = ContentType.SERIES
                    )
                )
            )
        }

        if (eps is JSONObject) {
            val keys = eps.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val arr = eps.optJSONArray(k) ?: continue
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    add(o, k)
                }
            }
        } else if (eps is JSONArray) {
            for (i in 0 until eps.length()) {
                val arr = eps.optJSONArray(i) ?: continue
                for (j in 0 until arr.length()) {
                    val o = arr.optJSONObject(j) ?: continue
                    add(o, (i + 1).toString())
                }
            }
        }
        return found.sortedWith(compareBy({ it.first }, { it.second })).map { it.third }
    }
}
