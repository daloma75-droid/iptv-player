package com.dani.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import coil.load
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Busca carátulas que la lista no trae o que no cargan. Primero TMDB (si hay clave) y,
 * si no, iTunes. Lo encontrado se guarda para no volver a buscarlo.
 */
object Posters {
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())
    private val memory = ConcurrentHashMap<String, String>() // clave → url ("" = no encontrada)
    private val pending = HashMap<String, MutableList<(String) -> Unit>>()

    private fun store(ctx: Context) = ctx.applicationContext.getSharedPreferences("posters", Context.MODE_PRIVATE)

    fun tmdbKey(ctx: Context): String = Repo.prefs(ctx).getString("tmdb_key", "").orEmpty()

    fun setTmdbKey(ctx: Context, key: String) {
        Repo.prefs(ctx).edit().putString("tmdb_key", key).apply()
        // Con otra clave vale la pena reintentar lo que no se encontró
        memory.entries.removeAll { it.value.isEmpty() }
    }

    /** Pide la carátula de [c]. [cb] se llama en el hilo principal con la URL ("" si no hay). */
    fun resolve(ctx: Context, c: Channel, cb: (String) -> Unit) {
        val app = ctx.applicationContext
        val k = c.key
        val known = memory[k]
        if (known != null) {
            cb(known)
            return
        }
        val saved = store(app).getString(k, null)
        if (!saved.isNullOrEmpty()) {
            memory[k] = saved
            cb(saved)
            return
        }
        synchronized(pending) {
            val list = pending[k]
            if (list != null) {
                list.add(cb)
                return
            }
            pending[k] = arrayListOf(cb)
        }
        pool.execute {
            val url: String? = try {
                lookup(app, c)
            } catch (e: Exception) {
                null // sin red u otro fallo: no se recuerda, se reintentará
            }
            if (url != null) {
                memory[k] = url
                if (url.isNotEmpty()) store(app).edit().putString(k, url).apply()
            }
            val cbs = synchronized(pending) { pending.remove(k) }.orEmpty()
            main.post { cbs.forEach { it(url.orEmpty()) } }
        }
    }

    // ---------- Título y año ----------

    private val parenYear = Regex("""[(\[]\s*((?:19|20)\d{2})\s*[)\]]""")
    private val anyYear = Regex("""\b((?:19|20)\d{2})\b""")
    private val brackets = Regex("""[(\[][^)\]]*[)\]]""")
    private val langPrefix = Regex("""^\s*\|?[A-Z]{2,3}\s*[-|:]\s*""")
    private val tags = Regex(
        """(?i)\b(4k|uhd|fhd|hd|sd|hdr|hevc|x264|x265|h264|h265|2160p|1080p|720p|480p|multi|dual|latino|""" +
            """castellano|espanol|español|vose|vos|sub|subs|subtitulado|web-?dl|bluray|brrip|dvdrip)\b"""
    )

    fun yearOf(name: String): Int {
        parenYear.find(name)?.let { return it.groupValues[1].toInt() }
        if (name.trim().length <= 4) return 0 // un título que es solo un número (p. ej. «1917»)
        val m = anyYear.findAll(name).lastOrNull() ?: return 0
        val y = m.groupValues[1].toInt()
        return if (y in 1930..2035) y else 0
    }

    /** Quita prefijos de idioma, etiquetas de calidad, paréntesis y el año. */
    fun parseTitle(name: String): Pair<String, Int> {
        val year = yearOf(name)
        var t = brackets.replace(name, " ")
        t = langPrefix.replace(t, "")
        t = tags.replace(t, " ")
        if (year > 0) {
            val noYear = Regex("""\b$year\b""").replace(t, " ")
            if (noYear.isNotBlank()) t = noYear
        }
        t = t.replace('.', ' ').replace('_', ' ')
        t = Regex("""\s+""").replace(t, " ").trim(' ', '-', '|', ':')
        return t to year
    }

    // ---------- Búsqueda ----------

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun getJson(url: String): JSONObject =
        JSONObject(Repo.open(url, Repo.UA_CHROME).bufferedReader(Charsets.UTF_8).use { it.readText() })

    private fun lookup(ctx: Context, c: Channel): String {
        val (title, year) = parseTitle(c.name)
        if (title.length < 2) return ""
        val series = c.type == ContentType.SERIES
        val key = tmdbKey(ctx)
        if (key.isNotEmpty()) {
            val u = tmdb(key, title, year, series)
            if (u.isNotEmpty()) return u
        }
        return itunes(title, series)
    }

    private fun tmdb(key: String, title: String, year: Int, series: Boolean): String {
        val kind = if (series) "tv" else "movie"
        var url = "https://api.themoviedb.org/3/search/$kind?api_key=${enc(key)}" +
            "&language=es-ES&include_adult=false&query=${enc(title)}"
        if (year > 0) url += if (series) "&first_air_date_year=$year" else "&year=$year"
        val results = getJson(url).optJSONArray("results")
        if (results != null) {
            for (i in 0 until results.length()) {
                val path = results.optJSONObject(i)?.optString("poster_path").orEmpty()
                if (path.isNotEmpty() && path != "null") return "https://image.tmdb.org/t/p/w342$path"
            }
        }
        // Si con el año no sale nada, se prueba sin año
        return if (year > 0) tmdb(key, title, 0, series) else ""
    }

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun itunes(title: String, series: Boolean): String {
        val media = if (series) "tvShow" else "movie"
        val entity = if (series) "tvSeason" else "movie"
        val url = "https://itunes.apple.com/search?media=$media&entity=$entity&limit=8&term=${enc(title)}"
        val results = getJson(url).optJSONArray("results") ?: return ""
        val want = norm(title)
        for (i in 0 until results.length()) {
            val o = results.optJSONObject(i) ?: continue
            val name = norm(if (series) o.optString("collectionName") else o.optString("trackName"))
            val art = o.optString("artworkUrl100")
            if (art.isEmpty() || name.isEmpty()) continue
            if (name == want || name.startsWith(want) || (want.length > 5 && name.contains(want))) {
                return art.replace("100x100bb", "400x600bb")
            }
        }
        return ""
    }
}

/**
 * Carga la carátula de [c]. Si la de la lista falta, falla o es una imagen minúscula
 * (muchos servidores devuelven un cuadrado de 1×1), se busca en internet y se muestra esa.
 */
fun ImageView.loadPoster(c: Channel, ph: Int?) {
    tag = c.key
    val view = this

    fun fallback() {
        Posters.resolve(context, c) { url ->
            if (view.tag == c.key && url.isNotEmpty()) {
                view.load(url) {
                    crossfade(true)
                    if (ph != null) {
                        placeholder(ph)
                        error(ph)
                    }
                }
            }
        }
    }

    if (c.logo.isEmpty()) {
        if (ph != null) setImageResource(ph)
        fallback()
        return
    }
    load(c.logo) {
        crossfade(true)
        if (ph != null) {
            placeholder(ph)
            error(ph)
        }
        listener(
            onError = { _, _ -> fallback() },
            onSuccess = { _, result -> if (result.drawable.intrinsicWidth in 1..40) fallback() }
        )
    }
}
