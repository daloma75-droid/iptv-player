package com.dani.iptvplayer

import android.app.Activity
import android.content.Intent
import android.view.View

/** Barra de navegación inferior de 5 pestañas, compartida por el inicio y la exploración. */
object BottomNav {

    fun setup(activity: Activity, selected: Int) {
        val ids = intArrayOf(R.id.navHome, R.id.navLive, R.id.navMovies, R.id.navSeries, R.id.navSearch)
        for (id in ids) {
            val v = activity.findViewById<View>(id)
            v.isSelected = id == selected
            v.setOnClickListener { go(activity, id, selected) }
        }
    }

    /** Pestaña que corresponde a cada sección de BrowseActivity. */
    fun tabFor(section: String): Int = when (section) {
        "live" -> R.id.navLive
        "movie" -> R.id.navMovies
        "series" -> R.id.navSeries
        "all" -> R.id.navSearch
        else -> 0
    }

    private fun go(activity: Activity, id: Int, selected: Int) {
        if (id == selected) return
        if (id == R.id.navHome) {
            if (activity is MainActivity) return
            activity.startActivity(
                Intent(activity, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
            return
        }
        if (Repo.all.isEmpty()) return
        val section = when (id) {
            R.id.navLive -> "live"
            R.id.navMovies -> "movie"
            R.id.navSeries -> "series"
            else -> "all"
        }
        activity.startActivity(Intent(activity, BrowseActivity::class.java).putExtra("section", section))
        if (activity is BrowseActivity) {
            activity.finish()
            activity.overridePendingTransition(0, 0)
        }
    }
}
