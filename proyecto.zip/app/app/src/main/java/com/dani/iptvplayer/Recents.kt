package com.dani.iptvplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** "Seguir viendo": guarda la posición de películas y episodios para retomarlos. */
object Recents {
    private const val KEY = "recents"
    private const val MAX = 20

    class Entry(val channel: Channel, val pos: Long, val dur: Long)

    private fun raw(ctx: Context): String = Repo.prefs(ctx).getString(KEY, "") ?: ""

    /** Cambia cada vez que se modifica la lista (sirve para saber si hay que redibujar el inicio). */
    fun signature(ctx: Context): Int = raw(ctx).hashCode()

    fun load(ctx: Context): List<Entry> {
        val s = raw(ctx)
        if (s.isEmpty()) return emptyList()
        val out = ArrayList<Entry>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val headers = LinkedHashMap<String, String>()
                val h = o.optJSONObject("h")
                if (h != null) {
                    val keys = h.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        headers[k] = h.optString(k)
                    }
                }
                val type = try {
                    ContentType.valueOf(o.optString("t", "MOVIE"))
                } catch (e: Exception) {
                    ContentType.MOVIE
                }
                val ch = Channel(
                    name = o.optString("n"),
                    url = o.optString("u"),
                    group = o.optString("g"),
                    logo = o.optString("l"),
                    userAgent = o.optString("ua"),
                    headers = headers,
                    type = type,
                    seriesId = o.optString("sid")
                )
                out.add(Entry(ch, o.optLong("p"), o.optLong("d")))
            }
        } catch (e: Exception) {
            // Datos corruptos: se ignoran
        }
        return out
    }

    fun positionFor(ctx: Context, url: String): Long =
        load(ctx).firstOrNull { it.channel.url == url }?.pos ?: 0L

    /** Guarda el progreso. Si ya se vio casi entero, lo quita de la lista. */
    fun save(ctx: Context, ch: Channel, pos: Long, dur: Long) {
        if (ch.type == ContentType.LIVE || dur <= 0L) return
        val list = load(ctx).filter { it.channel.url != ch.url }.toMutableList()
        val finished = pos > dur * 95 / 100
        if (finished) {
            write(ctx, list)
        } else if (pos > 5000L) {
            list.add(0, Entry(ch, pos, dur))
            write(ctx, list.take(MAX))
        }
    }

    private fun write(ctx: Context, list: List<Entry>) {
        val arr = JSONArray()
        for (e in list) {
            val o = JSONObject()
            o.put("n", e.channel.name)
            o.put("u", e.channel.url)
            o.put("g", e.channel.group)
            o.put("l", e.channel.logo)
            o.put("ua", e.channel.userAgent)
            o.put("t", e.channel.type.name)
            o.put("sid", e.channel.seriesId)
            val h = JSONObject()
            for ((k, v) in e.channel.headers) h.put(k, v)
            o.put("h", h)
            o.put("p", e.pos)
            o.put("d", e.dur)
            arr.put(o)
        }
        Repo.prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }
}
