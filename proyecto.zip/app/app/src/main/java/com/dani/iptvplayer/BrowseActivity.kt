package com.dani.iptvplayer

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.max

/** Exploración: categorías como píldoras arriba y rejilla de carátulas debajo. */
class BrowseActivity : AppCompatActivity() {

    companion object {
        private const val ALL = "Todos"
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var adapter: ChannelAdapter
    private lateinit var catAdapter: CategoryAdapter

    private var section = "live"
    private var items: List<Channel> = emptyList()
    private var shown: List<Channel> = emptyList()
    private var currentGroup = ALL
    private val favorites = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)

        prefs = Repo.prefs(this)
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())

        section = intent.getStringExtra("section") ?: "live"
        items = computeItems()
        val poster = section == "movie" || section == "series"

        findViewById<TextView>(R.id.title).text = when (section) {
            "movie" -> "Películas"
            "series" -> "Series"
            "fav" -> "★ Mi lista"
            "all" -> "Buscar"
            else -> "TV en directo"
        }
        search = findViewById(R.id.search)
        search.hint = if (section == "all") "Canales, películas y series" else "Buscar en ${findViewById<TextView>(R.id.title).text}"
        status = findViewById(R.id.status)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        BottomNav.setup(this, BottomNav.tabFor(section))

        // Columnas de la rejilla según el ancho disponible
        val dm = resources.displayMetrics
        val gridWidth = dm.widthPixels - (16 * dm.density).toInt()
        val cellDp = if (poster) 108 else 300
        val span = max(1, (gridWidth / (cellDp * dm.density)).toInt())

        adapter = ChannelAdapter(
            poster,
            gridWidth / span,
            favorites,
            onClick = { position -> open(position) },
            onLongClick = { position -> itemMenu(position) }
        )
        val grid = findViewById<RecyclerView>(R.id.grid)
        grid.layoutManager = GridLayoutManager(this, span)
        grid.adapter = adapter

        catAdapter = CategoryAdapter(
            onClick = { group -> selectGroup(group) },
            onLongClick = { group -> toggleGroupLock(group) },
            isLocked = { group -> Parental.isLocked(this, group) }
        )
        val cats = findViewById<RecyclerView>(R.id.categories)
        cats.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        cats.adapter = catAdapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })

        setupCategories()

        // Categoría preseleccionada (al llegar desde una fila del inicio)
        val wantGroup = intent.getStringExtra("group")
        if (wantGroup != null) {
            val idx = catAdapter.select(wantGroup)
            if (idx >= 0) {
                currentGroup = wantGroup
                cats.scrollToPosition(idx)
            }
        }
        applyFilter()

        // Abrir directamente un elemento (series de Xtream desde el inicio)
        val openKey = intent.getStringExtra("open")
        if (openKey != null) {
            val idx = shown.indexOfFirst { it.key == openKey }
            if (idx >= 0) cats.post { open(idx) }
        }

        if (section == "all") {
            search.post {
                search.requestFocus()
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
            }
        } else {
            cats.post { cats.requestFocus() }
        }
    }

    /** Contenido de esta pantalla ya sin lo oculto ni lo bloqueado por el control parental. */
    private fun computeItems(): List<Channel> {
        val visible = Parental.visible(this)
        return when (section) {
            "movie" -> visible.filter { it.type == ContentType.MOVIE }
            "series" -> visible.filter { it.type == ContentType.SERIES }
            "fav", "all" -> visible
            // TV en directo: nacionales principales, luego Movistar, luego el resto
            else -> ChannelOrder.sortLive(visible.filter { it.type == ContentType.LIVE })
        }
    }

    private fun base(): List<Channel> =
        if (section == "fav") items.filter { it.key in favorites } else items

    private fun setupCategories() {
        val list = base()
        val groups = ArrayList<String>()
        groups.add(ALL)
        val distinct = list.map { it.group }.distinct()
        groups.addAll(if (section == "live") ChannelOrder.sortGroups(distinct, list) else distinct)
        val counts = HashMap<String, Int>()
        counts[ALL] = list.count { !Parental.isLocked(this, it.group) }
        for (c in list) counts[c.group] = (counts[c.group] ?: 0) + 1
        catAdapter.submit(groups, counts)
        currentGroup = ALL
    }

    private fun selectGroup(group: String) {
        if (group != ALL && Parental.isLocked(this, group)) {
            Parental.requirePin(this, "PIN para abrir «$group»") {
                Parental.unlock(group)
                catAdapter.refresh()
                catAdapter.select(group)
                currentGroup = group
                applyFilter()
            }
        } else {
            catAdapter.select(group)
            currentGroup = group
            applyFilter()
        }
    }

    private fun toggleGroupLock(group: String) {
        if (group == ALL) return
        Parental.toggleLock(this, group) { locked ->
            items = computeItems()
            setupCategories()
            applyFilter()
            Toast.makeText(
                this,
                if (locked) "Categoría bloqueada y oculta. Para verla: Control parental → Categorías bloqueadas"
                else "Categoría desbloqueada",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = base().filter { c ->
            (if (currentGroup == ALL) !Parental.isLocked(this, c.group) else c.group == currentGroup) &&
                (q.isEmpty() || c.name.lowercase().contains(q))
        }
        adapter.submit(shown)
        status.text = "${shown.size} elementos · mantén pulsado para favoritos, descargar u ocultar"
    }

    private fun open(position: Int) {
        val ch = shown[position]
        if (ch.seriesId.isNotEmpty()) {
            openSeries(ch)
            return
        }
        Playlist.channels = shown
        Playlist.index = position
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun openSeries(ch: Channel, download: Boolean = false) {
        val xt = Repo.savedXtream(this)
        if (xt == null) {
            Toast.makeText(this, "Los episodios necesitan una lista Xtream", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Cargando episodios de ${ch.name}…"
        Thread {
            try {
                val eps = Repo.loadEpisodes(xt, ch.seriesId, Repo.userAgent(this))
                runOnUiThread { showEpisodes(ch, eps, download) }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.text = "${shown.size} elementos"
                    Toast.makeText(this, "No se pudieron cargar los episodios: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showEpisodes(ch: Channel, eps: List<Channel>, download: Boolean = false) {
        status.text = "${shown.size} elementos"
        if (eps.isEmpty()) {
            Toast.makeText(this, "Esta serie no tiene episodios", Toast.LENGTH_LONG).show()
            return
        }
        if (download) {
            pickEpisodes(ch, eps)
            return
        }
        val names = eps.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(names) { _, which ->
                Playlist.channels = eps
                Playlist.index = which
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            .setNeutralButton("Descargar…") { _, _ -> pickEpisodes(ch, eps) }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    /** Elegir qué episodios de una serie descargar. */
    private fun pickEpisodes(ch: Channel, eps: List<Channel>) {
        val names = eps.map { it.name }.toTypedArray()
        val checked = BooleanArray(eps.size)
        AlertDialog.Builder(this)
            .setTitle("Descargar de ${ch.name}")
            .setMultiChoiceItems(names, checked) { _, i, on -> checked[i] = on }
            .setPositiveButton("Descargar") { _, _ ->
                val sel = eps.filterIndexed { i, _ -> checked[i] }
                if (sel.isEmpty()) {
                    Toast.makeText(this, "Marca al menos un episodio", Toast.LENGTH_SHORT).show()
                } else {
                    Downloads.enqueue(this, sel) { "${ch.name} · ${it.name}" }
                }
            }
            .setNeutralButton("Todos") { _, _ ->
                Downloads.enqueue(this, eps) { "${ch.name} · ${it.name}" }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /** Pulsación larga: favoritos u ocultar con el control parental. */
    private fun itemMenu(position: Int) {
        val ch = shown[position]
        val fav = if (ch.key in favorites) "Quitar de favoritos" else "Añadir a favoritos"
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        labels.add(fav)
        actions.add { toggleFavorite(position) }
        if (ch.seriesId.isNotEmpty()) {
            labels.add("Descargar episodios…")
            actions.add { openSeries(ch, true) }
        } else if (ch.type != ContentType.LIVE) {
            labels.add("Descargar")
            actions.add { Downloads.enqueue(this, listOf(ch)) }
        }
        labels.add("Ocultar (control parental)")
        actions.add { hideItem(ch) }
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun hideItem(ch: Channel) {
        Parental.hideItem(this, ch) {
            items = computeItems()
            setupCategories()
            applyFilter()
        }
    }

    private fun toggleFavorite(position: Int) {
        val ch = shown[position]
        val added = favorites.add(ch.key)
        if (!added) favorites.remove(ch.key)
        prefs.edit().putStringSet("favorites", HashSet(favorites)).apply()
        Toast.makeText(this, if (added) "Añadido a favoritos" else "Quitado de favoritos", Toast.LENGTH_SHORT).show()
        if (section == "fav") {
            applyFilter()
        } else {
            adapter.notifyItemChanged(position)
        }
    }
}
