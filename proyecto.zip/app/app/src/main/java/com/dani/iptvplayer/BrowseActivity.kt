package com.dani.iptvplayer

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.max

/** Pantalla de exploración estilo Smarters: categorías a la izquierda y rejilla a la derecha. */
class BrowseActivity : AppCompatActivity() {

    companion object {
        private const val ALL = "Todos"
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var adapter: ChannelAdapter
    private lateinit var catAdapter: CategoryAdapter

    private var section = "live"
    private var items: List<Channel> = emptyList()
    private var shown: List<Channel> = emptyList()
    private var currentGroup = ALL
    private val favorites = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)

        prefs = Repo.prefs(this)
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())

        section = intent.getStringExtra("section") ?: "live"
        items = when (section) {
            "movie" -> Repo.ofType(ContentType.MOVIE)
            "series" -> Repo.ofType(ContentType.SERIES)
            "fav" -> Repo.all
            else -> Repo.ofType(ContentType.LIVE)
        }
        val poster = section == "movie" || section == "series"

        findViewById<TextView>(R.id.title).text = when (section) {
            "movie" -> "Películas"
            "series" -> "Series"
            "fav" -> "★ Favoritos"
            else -> "TV en directo"
        }
        search = findViewById(R.id.search)
        status = findViewById(R.id.status)
        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        // Columnas de la rejilla según el ancho disponible
        val dm = resources.displayMetrics
        val gridWidth = dm.widthPixels - resources.getDimensionPixelSize(R.dimen.cat_width) - (16 * dm.density).toInt()
        val cellDp = if (poster) 120 else 300
        val span = max(1, (gridWidth / (cellDp * dm.density)).toInt())

        adapter = ChannelAdapter(
            poster,
            gridWidth / span,
            favorites,
            onClick = { position -> open(position) },
            onLongClick = { position -> toggleFavorite(position) }
        )
        val grid = findViewById<RecyclerView>(R.id.grid)
        grid.layoutManager = GridLayoutManager(this, span)
        grid.adapter = adapter

        catAdapter = CategoryAdapter { group ->
            currentGroup = group
            applyFilter()
        }
        val cats = findViewById<RecyclerView>(R.id.categories)
        cats.layoutManager = LinearLayoutManager(this)
        cats.adapter = catAdapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })

        setupCategories()
        applyFilter()
        cats.post { cats.requestFocus() }
    }

    private fun base(): List<Channel> =
        if (section == "fav") items.filter { it.key in favorites } else items

    private fun setupCategories() {
        val list = base()
        val groups = ArrayList<String>()
        groups.add(ALL)
        groups.addAll(list.map { it.group }.distinct())
        val counts = HashMap<String, Int>()
        counts[ALL] = list.size
        for (c in list) counts[c.group] = (counts[c.group] ?: 0) + 1
        catAdapter.submit(groups, counts)
        currentGroup = ALL
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = base().filter { c ->
            (currentGroup == ALL || c.group == currentGroup) &&
                (q.isEmpty() || c.name.lowercase().contains(q))
        }
        adapter.submit(shown)
        status.text = "${shown.size} elementos · mantén pulsado para añadir a favoritos"
    }

    private fun open(position: Int) {
        val ch = shown[position]
        if (ch.seriesId.isNotEmpty()) {
            openSeries(ch)
            return
        }
        Playlist.channels = shown
        Playlist.index = position
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun openSeries(ch: Channel) {
        val xt = Repo.savedXtream(this)
        if (xt == null) {
            Toast.makeText(this, "Los episodios necesitan una lista Xtream", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Cargando episodios de ${ch.name}…"
        Thread {
            try {
                val eps = Repo.loadEpisodes(xt, ch.seriesId, Repo.userAgent(this))
                runOnUiThread { showEpisodes(ch, eps) }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.text = "${shown.size} elementos"
                    Toast.makeText(this, "No se pudieron cargar los episodios: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showEpisodes(ch: Channel, eps: List<Channel>) {
        status.text = "${shown.size} elementos"
        if (eps.isEmpty()) {
            Toast.makeText(this, "Esta serie no tiene episodios", Toast.LENGTH_LONG).show()
            return
        }
        val names = eps.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(names) { _, which ->
                Playlist.channels = eps
                Playlist.index = which
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun toggleFavorite(position: Int) {
        val ch = shown[position]
        val added = favorites.add(ch.key)
        if (!added) favorites.remove(ch.key)
        prefs.edit().putStringSet("favorites", HashSet(favorites)).apply()
        Toast.makeText(this, if (added) "Añadido a favoritos" else "Quitado de favoritos", Toast.LENGTH_SHORT).show()
        if (section == "fav") {
            applyFilter()
        } else {
            adapter.notifyItemChanged(position)
        }
    }
}
