package com.dani.iptvplayer

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.max

/** Exploración: categorías como píldoras arriba y rejilla de carátulas debajo. */
class BrowseActivity : AppCompatActivity() {

    companion object {
        private const val ALL = "Todos"
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var adapter: ChannelAdapter
    private lateinit var catAdapter: CategoryAdapter

    private var section = "live"
    private var items: List<Channel> = emptyList()
    private var shown: List<Channel> = emptyList()
    private var currentGroup = ALL
    private val favorites = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)

        prefs = Repo.prefs(this)
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())

        section = intent.getStringExtra("section") ?: "live"
        val visible = Parental.visible(this)
        items = when (section) {
            "movie" -> visible.filter { it.type == ContentType.MOVIE }
            "series" -> visible.filter { it.type == ContentType.SERIES }
            "fav", "all" -> visible
            else -> visible.filter { it.type == ContentType.LIVE }
        }
        val poster = section == "movie" || section == "series"

        findViewById<TextView>(R.id.title).text = when (section) {
            "movie" -> "Películas"
            "series" -> "Series"
            "fav" -> "★ Mi lista"
            "all" -> "Buscar"
            else -> "TV en directo"
        }
        search = findViewById(R.id.search)
        search.hint = if (section == "all") "Canales, películas y series" else "Buscar en ${findViewById<TextView>(R.id.title).text}"
        status = findViewById(R.id.status)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        BottomNav.setup(this, BottomNav.tabFor(section))

        // Columnas de la rejilla según el ancho disponible
        val dm = resources.displayMetrics
        val gridWidth = dm.widthPixels - (16 * dm.density).toInt()
        val cellDp = if (poster) 108 else 300
        val span = max(1, (gridWidth / (cellDp * dm.density)).toInt())

        adapter = ChannelAdapter(
            poster,
            gridWidth / span,
            favorites,
            onClick = { position -> open(position) },
            onLongClick = { position -> itemMenu(position) }
        )
        val grid = findViewById<RecyclerView>(R.id.grid)
        grid.layoutManager = GridLayoutManager(this, span)
        grid.adapter = adapter

        catAdapter = CategoryAdapter(
            onClick = { group -> selectGroup(group) },
            onLongClick = { group -> toggleGroupLock(group) },
            isLocked = { group -> Parental.isLocked(this, group) }
        )
        val cats = findViewById<RecyclerView>(R.id.categories)
        cats.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        cats.adapter = catAdapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })

        setupCategories()

        // Categoría preseleccionada (al llegar desde una fila del inicio)
        val wantGroup = intent.getStringExtra("group")
        if (wantGroup != null) {
            val idx = catAdapter.select(wantGroup)
            if (idx >= 0) {
                currentGroup = wantGroup
                cats.scrollToPosition(idx)
            }
        }
        applyFilter()

        // Abrir directamente un elemento (series de Xtream desde el inicio)
        val openKey = intent.getStringExtra("open")
        if (openKey != null) {
            val idx = shown.indexOfFirst { it.key == openKey }
            if (idx >= 0) cats.post { open(idx) }
        }

        if (section == "all") {
            search.post {
                search.requestFocus()
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
            }
        } else {
            cats.post { cats.requestFocus() }
        }
    }

    private fun base(): List<Channel> =
        if (section == "fav") items.filter { it.key in favorites } else items

    private fun setupCategories() {
        val list = base()
        val groups = ArrayList<String>()
        groups.add(ALL)
        groups.addAll(list.map { it.group }.distinct())
        val counts = HashMap<String, Int>()
        counts[ALL] = list.count { !Parental.isLocked(this, it.group) }
        for (c in list) counts[c.group] = (counts[c.group] ?: 0) + 1
        catAdapter.submit(groups, counts)
        currentGroup = ALL
    }

    private fun selectGroup(group: String) {
        if (group != ALL && Parental.isLocked(this, group)) {
            Parental.requirePin(this, "PIN para abrir «$group»") {
                Parental.unlock(group)
                catAdapter.refresh()
                catAdapter.select(group)
                currentGroup = group
                applyFilter()
            }
        } else {
            catAdapter.select(group)
            currentGroup = group
            applyFilter()
        }
    }

    private fun toggleGroupLock(group: String) {
        if (group == ALL) return
        Parental.toggleLock(this, group) { locked ->
            if (locked && currentGroup == group) {
                catAdapter.select(ALL)
                currentGroup = ALL
            }
            catAdapter.refresh()
            applyFilter()
            Toast.makeText(this, if (locked) "Categoría bloqueada" else "Categoría desbloqueada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = base().filter { c ->
            (if (currentGroup == ALL) !Parental.isLocked(this, c.group) else c.group == currentGroup) &&
                (q.isEmpty() || c.name.lowercase().contains(q))
        }
        adapter.submit(shown)
        status.text = "${shown.size} elementos · mantén pulsado para favoritos u ocultar"
    }

    private fun open(position: Int) {
        val ch = shown[position]
        if (ch.seriesId.isNotEmpty()) {
            openSeries(ch)
            return
        }
        Playlist.channels = shown
        Playlist.index = position
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun openSeries(ch: Channel) {
        val xt = Repo.savedXtream(this)
        if (xt == null) {
            Toast.makeText(this, "Los episodios necesitan una lista Xtream", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Cargando episodios de ${ch.name}…"
        Thread {
            try {
                val eps = Repo.loadEpisodes(xt, ch.seriesId, Repo.userAgent(this))
                runOnUiThread { showEpisodes(ch, eps) }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.text = "${shown.size} elementos"
                    Toast.makeText(this, "No se pudieron cargar los episodios: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showEpisodes(ch: Channel, eps: List<Channel>) {
        status.text = "${shown.size} elementos"
        if (eps.isEmpty()) {
            Toast.makeText(this, "Esta serie no tiene episodios", Toast.LENGTH_LONG).show()
            return
        }
        val names = eps.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(names) { _, which ->
                Playlist.channels = eps
                Playlist.index = which
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    /** Pulsación larga: favoritos u ocultar con el control parental. */
    private fun itemMenu(position: Int) {
        val ch = shown[position]
        val fav = if (ch.key in favorites) "Quitar de favoritos" else "Añadir a favoritos"
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(arrayOf(fav, "Ocultar (control parental)")) { _, which ->
                if (which == 0) toggleFavorite(position) else hideItem(ch)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun hideItem(ch: Channel) {
        Parental.hideItem(this, ch) {
            items = items.filter { it.key != ch.key }
            setupCategories()
            applyFilter()
        }
    }

    private fun toggleFavorite(position: Int) {
        val ch = shown[position]
        val added = favorites.add(ch.key)
        if (!added) favorites.remove(ch.key)
        prefs.edit().putStringSet("favorites", HashSet(favorites)).apply()
        Toast.makeText(this, if (added) "Añadido a favoritos" else "Quitado de favoritos", Toast.LENGTH_SHORT).show()
        if (section == "fav") {
            applyFilter()
        } else {
            adapter.notifyItemChanged(position)
        }
    }
}
