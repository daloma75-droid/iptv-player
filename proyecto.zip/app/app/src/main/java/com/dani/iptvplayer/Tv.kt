package com.dani.iptvplayer

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.widget.Toast

/** Utilidades para Android TV y TV box. */
object Tv {
    fun isTv(ctx: Context): Boolean = try {
        val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            ctx.packageManager.hasSystemFeature("android.software.leanback")
    } catch (e: Exception) {
        false
    }

    /** En TV se ve desde lejos: se amplía el texto un 20 % (si el usuario no lo ha ampliado ya). */
    fun wrap(base: Context): Context {
        if (!isTv(base)) return base
        val cfg = Configuration(base.resources.configuration)
        if (cfg.fontScale >= 1.2f) return base
        cfg.fontScale = 1.2f
        return base.createConfigurationContext(cfg)
    }

    /** Avisa una sola vez de cómo abrir el menú de un título con el mando (mantener OK). */
    fun showLongPressHint(ctx: Context) {
        if (!isTv(ctx)) return
        val p = Repo.prefs(ctx)
        if (p.getBoolean("tv_hint_shown", false)) return
        p.edit().putBoolean("tv_hint_shown", true).apply()
        Toast.makeText(ctx, "Mantén pulsado OK sobre un título para ver más opciones", Toast.LENGTH_LONG).show()
    }
}
