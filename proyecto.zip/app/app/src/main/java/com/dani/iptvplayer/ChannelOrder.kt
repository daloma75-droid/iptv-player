package com.dani.iptvplayer

import android.widget.ImageView
import coil.load
import java.text.Normalizer

/**
 * Orden de la TV en directo: primero las cadenas nacionales principales (La 1, La 2, Antena 3,
 * Cuatro, Telecinco, laSexta…), después los canales de Movistar Plus+ y, por último, el resto
 * en el orden original de la lista. También sabe qué logotipo corresponde a cada canal conocido.
 */
object ChannelOrder {

    private const val LOGO_BASE =
        "https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/spain/"

    private class Nat(val aliases: List<String>, val logo: String)

    /** Cadenas nacionales, en el orden en que deben aparecer. */
    private val national: List<Nat> = listOf(
        Nat(listOf("la 1", "la1", "tve 1", "tve1", "tve la 1", "la 1 tve", "tve", "tve hd"), "tve-1-es.png"),
        Nat(listOf("la 2", "la2", "tve 2", "tve2", "la 2 tve", "tve la 2"), "tve-2-es.png"),
        Nat(listOf("antena 3", "antena3", "a3", "antena 3 tv", "antena 3 tdt"), "antena-3-es.png"),
        Nat(listOf("cuatro", "cuatro tv"), "cuatro-es.png"),
        Nat(listOf("telecinco", "tele 5", "tele5", "telecinco tv", "t5"), "telecinco-es.png"),
        Nat(listOf("lasexta", "la sexta", "la sexta tv", "sexta"), "lasexta-es.png"),
        Nat(listOf("24h", "24 h", "24 horas", "canal 24 horas", "canal 24h", "24h tve"), "24h-es.png"),
        Nat(listOf("clan", "clan tve", "clan tv"), "clan-es.png"),
        Nat(listOf("teledeporte", "tdp", "teledeporte tve"), "tdp-es.png"),
        Nat(listOf("neox"), "neox-es.png"),
        Nat(listOf("nova"), "nova-es.png"),
        Nat(listOf("mega"), "mega-es.png"),
        Nat(listOf("atreseries", "atres series"), "atreseries-es.png"),
        Nat(listOf("fdf", "factoria de ficcion"), "fdf-es.png"),
        Nat(listOf("energy"), "energy-es.png"),
        Nat(listOf("divinity"), "divinity-es.png"),
        Nat(listOf("boing"), "boing-es.png"),
        Nat(listOf("paramount network", "paramount"), "paramount-network-es.png"),
        Nat(listOf("dmax", "d max"), "dmax-es.png"),
        Nat(listOf("be mad", "bemad", "be mad tv"), "be-mad-tv-es.png"),
        Nat(listOf("ten", "ten tv"), "ten-es.png"),
        Nat(listOf("dkiss", "d kiss"), "dkiss-es.png"),
        Nat(listOf("real madrid tv", "real madrid"), "real-madrid-tv-es.png"),
        Nat(listOf("gol", "gol tv"), "gol-es.png"),
        Nat(listOf("trece", "13tv", "13 tv"), "trece-es.png"),
        Nat(listOf("disney channel"), "disney-channel-es.png")
    )

    private val nationalIndex: Map<String, Int> = HashMap<String, Int>().also { m ->
        national.forEachIndexed { i, n -> n.aliases.forEach { m[it] = i } }
    }

    /** Logotipos de Movistar Plus+ que existen en el repositorio de logos (sin "-por-movistar-plus-es.png"). */
    private val movistarLogos: Set<String> = setOf(
        "accion", "cine-espanol", "cine", "clasicos", "comedia", "deportes-2", "deportes-3", "deportes-4", 
        "deportes-5", "deportes-6", "deportes-7", "deportes-8", "deportes", "documentales", "drama", 
        "ellas-vamos", "golf-2", "golf", "indie", "laliga-hdr-2", "laliga-hdr", "laliga-tv-2", 
        "laliga-tv-3", "laliga-tv-4", "laliga-tv-5", "laliga-tv-6", "laliga-tv-7", "laliga-tv", 
        "laliga-tv-uhd", "liga-de-campeones-10", "liga-de-campeones-11", "liga-de-campeones-12", 
        "liga-de-campeones-13", "liga-de-campeones-14", "liga-de-campeones-15", "liga-de-campeones-16", 
        "liga-de-campeones-17", "liga-de-campeones-2-hdr", "liga-de-campeones-2-uhd", 
        "liga-de-campeones-3", "liga-de-campeones-4", "liga-de-campeones-5", "liga-de-campeones-6", 
        "liga-de-campeones-7", "liga-de-campeones-8", "liga-de-campeones-9", "liga-de-campeones-hdr", 
        "liga-de-campeones", "liga-de-campeones-uhd", "musica", "originales", "series", "suspense", 
        "vamos", 
    )

    private val qualityTokens = setOf(
        "hd", "fhd", "uhd", "sd", "4k", "h265", "h264", "hevc", "1080p", "720p", "1080", "720", "50fps", "60fps",
        "raw", "backup", "es", "esp", "spa", "sp", "tdt", "dir"
    )

    /** Prefijo de país al principio del nombre: «ES| », «ES: », «[ES] », «ES - »… */
    private val countryPrefix = Regex("^\\s*[\\[(|]*\\s*(es|esp|spa|spain|espana|españa)\\s*[\\])|:\\-–]+\\s*", RegexOption.IGNORE_CASE)

    // ---------------------------------------------------------------- normalización

    private fun stripAccents(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    /** Minúsculas, sin acentos, sin símbolos; separa en palabras. */
    private fun tokens(raw: String): List<String> =
        stripAccents(raw.lowercase())
            .replace(Regex("[\\[(].*?[\\])]"), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .split(' ')
            .filter { it.isNotEmpty() }

    /** Nombre limpio: sin prefijo de país ni etiquetas de calidad. */
    private fun clean(name: String): String {
        val t = tokens(name).toMutableList()
        while (t.isNotEmpty() && t.first() in setOf("es", "esp", "spa", "sp", "spain", "espana")) t.removeAt(0)
        return t.filter { it !in qualityTokens }.joinToString(" ")
    }

    private fun isMovistar(c: Channel): Boolean {
        val n = c.name.replace(countryPrefix, "").trim().lowercase()
        if ("movistar" in n) return true
        if (n.startsWith("m+") || n.startsWith("#0") || n.startsWith("#vamos") || n.startsWith("m. ")) return true
        return "movistar" in c.group.lowercase()
    }

    // ---------------------------------------------------------------- Movistar

    private fun movistarSlug(c: Channel): String {
        val t = tokens(c.name.replace("+", " ").replace("#", " "))
            .filter { it !in qualityTokens && it != "movistar" && it != "plus" && it != "m" && it != "por" }
        return t.joinToString("-")
    }

    private fun movistarLogoSlug(slug: String): String? {
        if (slug.isEmpty() || slug == "0" || slug == "lite") return "movistar-plus-es.png"
        val candidates = listOf(
            slug,
            slug.removeSuffix("-1"),
            slug.replace(Regex("^laliga(?!-tv|-hdr)"), "laliga-tv"),
            slug.replace(Regex("^laliga(?!-tv|-hdr)"), "laliga-tv").removeSuffix("-1"),
            slug.replace("champions-league", "liga-de-campeones").replace("champions", "liga-de-campeones")
        )
        for (cand in candidates) if (cand in movistarLogos) return "$cand-por-movistar-plus-es.png"
        return null
    }

    private fun movistarSub(slug: String): Int = when {
        slug.isEmpty() || slug == "0" || slug == "lite" -> 0
        slug.startsWith("liga-de-campeones") || slug.startsWith("champions") -> 1
        slug.startsWith("laliga") -> 2
        slug.startsWith("deportes") -> 3
        slug.contains("vamos") -> 4
        slug.startsWith("series") -> 5
        slug.startsWith("originales") || slug.startsWith("estrenos") -> 6
        slug.startsWith("cine") || slug.startsWith("clasicos") -> 7
        slug.startsWith("comedia") || slug.startsWith("drama") || slug.startsWith("accion") ||
            slug.startsWith("indie") || slug.startsWith("suspense") -> 8
        slug.startsWith("documentales") -> 9
        slug.startsWith("golf") -> 10
        slug.startsWith("musica") -> 11
        else -> 50
    }

    private fun trailingNumber(slug: String): Int =
        Regex("(\\d+)(?:-[a-z]+)*$").find(slug)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    // ---------------------------------------------------------------- API pública

    /** Clave de ordenación: (nivel, subnivel, número). Nivel 0 = nacional, 1 = Movistar, 2 = resto. */
    private data class Key(val tier: Int, val sub: Int, val num: Int)

    private fun key(c: Channel): Key {
        if (isMovistar(c)) {
            val slug = movistarSlug(c)
            return Key(1, movistarSub(slug), trailingNumber(slug))
        }
        val idx = nationalIndex[clean(c.name)]
        return if (idx != null) Key(0, idx, 0) else Key(2, 0, 0)
    }

    /** Nivel de un canal: 0 = nacional principal, 1 = Movistar, 2 = resto. */
    fun tier(c: Channel): Int = key(c).tier

    private val fhdRegex = Regex("\\b(fhd|full ?hd|1080[pi]?)\\b")
    private val uhdRegex = Regex("\\b(uhd|4k)\\b")
    private val hdRegex = Regex("\\b(hd|720p?)\\b")

    /** Calidad según el nombre: 3 = Full HD, 2 = UHD/4K, 1 = HD, 0 = sin indicar o SD. */
    private fun quality(name: String): Int {
        val n = name.lowercase()
        return when {
            fhdRegex.containsMatchIn(n) -> 3
            uhdRegex.containsMatchIn(n) -> 2
            hdRegex.containsMatchIn(n) -> 1
            else -> 0
        }
    }

    /** Identifica "el mismo canal" aunque venga repetido en varias calidades; null si no se puede saber. */
    private fun sameChannelKey(c: Channel, k: Key): String? = when (k.tier) {
        0 -> "n${k.sub}"
        1 -> "m" + movistarSlug(c)
        else -> clean(c.name).ifEmpty { null }?.let { "o$it" }
    }

    /**
     * Ordena canales en directo: nacionales, luego Movistar, luego el resto (orden original, con los Full HD primero).
     * Si un canal está repetido (SD, HD, FHD…), solo se deja la mejor versión, prefiriendo Full HD.
     */
    fun sortLive(list: List<Channel>): List<Channel> {
        val keyed = list.map { it to key(it) }
        // Mejor versión de cada canal repetido
        val best = HashMap<String, Pair<Channel, Int>>()
        for ((c, k) in keyed) {
            val id = sameChannelKey(c, k) ?: continue
            val q = quality(c.name)
            val cur = best[id]
            if (cur == null || q > cur.second) best[id] = c to q
        }
        val kept = keyed.filter { (c, k) ->
            val id = sameChannelKey(c, k)
            id == null || best[id]?.first === c
        }
        return kept
            .sortedWith(
                compareBy<Pair<Channel, Key>>({ it.second.tier }, { it.second.sub }, { it.second.num })
                    .thenByDescending { if (it.second.tier == 2) quality(it.first.name) else 0 }
            )
            .map { it.first }
    }

    /** Ordena las categorías: primero las que contienen nacionales, luego las de Movistar, luego el resto. */
    fun sortGroups(groups: List<String>, channels: List<Channel>): List<String> {
        val best = HashMap<String, Int>()
        for (c in channels) {
            val k = key(c)
            // Para las categorías solo cuentan las 10 cadenas nacionales principales
            var t = if (k.tier == 0 && k.sub >= 10) 2 else k.tier
            if ("movistar" in c.group.lowercase()) t = minOf(t, 1)
            val old = best[c.group]
            if (old == null || t < old) best[c.group] = t
        }
        return groups.sortedBy { best[it] ?: 2 }
    }

    private fun fileSlug(alias: String): String =
        stripAccents(alias.lowercase()).replace(Regex("[^a-z0-9]+"), "-").trim('-')

    /**
     * URLs de logotipo oficial por orden de preferencia (vacío si no reconocemos el canal).
     * En las nacionales se prueban también los nombres de archivo habituales del repositorio,
     * por si el principal no existe: el cargador pasa al siguiente si uno da error.
     */
    fun logoCandidates(c: Channel): List<String> {
        if (c.type != ContentType.LIVE) return emptyList()
        if (isMovistar(c)) return movistarLogoSlug(movistarSlug(c))?.let { listOf(LOGO_BASE + it) } ?: emptyList()
        val idx = nationalIndex[clean(c.name)] ?: return emptyList()
        val n = national[idx]
        val files = LinkedHashSet<String>()
        files.add(n.logo)
        for (a in n.aliases.take(3)) files.add(fileSlug(a) + "-es.png")
        return files.take(4).map { LOGO_BASE + it }
    }

    /** URL del logotipo oficial si reconocemos el canal; null si no. */
    fun logoUrl(c: Channel): String? = logoCandidates(c).firstOrNull()
}

/** Carga el logotipo de un canal: el oficial si lo conocemos y, si falla, el de la lista. */
object Logos {
    fun load(iv: ImageView, c: Channel, placeholder: Int = R.drawable.ic_tv, fade: Boolean = false) {
        val chain = ArrayList<String>(ChannelOrder.logoCandidates(c))
        if (c.logo.isNotEmpty()) chain.add(c.logo)
        val token = c.key
        iv.tag = token
        if (chain.isEmpty()) {
            iv.load(placeholder)
            return
        }
        step(iv, chain, 0, token, placeholder, fade)
    }

    /** Prueba la URL número [i]; si da error pasa a la siguiente. */
    private fun step(iv: ImageView, chain: List<String>, i: Int, token: String, placeholder: Int, fade: Boolean) {
        if (iv.tag != token || i >= chain.size) return
        iv.load(chain[i]) {
            crossfade(fade)
            placeholder(placeholder)
            error(placeholder)
            listener(onError = { _, _ -> iv.post { step(iv, chain, i + 1, token, placeholder, fade) } })
        }
    }
}
