package com.dani.iptvplayer

import android.content.Context
import org.json.JSONObject

enum class ContentType { LIVE, MOVIE, SERIES }

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String,
    val userAgent: String = "",
    val headers: Map<String, String> = emptyMap(),
    val type: ContentType = ContentType.LIVE,
    /** Solo para series de Xtream: los episodios se piden aparte con este id. */
    val seriesId: String = "",
    /** Fecha (segundos Unix) en que el servidor añadió el título; 0 si no se sabe. Sirve para ordenar por novedades. */
    val added: Long = 0L,
    /** Fecha de estreno (segundos Unix) si el servidor la da; 0 si no se sabe. */
    val released: Long = 0L
) {
    /** Clave estable para favoritos. */
    val key: String get() = if (seriesId.isNotEmpty()) "s:$seriesId" else url
}

/** Lista actual (ya filtrada) que se comparte entre la pantalla de exploración y el reproductor. */
object Playlist {
    var channels: List<Channel> = emptyList()
    var index: Int = 0

    private const val LAST = "last_channel"

    /** Guarda el título que se está reproduciendo para poder reabrirlo si Android mata el proceso. */
    fun remember(ctx: Context, c: Channel) {
        try {
            val o = JSONObject()
                .put("name", c.name).put("url", c.url).put("group", c.group).put("logo", c.logo)
                .put("ua", c.userAgent).put("type", c.type.name).put("seriesId", c.seriesId)
                .put("added", c.added).put("released", c.released)
                .put("headers", JSONObject(c.headers as Map<*, *>))
            Repo.prefs(ctx).edit().putString(LAST, o.toString()).apply()
        } catch (e: Exception) {
            // no es crítico
        }
    }

    /** Si la lista se perdió (proceso reiniciado), la recompone con el último título reproducido. */
    fun restoreIfEmpty(ctx: Context) {
        if (channels.isNotEmpty()) return
        try {
            val txt = Repo.prefs(ctx).getString(LAST, null) ?: return
            val o = JSONObject(txt)
            val h = LinkedHashMap<String, String>()
            val ho = o.optJSONObject("headers")
            if (ho != null) for (k in ho.keys()) h[k] = ho.optString(k)
            channels = listOf(
                Channel(
                    name = o.optString("name"), url = o.optString("url"),
                    group = o.optString("group"), logo = o.optString("logo"),
                    userAgent = o.optString("ua"), headers = h,
                    type = runCatching { ContentType.valueOf(o.optString("type")) }.getOrDefault(ContentType.LIVE),
                    seriesId = o.optString("seriesId"),
                    added = o.optLong("added"), released = o.optLong("released")
                )
            )
            index = 0
        } catch (e: Exception) {
            // sin último canal
        }
    }
}

/** Decide si una entrada de una lista M3U es TV en directo, película o serie. */
object Classifier {
    private val vodExt = setOf("mkv", "mp4", "avi", "mov", "m4v", "wmv", "flv", "webm")
    private val seriesWords = listOf("serie", "season", "temporada", "novela")
    private val movieWords = listOf("pelicula", "película", "pelis", "movie", "film", "vod")

    fun classify(url: String, group: String): ContentType {
        val u = url.substringBefore('?').lowercase()
        if (u.contains("/series/")) return ContentType.SERIES
        if (u.contains("/movie/")) return ContentType.MOVIE
        if (u.contains("/live/")) return ContentType.LIVE

        val file = u.substringAfterLast('/')
        val ext = if (file.contains('.')) file.substringAfterLast('.') else ""
        val g = group.lowercase()
        val seriesGroup = seriesWords.any { g.contains(it) }

        if (ext in vodExt) return if (seriesGroup) ContentType.SERIES else ContentType.MOVIE
        if (ext == "m3u8" || ext == "ts") return ContentType.LIVE
        if (seriesGroup) return ContentType.SERIES
        if (movieWords.any { g.contains(it) }) return ContentType.MOVIE
        return ContentType.LIVE
    }
}
