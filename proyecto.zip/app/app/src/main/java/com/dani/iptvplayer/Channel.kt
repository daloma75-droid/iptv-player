package com.dani.iptvplayer

enum class ContentType { LIVE, MOVIE, SERIES }

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String,
    val userAgent: String = "",
    val headers: Map<String, String> = emptyMap(),
    val type: ContentType = ContentType.LIVE,
    /** Solo para series de Xtream: los episodios se piden aparte con este id. */
    val seriesId: String = "",
    /** Fecha de incorporación al catálogo (epoch ms); 0 si la lista no la facilita. */
    val addedAt: Long = 0L
) {
    /** Clave estable para favoritos. */
    val key: String get() = if (seriesId.isNotEmpty()) "s:$seriesId" else url
}

/** Lista actual (ya filtrada) que se comparte entre la pantalla de exploración y el reproductor. */
object Playlist {
    var channels: List<Channel> = emptyList()
    var index: Int = 0
}

/** Decide si una entrada de una lista M3U es TV en directo, película o serie. */
object Classifier {
    private val vodExt = setOf("mkv", "mp4", "avi", "mov", "m4v", "wmv", "flv", "webm")
    private val seriesWords = listOf("serie", "season", "temporada", "novela")
    private val movieWords = listOf("pelicula", "película", "pelis", "movie", "film", "vod")

    fun classify(url: String, group: String): ContentType {
        val u = url.substringBefore('?').lowercase()
        if (u.contains("/series/")) return ContentType.SERIES
        if (u.contains("/movie/")) return ContentType.MOVIE
        if (u.contains("/live/")) return ContentType.LIVE

        val file = u.substringAfterLast('/')
        val ext = if (file.contains('.')) file.substringAfterLast('.') else ""
        val g = group.lowercase()
        val seriesGroup = seriesWords.any { g.contains(it) }

        if (ext in vodExt) return if (seriesGroup) ContentType.SERIES else ContentType.MOVIE
        if (ext == "m3u8" || ext == "ts") return ContentType.LIVE
        if (seriesGroup) return ContentType.SERIES
        if (movieWords.any { g.contains(it) }) return ContentType.MOVIE
        return ContentType.LIVE
    }
}


/** Convierte fechas de alta de Xtream/M3U a milisegundos Unix. */
object ContentDate {
    fun parse(raw: String?): Long {
        val value = raw?.trim().orEmpty()
        if (value.isEmpty() || value.equals("null", true) || value == "0") return 0L
        value.toLongOrNull()?.let { n ->
            return when { n <= 0L -> 0L; n < 100000000000L -> n * 1000L; else -> n }
        }
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "dd-MM-yyyy", "dd/MM/yyyy", "MM/dd/yyyy"
        )
        for (pattern in patterns) {
            try {
                val format = java.text.SimpleDateFormat(pattern, java.util.Locale.US)
                format.isLenient = false
                format.timeZone = java.util.TimeZone.getTimeZone("UTC")
                val date = format.parse(value)
                if (date != null) return date.time
            } catch (_: Exception) { }
        }
        return 0L
    }
}
