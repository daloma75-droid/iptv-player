package com.dani.iptvplayer

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String,
    val userAgent: String = "",
    val headers: Map<String, String> = emptyMap()
)

/** Lista actual (ya filtrada) que se comparte entre la pantalla principal y el reproductor. */
object Playlist {
    var channels: List<Channel> = emptyList()
    var index: Int = 0
}
