package com.dani.iptvplayer

enum class ContentType { LIVE, MOVIE, SERIES }

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String,
    val userAgent: String = "",
    val headers: Map<String, String> = emptyMap(),
    val type: ContentType = ContentType.LIVE,
    /** Solo para series de Xtream: los episodios se piden aparte con este id. */
    val seriesId: String = "",
    /** Fecha (segundos Unix) en que el servidor añadió el título; 0 si no se sabe. Sirve para ordenar por novedades. */
    val added: Long = 0L
) {
    /** Clave estable para favoritos. */
    val key: String get() = if (seriesId.isNotEmpty()) "s:$seriesId" else url
}

/** Lista actual (ya filtrada) que se comparte entre la pantalla de exploración y el reproductor. */
object Playlist {
    var channels: List<Channel> = emptyList()
    var index: Int = 0
}

/** Decide si una entrada de una lista M3U es TV en directo, película o serie. */
object Classifier {
    private val vodExt = setOf("mkv", "mp4", "avi", "mov", "m4v", "wmv", "flv", "webm")
    private val seriesWords = listOf("serie", "season", "temporada", "novela")
    private val movieWords = listOf("pelicula", "película", "pelis", "movie", "film", "vod")

    fun classify(url: String, group: String): ContentType {
        val u = url.substringBefore('?').lowercase()
        if (u.contains("/series/")) return ContentType.SERIES
        if (u.contains("/movie/")) return ContentType.MOVIE
        if (u.contains("/live/")) return ContentType.LIVE

        val file = u.substringAfterLast('/')
        val ext = if (file.contains('.')) file.substringAfterLast('.') else ""
        val g = group.lowercase()
        val seriesGroup = seriesWords.any { g.contains(it) }

        if (ext in vodExt) return if (seriesGroup) ContentType.SERIES else ContentType.MOVIE
        if (ext == "m3u8" || ext == "ts") return ContentType.LIVE
        if (seriesGroup) return ContentType.SERIES
        if (movieWords.any { g.contains(it) }) return ContentType.MOVIE
        return ContentType.LIVE
    }
}
