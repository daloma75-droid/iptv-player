package com.dani.iptvplayer

/**
 * Orden por novedades (lo más nuevo primero) para películas y series.
 * Usa la fecha en que el servidor Xtream añadió el título; si no la hay, el año del nombre
 * («Título (2024)»); si tampoco, el elemento conserva su sitio al final, en el orden de la lista.
 */
object Newest {
    private val yearRegex = Regex("(?<!\\d)((?:19[5-9]|20[0-3])\\d)(?!\\d)")
    private const val SECONDS_PER_YEAR = 31_556_952L

    /** Marca de tiempo (segundos) para ordenar; 0 si no se sabe. */
    fun recency(c: Channel): Long {
        if (c.added > 0L) return c.added
        val y = yearRegex.findAll(c.name).lastOrNull()?.value?.toIntOrNull() ?: return 0L
        return (y - 1970) * SECONDS_PER_YEAR
    }

    /** Más nuevo primero. La ordenación es estable: lo que no tiene fecha mantiene su orden. */
    fun sort(list: List<Channel>): List<Channel> = list.sortedByDescending { recency(it) }

    fun hasDates(list: List<Channel>): Boolean = list.any { recency(it) > 0L }

    /** Categorías ordenadas por su elemento más reciente (las más nuevas primero). */
    fun sortGroups(groups: List<String>, list: List<Channel>): List<String> {
        val newest = HashMap<String, Long>()
        for (c in list) {
            val r = recency(c)
            val old = newest[c.group]
            if (old == null || r > old) newest[c.group] = r
        }
        return groups.sortedByDescending { newest[it] ?: 0L }
    }
}
