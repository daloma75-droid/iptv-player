package com.dani.iptvplayer

/**
 * Orden por novedades (lo más nuevo primero) para películas y series.
 * Usa la fecha en que el servidor Xtream añadió el título; si no la hay, el año del nombre
 * («Título (2024)»); si tampoco, el elemento conserva su sitio al final, en el orden de la lista.
 */
object Newest {
    private val yearRegex = Regex("(?<!\\d)((?:19[5-9]|20[0-3])\\d)(?!\\d)")
    private const val SECONDS_PER_YEAR = 31_556_952L

    /** Fecha de estreno (segundos) para ordenar: la del servidor, si no el año del título, si no 0. */
    fun recency(c: Channel, now: Long = System.currentTimeMillis() / 1000): Long {
        if (c.released > 0L) return minOf(c.released, now)
        val y = yearRegex.findAll(c.name).lastOrNull()?.value?.toIntOrNull() ?: return 0L
        return minOf((y - 1970) * SECONDS_PER_YEAR, now)
    }

    /**
     * Más estrenado primero; a igual fecha, el añadido más tarde al servidor. Estable para lo que no tiene fecha.
     * La fecha se calcula una sola vez por elemento (las listas pueden tener decenas de miles).
     */
    fun sort(list: List<Channel>): List<Channel> {
        val now = System.currentTimeMillis() / 1000
        return list.map { Triple(it, recency(it, now), it.added) }
            .sortedWith(compareByDescending<Triple<Channel, Long, Long>> { it.second }.thenByDescending { it.third })
            .map { it.first }
    }

    fun hasDates(list: List<Channel>): Boolean = list.any { recency(it) > 0L }

    /** Categorías ordenadas por su elemento más reciente (las más nuevas primero). */
    fun sortGroups(groups: List<String>, list: List<Channel>): List<String> {
        val newest = HashMap<String, Long>()
        for (c in list) {
            val r = recency(c)
            val old = newest[c.group]
            if (old == null || r > old) newest[c.group] = r
        }
        return groups.sortedByDescending { newest[it] ?: 0L }
    }
}
