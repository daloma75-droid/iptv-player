package com.dani.iptvplayer

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView

/** Inicio con estilo de plataforma de streaming: banner, filas por categoría y barra inferior. */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var statusRow: View
    private lateinit var progress: ProgressBar
    private lateinit var rows: LinearLayout
    private lateinit var hero: RecyclerView
    private lateinit var dots: LinearLayout
    private lateinit var emptyState: View
    private lateinit var vpnOverlay: View

    private val snap = PagerSnapHelper()
    private val favorites = mutableSetOf<String>()
    private var lastSig = ""
    private var autoChecked = false
    private var langChecked = false
    private var activeDot = -1

    private val handler = Handler(Looper.getMainLooper())
    private val vpnPoll = Runnable { checkVpn() }

    /** Al conectar o quitar la VPN se redibuja el inicio para volver a pedir las carátulas. */
    private val netChanged = Runnable { refreshHome(true) }
    private var seenEpoch = Net.epoch
    private var lastVpnState: Boolean? = null

    private val pickWgConf =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importWgFromUri(uri)
        }

    /** Permiso de VPN del sistema (Android lo pide una sola vez). */
    private val wgConsent =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            // Algunos móviles devuelven "cancelado" aunque el permiso sí se haya concedido: se vuelve a comprobar
            if (result.resultCode == RESULT_OK || android.net.VpnService.prepare(this) == null) {
                connectWg()
            } else {
                showWgDenied()
            }
        }

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadFromUri(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Repo.prefs(this)

        status = findViewById(R.id.status)
        statusRow = findViewById(R.id.statusRow)
        progress = findViewById(R.id.progress)
        rows = findViewById(R.id.rows)
        hero = findViewById(R.id.hero)
        dots = findViewById(R.id.dots)
        emptyState = findViewById(R.id.emptyState)
        vpnOverlay = findViewById(R.id.vpnOverlay)
        findViewById<View>(R.id.btnVpnOpen).setOnClickListener {
            if (WgVpn.hasConfig(this)) startWg() else Vpn.openProton(this)
        }
        findViewById<View>(R.id.btnVpnSetup).setOnClickListener { showWgMenu() }
        findViewById<View>(R.id.btnVpnAlways).setOnClickListener { Vpn.openAlwaysOnSettings(this) }
        findViewById<View>(R.id.btnVpnSkip).setOnClickListener {
            Vpn.bypass = true
            checkVpn()
        }

        hero.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        snap.attachToRecyclerView(hero)
        hero.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) = updateDots()
        })

        findViewById<View>(R.id.chipMovies).setOnClickListener { openSection("movie") }
        findViewById<View>(R.id.chipSeries).setOnClickListener { openSection("series") }
        findViewById<View>(R.id.chipLive).setOnClickListener { openSection("live") }
        findViewById<View>(R.id.chipFav).setOnClickListener { openSection("fav") }
        findViewById<View>(R.id.btnLists).setOnClickListener { showMenu() }
        findViewById<View>(R.id.btnUpdate).setOnClickListener { updateEverything() }
        findViewById<View>(R.id.btnVpnToggle).setOnClickListener { vpnButton() }
        findViewById<View>(R.id.btnExit).setOnClickListener { confirmExit() }
        findViewById<View>(R.id.btnEmptyAdd).setOnClickListener { showAddDialog() }

        BottomNav.setup(this, R.id.navHome)

        if (Repo.all.isEmpty()) {
            showStatus("Cargando…")
            Thread {
                val ok = Repo.loadCache(this)
                runOnUiThread {
                    showStatus("")
                    refreshHome(true)
                    if (!ok) showAddDialog() else {
                        maybeAutoRefresh()
                        maybeAskLanguages()
                    }
                }
            }.start()
        } else {
            refreshHome(true)
        }
    }

    override fun onResume() {
        super.onResume()
        Net.addListener(netChanged)
        if (seenEpoch != Net.epoch) {
            seenEpoch = Net.epoch
            refreshHome(true)
        }
        checkVpn()
        refreshHome(false)
        maybeAutoRefresh()
        maybeAskLanguages()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(vpnPoll)
        Net.removeListener(netChanged)
    }

    // ---------- VPN ----------

    /** Si hace falta VPN y no hay ninguna activa, tapa la app y espera a que se conecte. */
    private fun checkVpn() {
        handler.removeCallbacks(vpnPoll)
        updateVpnButton()
        val vpnNow = Vpn.isActive(this)
        if (lastVpnState != null && lastVpnState != vpnNow) {
            // La VPN acaba de conectarse o caer: las conexiones viejas no sirven y las portadas fallidas se repiten
            Net.onNetworkChanged(vpnNow)   // avisa por netChanged y se redibuja el inicio
        }
        lastVpnState = vpnNow
        if (Vpn.blocked(this)) {
            val first = vpnOverlay.visibility != View.VISIBLE
            vpnOverlay.visibility = View.VISIBLE
            val wg = WgVpn.hasConfig(this)
            findViewById<TextView>(R.id.btnVpnOpen).text = if (wg) "Conectar la VPN" else "Abrir Proton VPN"
            findViewById<TextView>(R.id.vpnMsg).text =
                if (wg) "Pulsa «Conectar la VPN» para activarla directamente. La app continuará sola en cuanto esté conectada."
                else "Para proteger tu conexión, abre Proton VPN y conéctate, o configura una VPN propia con WireGuard para que se active directamente. La app continuará sola en cuanto detecte la VPN."
            if (first) findViewById<View>(R.id.btnVpnOpen).requestFocus()
            if (!Vpn.autoOpened) {
                Vpn.autoOpened = true
                if (wg) askConnectWg() else Vpn.openProton(this)
            }
            handler.postDelayed(vpnPoll, 1500)
        } else {
            vpnOverlay.visibility = View.GONE
            if (!Vpn.autoOpened && WgVpn.hasConfig(this) && WgVpn.askAtStart(this) && !Vpn.isActive(this)) {
                Vpn.autoOpened = true
                askConnectWg()
            }
            maybeAutoRefresh()
            maybeAskLanguages()
        }
    }

    /** La primera vez que hay una lista cargada, pregunta qué idiomas se quieren ver. */
    private fun maybeAskLanguages() {
        if (langChecked || Repo.all.isEmpty() || Vpn.blocked(this) || Parental.langAsked(this)) return
        langChecked = true
        LangPicker.start(this, true) { refreshHome(true) }
    }

    /**
     * Actualiza la lista sola si toca (por defecto cada 3 días). Se comprueba una vez por arranque
     * y espera a que la VPN esté lista para no descargar sin protección.
     */
    private fun maybeAutoRefresh() {
        if (autoChecked || Repo.all.isEmpty() || Vpn.blocked(this)) return
        autoChecked = true
        if (!Repo.updateDue(this) && !Repo.needsDates(this)) return
        if (progress.visibility == View.VISIBLE) return
        runLoad { report ->
            report("Actualizando la lista automáticamente…")
            Repo.refresh(this, report)
        }
    }

    // ---------- Inicio ----------

    private fun showStatus(msg: String) {
        status.text = msg
        statusRow.visibility =
            if (msg.isEmpty() && progress.visibility != View.VISIBLE) View.GONE else View.VISIBLE
    }

    /** Redibuja el inicio solo si cambió algo (lista, favoritos o "seguir viendo"). */
    private fun refreshHome(force: Boolean) {
        favorites.clear()
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
        val sig = "${Repo.all.size}|${Recents.signature(this)}|${favorites.hashCode()}|${Parental.stateKey(this)}"
        if (!force && sig == lastSig) return
        lastSig = sig
        buildHome()
    }

    private fun buildHome() {
        rows.removeAllViews()
        val all = Repo.all
        if (all.isEmpty()) {
            emptyState.visibility = View.VISIBLE
            hero.visibility = View.GONE
            dots.visibility = View.GONE
            return
        }
        emptyState.visibility = View.GONE

        // Sin contenido adulto ni categorías bloqueadas
        val content = Parental.openList(this)
        val live = ChannelOrder.sortLive(content.filter { it.type == ContentType.LIVE })
        // Películas y series: lo más nuevo primero (las categorías salen ordenadas por su título más reciente)
        val movies = Newest.sort(content.filter { it.type == ContentType.MOVIE })
        val series = Newest.sort(content.filter { it.type == ContentType.SERIES })

        // Banner destacado: hasta 5 títulos repartidos por la lista
        val pool = movies.filter { it.logo.isNotEmpty() }
            .ifEmpty { series.filter { it.logo.isNotEmpty() } }
            .ifEmpty { live.filter { it.logo.isNotEmpty() } }
        if (pool.isEmpty()) {
            hero.visibility = View.GONE
            dots.visibility = View.GONE
        } else {
            val n = minOf(5, pool.size)
            val step = pool.size / n
            // Con fechas, el banner enseña las 5 novedades; sin ellas, 5 títulos repartidos por la lista
            val featured = if (Newest.hasDates(pool)) pool.take(n) else (0 until n).map { pool[it * step] }
            hero.visibility = View.VISIBLE
            dots.visibility = if (n > 1) View.VISIBLE else View.GONE
            hero.adapter = HeroAdapter(featured) { pos -> openItem(featured, pos) }
            hero.scrollToPosition(0)
            buildDots(n)
        }

        val recents = Recents.load(this).filter { Parental.allowed(this, it.channel) }
        if (recents.isNotEmpty()) {
            addRow("Seguir viendo", CardKind.CONTINUE, recents.map { it.channel }, recents, null, null)
        }
        val favs = content.filter { it.key in favorites }
        if (favs.isNotEmpty()) {
            addRow("Mi lista", CardKind.POSTER, favs.take(30), null, "fav", null)
        }
        if (live.isNotEmpty()) {
            addRow("TV en directo", CardKind.LIVE, live.take(30), null, "live", null)
        }
        // Novedades: películas y series juntas, por fecha de estreno
        val novelties = Newest.sort(movies + series)
        if (Newest.hasDates(novelties)) addRow("Novedades · Películas y series", CardKind.POSTER, novelties.take(40), null, null, null)
        addGroupRows(movies, "movie", "Películas", 6)
        addGroupRows(series, "series", "Series", 4)
    }

    private fun addGroupRows(list: List<Channel>, section: String, defaultTitle: String, maxRows: Int) {
        if (list.isEmpty()) return
        val groups = LinkedHashMap<String, MutableList<Channel>>()
        for (c in list) groups.getOrPut(c.group) { ArrayList() }.add(c)
        var n = 0
        for ((g, items) in groups) {
            if (n >= maxRows) break
            if (items.size < 3) continue
            addRow(g.ifEmpty { defaultTitle }, CardKind.POSTER, items.take(30), null, section, g)
            n++
        }
        if (n == 0) {
            addRow(defaultTitle, CardKind.POSTER, list.take(30), null, section, null)
        }
    }

    private fun addRow(
        title: String,
        kind: CardKind,
        list: List<Channel>,
        entries: List<Recents.Entry>?,
        section: String?,
        group: String?
    ) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_row, rows, false)
        row.findViewById<TextView>(R.id.rowTitle).text = title
        val header = row.findViewById<View>(R.id.rowHeader)
        if (section == null) {
            row.findViewById<View>(R.id.rowMore).visibility = View.GONE
            header.isFocusable = false
            header.isClickable = false
        } else {
            header.setOnClickListener { openSection(section, group) }
        }
        val rv = row.findViewById<RecyclerView>(R.id.rowList)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv.adapter = CardAdapter(kind, list, favorites, entries) { pos -> openItem(list, pos) }
        rows.addView(row)
    }

    private fun buildDots(n: Int) {
        dots.removeAllViews()
        val d = resources.displayMetrics.density
        for (i in 0 until n) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams((6 * d).toInt(), (6 * d).toInt())
            lp.marginStart = (4 * d).toInt()
            lp.marginEnd = (4 * d).toInt()
            v.layoutParams = lp
            dots.addView(v)
        }
        activeDot = -1
        setActiveDot(0)
    }

    private fun setActiveDot(active: Int) {
        if (active == activeDot) return
        activeDot = active
        val d = resources.displayMetrics.density
        for (i in 0 until dots.childCount) {
            val v = dots.getChildAt(i)
            val lp = v.layoutParams
            lp.width = ((if (i == active) 18 else 6) * d).toInt()
            v.layoutParams = lp
            v.setBackgroundResource(if (i == active) R.drawable.dot_on else R.drawable.dot_off)
        }
    }

    private fun updateDots() {
        val lm = hero.layoutManager as? LinearLayoutManager ?: return
        val v = snap.findSnapView(lm) ?: return
        val p = lm.getPosition(v)
        if (p >= 0 && p < dots.childCount) setActiveDot(p)
    }

    // ---------- Navegación ----------

    private fun openSection(section: String, group: String? = null) {
        if (Repo.all.isEmpty()) {
            Toast.makeText(this, "Primero añade una lista", Toast.LENGTH_SHORT).show()
            showAddDialog()
            return
        }
        val i = Intent(this, BrowseActivity::class.java).putExtra("section", section)
        if (group != null) i.putExtra("group", group)
        startActivity(i)
    }

    /** Reproduce el elemento; las series de Xtream abren su lista de episodios en la exploración. */
    private fun openItem(list: List<Channel>, pos: Int) {
        val ch = list.getOrNull(pos) ?: return
        if (ch.seriesId.isNotEmpty()) {
            startActivity(
                Intent(this, BrowseActivity::class.java)
                    .putExtra("section", "series")
                    .putExtra("open", ch.key)
            )
        } else {
            Playlist.channels = list
            Playlist.index = pos
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }

    private fun showMenu() {
        val options = arrayOf(
            "★ Mi lista (favoritos)",
            "Descargas",
            "Añadir lista",
            "Actualizar lista ahora${lastUpdateText()}",
            "Control parental",
            "Ajustes"
        )
        AlertDialog.Builder(this)
            .setTitle("Listas")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openSection("fav")
                    1 -> startActivity(Intent(this, DownloadsActivity::class.java))
                    2 -> showAddDialog()
                    3 -> updateEverything()
                    4 -> Parental.showMenu(this) { refreshHome(true) }
                    else -> showSettings()
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    // ---------- Carga de listas ----------

    /** Ejecuta una carga en segundo plano mostrando el progreso. */
    private fun runLoad(work: ((String) -> Unit) -> Int) {
        progress.visibility = View.VISIBLE
        showStatus("Cargando…")
        val report: (String) -> Unit = { msg -> runOnUiThread { showStatus(msg) } }
        Thread {
            try {
                val n = work(report)
                runOnUiThread {
                    progress.visibility = View.GONE
                    showStatus("Lista cargada: $n elementos")
                    refreshHome(true)
                    maybeAskLanguages()
                    statusRow.postDelayed({
                        if (progress.visibility != View.VISIBLE) showStatus("")
                    }, 4000)
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    showStatus("Error: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }.start()
    }

    private fun refresh() {
        if (prefs.getString("src", "").isNullOrEmpty()) {
            showAddDialog()
            return
        }
        runLoad { report -> Repo.refresh(this, report) }
    }

    // ---------- Botones del inicio: actualizar, VPN, apagar ----------

    /** Botón «Actualizar»: vuelve a descargar la lista y borra las carátulas guardadas para pedirlas de nuevo. */
    private fun updateEverything() {
        if (progress.visibility == View.VISIBLE) {
            Toast.makeText(this, "Ya se está actualizando…", Toast.LENGTH_SHORT).show()
            return
        }
        val src = prefs.getString("src", "").orEmpty()
        if (src.isEmpty()) {
            showAddDialog()
            return
        }
        if (src == "file") {
            Toast.makeText(this, "Esta lista viene de un archivo: vuelve a elegirlo", Toast.LENGTH_LONG).show()
            showAddDialog()
            return
        }
        Net.clearImageCaches(this)
        runLoad { report ->
            report("Actualizando lista y carátulas…")
            Repo.refresh(this, report)
        }
    }

    /** Botón de VPN: conecta directamente la VPN propia (WireGuard) o la desconecta. */
    private fun vpnButton() {
        when {
            WgVpn.isUp(this) -> disconnectWg()
            Vpn.isActive(this) -> {
                Toast.makeText(this, "La VPN activa es de otra app: se abre para gestionarla", Toast.LENGTH_LONG).show()
                Vpn.openProton(this)
            }
            WgVpn.hasConfig(this) -> startWg()
            else -> {
                Toast.makeText(this, "Primero importa tu archivo .conf de WireGuard (Proton VPN)", Toast.LENGTH_LONG).show()
                showWgMenu()
            }
        }
    }

    private fun updateVpnButton() {
        val b = findViewById<TextView>(R.id.btnVpnToggle)
        b.text = when {
            WgVpn.isUp(this) -> "Quitar VPN"
            Vpn.isActive(this) -> "VPN activa"
            else -> "Conectar VPN"
        }
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle("¿Apagar la aplicación?")
            .setMessage("Se cerrará IPTV Player.")
            .setPositiveButton("Apagar") { _, _ -> exitApp() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /** Apaga de verdad: desconecta la VPN propia (sin pedir PIN) y mata el proceso. */
    private fun exitApp() {
        if (WgVpn.isUp(this)) {
            WgVpn.disconnect(this) { _, _ -> runOnUiThread { closeForGood() } }
        } else {
            if (Vpn.isActive(this)) {
                Toast.makeText(this, "La VPN activa es de otra app: desconéctala desde ella", Toast.LENGTH_LONG).show()
            }
            closeForGood()
        }
    }

    private fun closeForGood() {
        // Al volver a abrir la app se comporta como un arranque nuevo (pregunta por la VPN, etc.)
        Vpn.autoOpened = false
        Vpn.bypass = false
        finishAndRemoveTask()
        // finishAndRemoveTask solo cierra las pantallas; se termina el proceso para que no quede en segundo plano
        handler.postDelayed({ android.os.Process.killProcess(android.os.Process.myPid()) }, 400)
    }

    private fun showAddDialog() {
        val options = arrayOf(
            "Lista M3U por URL",
            "Xtream Codes (servidor, usuario y contraseña)",
            "Archivo M3U del dispositivo"
        )
        AlertDialog.Builder(this)
            .setTitle("Añadir lista")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> askUrl()
                    1 -> askXtream()
                    else -> pickFile.launch(arrayOf("*/*"))
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askUrl() {
        val input = EditText(this).apply {
            hint = "https://…/lista.m3u"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("url", ""))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("URL de la lista")
            .setMessage("Vale una lista M3U o un enlace get.php de Xtream.")
            .setView(input)
            .setPositiveButton("Cargar") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) runLoad { report -> Repo.loadFromUrl(this, url, report) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askXtream() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val server = EditText(this).apply {
            hint = "Servidor: http://dominio:puerto"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("xt_host", ""))
            setSingleLine()
        }
        val user = EditText(this).apply {
            hint = "Usuario"
            setText(prefs.getString("xt_user", ""))
            setSingleLine()
        }
        val pass = EditText(this).apply {
            hint = "Contraseña"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(server)
            addView(user)
            addView(pass)
        }
        AlertDialog.Builder(this)
            .setTitle("Xtream Codes")
            .setView(box)
            .setPositiveButton("Cargar") { _, _ ->
                val host = server.text.toString().trim()
                val u = user.text.toString().trim()
                val p = pass.text.toString().trim()
                if (host.isEmpty() || u.isEmpty()) return@setPositiveButton
                val creds = XtreamCreds(Repo.normalizeHost(host), u, p)
                runLoad { report -> Repo.loadXtream(this, creds, report) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun loadFromUri(uri: Uri) {
        runLoad { report ->
            report("Leyendo archivo…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val isGzip = bytes.size > 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()
            val raw = if (isGzip) java.util.zip.GZIPInputStream(bytes.inputStream()).use { it.readBytes() } else bytes
            Repo.loadFromFileText(this, String(raw, Charsets.UTF_8))
        }
    }

    // ---------- VPN propia (WireGuard) ----------

    /** Al abrir la app: pregunta si se quiere activar la VPN. */
    private fun askConnectWg() {
        AlertDialog.Builder(this)
            .setTitle("¿Activar la VPN?")
            .setMessage("Se conectará directamente, sin abrir otras apps.")
            .setPositiveButton("Sí, activar") { _, _ -> startWg() }
            .setNegativeButton("No", null)
            .show()
    }

    /** Pide el permiso de VPN a Android si hace falta (solo la primera vez) y conecta. */
    private fun startWg() {
        val consent = android.net.VpnService.prepare(this)
        if (consent != null) wgConsent.launch(consent) else connectWg()
    }

    /** Android no ha concedido el permiso de VPN: explica las causas habituales. */
    private fun showWgDenied() {
        // Android guarda qué app es la "VPN siempre activa" (si el móvil deja leerlo)
        val always = try {
            android.provider.Settings.Secure.getString(contentResolver, "always_on_vpn_app")
        } catch (e: Exception) {
            null
        }
        val detected = if (!always.isNullOrEmpty() && always != packageName) {
            "Detectado: «$always» está como «VPN siempre activa». Esa es la causa: hay que desactivarla.\n\n"
        } else {
            ""
        }
        AlertDialog.Builder(this)
            .setTitle("Android no ha dado el permiso de VPN")
            .setMessage(
                detected +
                    "Causas habituales:\n\n" +
                    "• Proton VPN tiene activada «VPN siempre activa». Para quitarla: abre la app de Proton VPN → Ajustes → Funciones → Kill Switch y pulsa el botón que abre los ajustes de Android; allí desactiva «VPN siempre activa». Desconecta Proton antes.\n\n" +
                    "• Tienes que pulsar «Aceptar» en el aviso de Android «Solicitud de conexión». Si pulsaste «Cancelar» o tocaste fuera, vuelve a intentarlo.\n\n" +
                    "• Hay algo sobre la pantalla (burbujas, filtro de luz azul, grabador…) y Android desactiva el botón Aceptar por seguridad. Ciérralo y reintenta."
            )
            .setPositiveButton("Reintentar") { _, _ -> startWg() }
            .setNeutralButton("Abrir Proton VPN") { _, _ -> Vpn.openProton(this) }
            .setNegativeButton("Ajustes de VPN") { _, _ ->
                try {
                    startActivity(Intent("android.settings.VPN_SETTINGS"))
                } catch (e: Exception) {
                    Toast.makeText(this, "No se pudieron abrir los ajustes de VPN", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    private fun connectWg() {
        Toast.makeText(this, "Conectando la VPN…", Toast.LENGTH_SHORT).show()
        WgVpn.connect(this) { ok, msg ->
            runOnUiThread {
                if (ok) {
                    Toast.makeText(this, "VPN conectada", Toast.LENGTH_SHORT).show()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("No se pudo conectar la VPN")
                        .setMessage(msg)
                        .setPositiveButton("Cerrar", null)
                        .show()
                }
                checkVpn()
            }
        }
    }

    private fun disconnectWg() {
        Parental.requirePin(this, "PIN para desconectar la VPN") {
            WgVpn.disconnect(this) { ok, msg ->
                runOnUiThread {
                    Toast.makeText(this, if (ok) "VPN desconectada" else "Error: $msg", Toast.LENGTH_LONG).show()
                    checkVpn()
                }
            }
        }
    }

    private fun showWgMenu() {
        val has = WgVpn.hasConfig(this)
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        labels.add("¿Cómo conseguir el archivo de configuración?")
        actions.add { showWgHelp() }
        labels.add("Importar archivo .conf")
        actions.add { pickWgConf.launch(arrayOf("*/*")) }
        labels.add("Pegar la configuración")
        actions.add { pasteWgConf() }
        if (has) {
            val up = Vpn.isActive(this)
            labels.add(if (up) "Desconectar la VPN ahora" else "Conectar la VPN ahora")
            actions.add { if (up) disconnectWg() else startWg() }
            labels.add("Preguntar al abrir la app: ${if (WgVpn.askAtStart(this)) "SÍ" else "NO"}")
            actions.add {
                val on = !WgVpn.askAtStart(this)
                WgVpn.setAskAtStart(this, on)
                Toast.makeText(this, if (on) "Preguntará al abrir" else "No preguntará al abrir", Toast.LENGTH_SHORT).show()
            }
            labels.add("Borrar la configuración")
            actions.add {
                Parental.requirePin(this, "PIN para borrar la VPN") {
                    WgVpn.clear(this)
                    Toast.makeText(this, "Configuración borrada", Toast.LENGTH_SHORT).show()
                    checkVpn()
                }
            }
        }
        AlertDialog.Builder(this)
            .setTitle(if (has) "VPN propia (WireGuard): configurada" else "VPN propia (WireGuard): sin configurar")
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showWgHelp() {
        AlertDialog.Builder(this)
            .setTitle("Archivo de configuración")
            .setMessage(
                "1. Entra en tu cuenta de Proton VPN desde un navegador.\n" +
                    "2. Ve a Descargas y busca «Configuración WireGuard» (el nombre del menú puede variar).\n" +
                    "3. Elige Android, un servidor y pulsa «Crear». Descarga el archivo .conf.\n" +
                    "4. Aquí usa «Importar archivo .conf», o abre el archivo, copia todo su texto y usa «Pegar la configuración».\n\n" +
                    "Ese archivo contiene tu clave privada: no lo compartas con nadie."
            )
            .setPositiveButton("Entendido", null)
            .show()
    }

    private fun pasteWgConf() {
        val input = EditText(this).apply {
            hint = "[Interface]\nPrivateKey = …"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 6
            gravity = android.view.Gravity.TOP
            // Si el portapapeles ya tiene una configuración, se rellena sola
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                if (clip.contains("[Interface]")) setText(clip)
            } catch (_: Exception) {
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Pegar configuración WireGuard")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ -> saveWgConfig(input.text.toString()) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun importWgFromUri(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)!!.use { String(it.readBytes(), Charsets.UTF_8) }
            saveWgConfig(text)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo leer el archivo: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveWgConfig(text: String) {
        val error = WgVpn.saveConfig(this, text)
        if (error != null) {
            AlertDialog.Builder(this)
                .setTitle("Configuración no válida")
                .setMessage(error)
                .setPositiveButton("Cerrar", null)
                .show()
            return
        }
        checkVpn()
        AlertDialog.Builder(this)
            .setTitle("Configuración guardada")
            .setMessage("¿Conectar la VPN ahora? Android pedirá un permiso de VPN la primera vez.")
            .setPositiveButton("Conectar") { _, _ -> startWg() }
            .setNegativeButton("Más tarde", null)
            .show()
    }

    // ---------- Ajustes ----------

    private fun showSettings() {
        val options = arrayOf(
            "Exigir VPN al iniciar: ${if (Vpn.required(this)) "SÍ" else "NO"}",
            "VPN propia (WireGuard)…",
            "Actualizar la lista automáticamente: ${autoText(Repo.autoDays(this))}",
            "User-Agent del reproductor",
            "Carátulas automáticas TMDB…",
            "Borrar la lista guardada"
        )
        AlertDialog.Builder(this)
            .setTitle("Ajustes")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> toggleVpn()
                    1 -> showWgMenu()
                    2 -> askAutoUpdate()
                    3 -> askUserAgent()
                    4 -> askTmdbKey()
                    else -> Parental.requirePin(this, "PIN para borrar la lista") {
                        Repo.clear(this)
                        refreshHome(true)
                        showStatus("Lista borrada")
                    }
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun askTmdbKey() {
        val input = EditText(this).apply {
            hint = "Clave API v3 de TMDB"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(TmdbPosters.apiKey(this@MainActivity))
        }
        AlertDialog.Builder(this)
            .setTitle("Carátulas automáticas (TMDB)")
            .setMessage("Introduce tu clave API v3 de TMDB. Se conservarán las carátulas IPTV que funcionen; TMDB se consultará si faltan o dan error.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                TmdbPosters.saveApiKey(this, input.text.toString())
                Toast.makeText(this, "Clave TMDB guardada", Toast.LENGTH_SHORT).show()
                refreshHome(true)
            }
            .setNeutralButton("Borrar clave") { _, _ -> TmdbPosters.saveApiKey(this, "") }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun autoText(days: Int): String = when (days) {
        0 -> "nunca"
        1 -> "cada día"
        7 -> "cada semana"
        else -> "cada $days días"
    }

    /** " (última: 21/11 18:30)" o vacío si no se sabe. */
    private fun lastUpdateText(): String {
        val t = Repo.lastUpdate(this)
        if (t <= 0L) return ""
        return " (última: ${SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(t))})"
    }

    private fun askAutoUpdate() {
        val labels = arrayOf("Cada día", "Cada 3 días (recomendado)", "Cada semana", "Nunca")
        val values = intArrayOf(1, 3, 7, 0)
        val current = values.indexOf(Repo.autoDays(this)).let { if (it < 0) 1 else it }
        AlertDialog.Builder(this)
            .setTitle("Actualizar la lista automáticamente")
            .setSingleChoiceItems(labels, current) { d, which ->
                Repo.setAutoDays(this, values[which])
                Toast.makeText(this, "Actualización: ${autoText(values[which])}", Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun toggleVpn() {
        val now = Vpn.required(this)
        if (now) {
            // Desactivarlo necesita el PIN si hay control parental
            Parental.requirePin(this, "PIN para desactivar la VPN") {
                Vpn.setRequired(this, false)
                checkVpn()
                Toast.makeText(this, "VPN opcional", Toast.LENGTH_SHORT).show()
            }
        } else {
            Vpn.setRequired(this, true)
            checkVpn()
            Toast.makeText(this, "Se exigirá VPN al iniciar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askUserAgent() {
        val input = EditText(this).apply {
            hint = Repo.UA_VLC
            setText(prefs.getString("ua", ""))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("User-Agent")
            .setMessage("Déjalo vacío para usar el predeterminado (${Repo.UA_VLC}). Algunos servidores solo aceptan ciertos User-Agent.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putString("ua", input.text.toString().trim()).apply()
                Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
