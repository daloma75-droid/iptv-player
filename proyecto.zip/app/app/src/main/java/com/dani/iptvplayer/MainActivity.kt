package com.dani.iptvplayer

import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Pantalla de inicio estilo Smarters: TV en directo, Películas y Series. */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var countLive: TextView
    private lateinit var countMovies: TextView
    private lateinit var countSeries: TextView

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadFromUri(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Repo.prefs(this)

        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        countLive = findViewById(R.id.countLive)
        countMovies = findViewById(R.id.countMovies)
        countSeries = findViewById(R.id.countSeries)

        // Tarjetas en columna en vertical y en fila en horizontal / TV
        val cards = findViewById<LinearLayout>(R.id.cards)
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        cards.orientation = if (landscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        val ids = intArrayOf(R.id.cardLive, R.id.cardMovies, R.id.cardSeries)
        for (id in ids) {
            val card = findViewById<View>(id)
            val lp = card.layoutParams as LinearLayout.LayoutParams
            if (landscape) {
                lp.width = 0
                lp.height = LinearLayout.LayoutParams.MATCH_PARENT
            } else {
                lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                lp.height = 0
            }
            lp.weight = 1f
            card.layoutParams = lp
            card.zoomOnFocus(1.05f)
        }

        findViewById<View>(R.id.cardLive).setOnClickListener { openSection("live") }
        findViewById<View>(R.id.cardMovies).setOnClickListener { openSection("movie") }
        findViewById<View>(R.id.cardSeries).setOnClickListener { openSection("series") }
        findViewById<View>(R.id.btnFav).setOnClickListener { openSection("fav") }
        findViewById<View>(R.id.btnAdd).setOnClickListener { showAddDialog() }
        findViewById<View>(R.id.btnRefresh).setOnClickListener { refresh() }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }

        if (Repo.all.isEmpty()) {
            status.text = "Cargando…"
            Thread {
                val ok = Repo.loadCache(this)
                runOnUiThread {
                    updateCounts()
                    status.text = if (ok) "" else "Añade una lista para empezar (botón «Añadir lista»)"
                    if (!ok) showAddDialog()
                }
            }.start()
        } else {
            updateCounts()
        }
        findViewById<View>(R.id.cardLive).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        updateCounts()
    }

    private fun updateCounts() {
        val list = Repo.all
        countLive.text = "${list.count { it.type == ContentType.LIVE }} canales"
        countMovies.text = "${list.count { it.type == ContentType.MOVIE }} películas"
        countSeries.text = "${list.count { it.type == ContentType.SERIES }} series"
    }

    private fun openSection(section: String) {
        if (Repo.all.isEmpty()) {
            Toast.makeText(this, "Primero añade una lista", Toast.LENGTH_SHORT).show()
            showAddDialog()
            return
        }
        startActivity(Intent(this, BrowseActivity::class.java).putExtra("section", section))
    }

    // ---------- Carga de listas ----------

    /** Ejecuta una carga en segundo plano mostrando el progreso. */
    private fun runLoad(work: ((String) -> Unit) -> Int) {
        progress.visibility = View.VISIBLE
        status.text = "Cargando…"
        val report: (String) -> Unit = { msg -> runOnUiThread { status.text = msg } }
        Thread {
            try {
                val n = work(report)
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Lista cargada: $n elementos"
                    updateCounts()
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Error: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }.start()
    }

    private fun refresh() {
        if (prefs.getString("src", "").isNullOrEmpty()) {
            showAddDialog()
            return
        }
        runLoad { report -> Repo.refresh(this, report) }
    }

    private fun showAddDialog() {
        val options = arrayOf(
            "Lista M3U por URL",
            "Xtream Codes (servidor, usuario y contraseña)",
            "Archivo M3U del dispositivo"
        )
        AlertDialog.Builder(this)
            .setTitle("Añadir lista")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> askUrl()
                    1 -> askXtream()
                    else -> pickFile.launch(arrayOf("*/*"))
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askUrl() {
        val input = EditText(this).apply {
            hint = "https://…/lista.m3u"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("url", ""))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("URL de la lista")
            .setMessage("Vale una lista M3U o un enlace get.php de Xtream.")
            .setView(input)
            .setPositiveButton("Cargar") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) runLoad { report -> Repo.loadFromUrl(this, url, report) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askXtream() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val server = EditText(this).apply {
            hint = "Servidor: http://dominio:puerto"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("xt_host", ""))
            setSingleLine()
        }
        val user = EditText(this).apply {
            hint = "Usuario"
            setText(prefs.getString("xt_user", ""))
            setSingleLine()
        }
        val pass = EditText(this).apply {
            hint = "Contraseña"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(server)
            addView(user)
            addView(pass)
        }
        AlertDialog.Builder(this)
            .setTitle("Xtream Codes")
            .setView(box)
            .setPositiveButton("Cargar") { _, _ ->
                val host = server.text.toString().trim()
                val u = user.text.toString().trim()
                val p = pass.text.toString().trim()
                if (host.isEmpty() || u.isEmpty()) return@setPositiveButton
                val creds = XtreamCreds(Repo.normalizeHost(host), u, p)
                runLoad { report -> Repo.loadXtream(this, creds, report) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun loadFromUri(uri: Uri) {
        runLoad { report ->
            report("Leyendo archivo…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val isGzip = bytes.size > 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()
            val raw = if (isGzip) java.util.zip.GZIPInputStream(bytes.inputStream()).use { it.readBytes() } else bytes
            Repo.loadFromFileText(this, String(raw, Charsets.UTF_8))
        }
    }

    // ---------- Ajustes ----------

    private fun showSettings() {
        val options = arrayOf("User-Agent del reproductor", "Borrar la lista guardada")
        AlertDialog.Builder(this)
            .setTitle("Ajustes")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> askUserAgent()
                    else -> {
                        Repo.clear(this)
                        updateCounts()
                        status.text = "Lista borrada"
                    }
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun askUserAgent() {
        val input = EditText(this).apply {
            hint = Repo.UA_VLC
            setText(prefs.getString("ua", ""))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("User-Agent")
            .setMessage("Déjalo vacío para usar el predeterminado (${Repo.UA_VLC}). Algunos servidores solo aceptan ciertos User-Agent.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putString("ua", input.text.toString().trim()).apply()
                Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
