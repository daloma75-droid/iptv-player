package com.dani.iptvplayer

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.zip.GZIPInputStream

class MainActivity : AppCompatActivity() {

    companion object {
        private const val ALL = "Todos"
        private const val FAV = "★ Favoritos"
        private const val UA = "Mozilla/5.0 (Linux; Android 13) IPTVPlayer/1.0"
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: ChannelAdapter
    private lateinit var search: EditText
    private lateinit var spinner: Spinner
    private lateinit var status: TextView

    private var all: List<Channel> = emptyList()
    private val favorites = mutableSetOf<String>()

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadFromUri(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("iptv", MODE_PRIVATE)
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())

        search = findViewById(R.id.search)
        spinner = findViewById(R.id.groupSpinner)
        status = findViewById(R.id.status)

        adapter = ChannelAdapter(
            favorites,
            onClick = { position ->
                Playlist.index = position
                startActivity(Intent(this, PlayerActivity::class.java))
            },
            onLongClick = { channel -> toggleFavorite(channel) }
        )
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<Button>(R.id.btnUrl).setOnClickListener { askUrl() }
        findViewById<Button>(R.id.btnXtream).setOnClickListener { askXtream() }
        findViewById<Button>(R.id.btnFile).setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener {
            val url = prefs.getString("url", "").orEmpty()
            if (url.isNotEmpty()) loadFromUrl(url)
            else Toast.makeText(this, "Esta lista viene de un archivo; vuelve a elegirlo", Toast.LENGTH_LONG).show()
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = applyFilter()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        loadCache()
    }

    // ---------- Carga de listas ----------

    private fun cacheFile() = File(filesDir, "playlist.m3u")

    private fun loadCache() {
        val f = cacheFile()
        if (!f.exists()) {
            status.text = "Añade una lista M3U (URL o archivo) para empezar"
            return
        }
        Thread {
            val channels = M3uParser.parse(f.readText())
            runOnUiThread { setChannels(channels) }
        }.start()
    }

    private fun askUrl() {
        val input = EditText(this).apply {
            hint = "https://…/lista.m3u"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("url", ""))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("URL de la lista M3U")
            .setView(input)
            .setPositiveButton("Cargar") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) loadFromUrl(url)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun loadFromUrl(url: String) {
        status.text = "Descargando lista…"
        Thread {
            try {
                val text = download(url)
                handleText(text, url)
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error al descargar: ${e.message}" }
            }
        }.start()
    }

    /** Descarga siguiendo redirecciones (también http<->https) y descomprime gzip si hace falta. */
    private fun download(startUrl: String): String {
        var current = startUrl
        repeat(6) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", UA)
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: throw Exception("Redirección sin destino")
                current = URL(URL(current), loc).toString()
                conn.disconnect()
            } else {
                if (code !in 200..299) throw Exception("HTTP $code")
                val bytes = conn.inputStream.use { it.readBytes() }
                return decode(bytes)
            }
        }
        throw Exception("Demasiadas redirecciones")
    }

    private fun decode(bytes: ByteArray): String {
        val isGzip = bytes.size > 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()
        val raw = if (isGzip) GZIPInputStream(bytes.inputStream()).use { it.readBytes() } else bytes
        return String(raw, Charsets.UTF_8)
    }

    private fun askXtream() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val server = EditText(this).apply {
            hint = "Servidor: http://dominio:puerto"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        val user = EditText(this).apply { hint = "Usuario"; setSingleLine() }
        val pass = EditText(this).apply {
            hint = "Contraseña"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(server); addView(user); addView(pass)
        }
        AlertDialog.Builder(this)
            .setTitle("Xtream Codes")
            .setView(box)
            .setPositiveButton("Cargar") { _, _ ->
                var host = server.text.toString().trim().trimEnd('/')
                if (host.isEmpty() || user.text.isNullOrBlank()) return@setPositiveButton
                if (!host.contains("://")) host = "http://$host"
                val u = URLEncoder.encode(user.text.toString().trim(), "UTF-8")
                val p = URLEncoder.encode(pass.text.toString().trim(), "UTF-8")
                loadFromUrl("$host/get.php?username=$u&password=$p&type=m3u_plus&output=ts")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun loadFromUri(uri: Uri) {
        status.text = "Leyendo archivo…"
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                handleText(decode(bytes), "")
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error al leer: ${e.message}" }
            }
        }.start()
    }

    private fun handleText(text: String, source: String) {
        // Si la URL es directamente un stream HLS (no una lista de canales), se trata como un único canal
        val isHlsStream = source.isNotEmpty() &&
            (text.contains("#EXT-X-STREAM-INF") || text.contains("#EXT-X-TARGETDURATION"))
        val channels = if (isHlsStream) {
            val n = source.substringBefore('?').substringAfterLast('/').ifEmpty { "Stream" }
            listOf(Channel(n, source, "Directo", ""))
        } else {
            M3uParser.parse(text)
        }
        if (channels.isEmpty()) {
            runOnUiThread { status.text = "La lista no tiene canales (¿es un M3U válido?)" }
            return
        }
        cacheFile().writeText(text)
        prefs.edit().putString("url", source).apply()
        runOnUiThread { setChannels(channels) }
    }

    // ---------- Lista, grupos y filtros ----------

    private fun setChannels(channels: List<Channel>) {
        all = channels
        val groups = mutableListOf(ALL, FAV)
        groups.addAll(channels.map { it.group }.distinct().sorted())
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups)
        applyFilter()
    }

    private fun applyFilter() {
        val group = spinner.selectedItem as? String ?: ALL
        val q = search.text.toString().trim().lowercase()
        val filtered = all.filter { c ->
            val groupOk = when (group) {
                ALL -> true
                FAV -> c.url in favorites
                else -> c.group == group
            }
            groupOk && (q.isEmpty() || c.name.lowercase().contains(q))
        }
        Playlist.channels = filtered
        adapter.submit(filtered)
        status.text = "${filtered.size} canales"
    }

    private fun toggleFavorite(channel: Channel) {
        if (!favorites.remove(channel.url)) favorites.add(channel.url)
        prefs.edit().putStringSet("favorites", HashSet(favorites)).apply()
        Toast.makeText(
            this,
            if (channel.url in favorites) "Añadido a favoritos" else "Quitado de favoritos",
            Toast.LENGTH_SHORT
        ).show()
        applyFilter()
    }
}
