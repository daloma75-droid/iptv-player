package com.dani.iptvplayer

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@UnstableApi
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private var http: DefaultHttpDataSource.Factory? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: View
    private lateinit var title: TextView
    private lateinit var error: TextView

    private var controllerVisible = false
    private var current: Channel? = null

    /** 0 = User-Agent normal; 1..MAX_ATTEMPT = reintentos automáticos con otros User-Agent. */
    private var attempt = 0
    private val MAX_ATTEMPT = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        setContentView(R.layout.activity_player)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        title = findViewById(R.id.title)
        error = findViewById(R.id.error)

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility ->
                controllerVisible = visibility == View.VISIBLE
                overlay.visibility = if (controllerVisible) View.VISIBLE else View.GONE
            }
        )
        findViewById<View>(R.id.btnPrev).setOnClickListener { play(Playlist.index - 1) }
        findViewById<View>(R.id.btnNext).setOnClickListener { play(Playlist.index + 1) }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
    }

    override fun onStart() {
        super.onStart()
        if (Vpn.blocked(this)) {
            Toast.makeText(this, "Conecta la VPN para reproducir", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(Repo.userAgent(this))
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(40000)
            .setReadTimeoutMs(40000)
        http = httpFactory

        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, httpFactory)))
            .build()
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition()
                    exo.prepare()
                    return
                }
                // Errores de red (2000..2004, incluye 403/404...): se reintenta con otro User-Agent
                if (e.errorCode in 2000..2004 && attempt < MAX_ATTEMPT) {
                    attempt++
                    startCurrent()
                    return
                }
                showError(e)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) error.visibility = View.GONE
            }
        })
        player = exo
        playerView.player = exo
        play(Playlist.index)
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        playerView.player = null
        player?.release()
        player = null
    }

    private fun showError(e: PlaybackException) {
        val sb = StringBuilder("No se pudo reproducir\n(${e.errorCodeName})")
        var t: Throwable? = e.cause
        var n = 0
        while (t != null && n < 2) {
            sb.append("\n").append(t.javaClass.simpleName).append(": ").append(t.message ?: "")
            t = t.cause
            n++
        }
        error.text = sb.toString()
        error.visibility = View.VISIBLE
    }

    /** Guarda dónde se quedó una película o episodio para "Seguir viendo". */
    private fun saveProgress() {
        val p = player ?: return
        val ch = current ?: return
        if (ch.type == ContentType.LIVE) return
        val dur = p.duration
        if (dur <= 0L) return
        Recents.save(this, ch, p.currentPosition, dur)
    }

    private fun play(requestedIndex: Int) {
        saveProgress()
        val list = Playlist.channels
        if (list.isEmpty()) {
            finish()
            return
        }
        val i = ((requestedIndex % list.size) + list.size) % list.size
        Playlist.index = i
        val channel = list[i]
        current = channel
        attempt = 0
        title.text = channel.name
        error.visibility = View.GONE
        startCurrent()
    }

    /** Arranca el elemento actual con la configuración del intento en curso. */
    private fun startCurrent() {
        val ch = current ?: return
        val ua = when (attempt) {
            0 -> ch.userAgent.ifEmpty { Repo.userAgent(this) }
            1 -> Repo.UA_SMARTERS
            2 -> Repo.UA_CHROME
            3 -> Repo.UA_LAVF
            4 -> Repo.UA_DALVIK
            else -> Repo.UA_OKHTTP
        }
        var url = ch.url
        // Canales Xtream: si .ts falla, se prueba con HLS (.m3u8)
        if (attempt >= 1 && ch.type == ContentType.LIVE && url.contains("/live/") && url.endsWith(".ts")) {
            url = url.dropLast(3) + ".m3u8"
        }
        http?.setUserAgent(ua)
        http?.setDefaultRequestProperties(ch.headers)
        if (attempt > 0) {
            error.text = "Reintentando ($attempt/$MAX_ATTEMPT)…"
            error.visibility = View.VISIBLE
        }
        // Películas y episodios retoman donde se quedaron; el directo arranca en vivo
        val startPos = if (ch.type != ContentType.LIVE) Recents.positionFor(this, ch.url) else 0L
        player?.apply {
            setMediaItem(MediaItem.fromUri(url), if (startPos > 0L) startPos else C.TIME_UNSET)
            prepare()
            playWhenReady = true
        }
    }

    private fun seekBy(ms: Long) {
        val p = player ?: return
        p.seekTo((p.currentPosition + ms).coerceAtLeast(0L))
    }

    /** Mando de TV box: ↑/↓ cambian de canal, ←/→ saltan 10 s en películas, OK muestra los controles. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && !controllerVisible) {
            val live = current?.type == ContentType.LIVE
            when (event.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP -> {
                    play(Playlist.index + 1)
                    return true
                }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    play(Playlist.index - 1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP -> if (live) {
                    play(Playlist.index - 1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> if (live) {
                    play(Playlist.index + 1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> if (!live) {
                    seekBy(-10000L)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (!live) {
                    seekBy(10000L)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    playerView.showController()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
}
