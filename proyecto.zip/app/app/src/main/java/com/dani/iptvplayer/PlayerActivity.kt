package com.dani.iptvplayer

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@UnstableApi
class PlayerActivity : AppCompatActivity() {

    private val defaultUa = "Mozilla/5.0 (Linux; Android 13) IPTVPlayer/1.0"
    private var player: ExoPlayer? = null
    private var http: DefaultHttpDataSource.Factory? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: View
    private lateinit var title: TextView
    private lateinit var error: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        setContentView(R.layout.activity_player)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        title = findViewById(R.id.title)
        error = findViewById(R.id.error)

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility ->
                overlay.visibility = if (visibility == View.VISIBLE) View.VISIBLE else View.GONE
            }
        )
        findViewById<View>(R.id.btnPrev).setOnClickListener { play(Playlist.index - 1) }
        findViewById<View>(R.id.btnNext).setOnClickListener { play(Playlist.index + 1) }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
    }

    override fun onStart() {
        super.onStart()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(defaultUa)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
        http = httpFactory

        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, httpFactory)))
            .build()
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition()
                    exo.prepare()
                } else {
                    error.text = "No se pudo reproducir este canal\n(${e.errorCodeName})"
                    error.visibility = View.VISIBLE
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) error.visibility = View.GONE
            }
        })
        player = exo
        playerView.player = exo
        play(Playlist.index)
    }

    override fun onStop() {
        super.onStop()
        playerView.player = null
        player?.release()
        player = null
    }

    private fun play(requestedIndex: Int) {
        val list = Playlist.channels
        if (list.isEmpty()) {
            finish()
            return
        }
        val i = ((requestedIndex % list.size) + list.size) % list.size
        Playlist.index = i
        val channel = list[i]
        title.text = channel.name
        error.visibility = View.GONE
        // Cabeceras propias de cada canal (User-Agent, Referer…) antes de crear la fuente
        http?.setUserAgent(channel.userAgent.ifEmpty { defaultUa })
        http?.setDefaultRequestProperties(channel.headers)
        player?.apply {
            setMediaItem(MediaItem.fromUri(channel.url))
            prepare()
            playWhenReady = true
        }
    }
}
