package com.dani.iptvplayer

import android.content.Context
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest
import java.util.UUID

/** Control parental: PIN, ocultar contenido adulto y categorías bloqueadas con PIN. */
object Parental {
    private const val VERIFY_MS = 5 * 60 * 1000L

    private val ADULT = Regex(
        "(?<![a-z0-9])(?:xxx|porn\\w*|adult\\w*|er[oó]tic\\w*|hentai|playboy|sexo|sexy|sex|\\+18|18\\+)(?![a-z0-9])"
    )

    private var verifiedAt = 0L
    private val unlocked = HashSet<String>()

    private var srcRef: List<Channel>? = null
    private var cached: List<Channel> = emptyList()

    private fun prefs(ctx: Context) = Repo.prefs(ctx)

    fun hasPin(ctx: Context): Boolean = !prefs(ctx).getString("pin_hash", "").isNullOrEmpty()

    fun adultHidden(ctx: Context): Boolean = prefs(ctx).getBoolean("hide_adult", true)

    fun lockedGroups(ctx: Context): Set<String> =
        prefs(ctx).getStringSet("locked_groups", emptySet()) ?: emptySet()

    fun isLocked(ctx: Context, group: String): Boolean =
        group in lockedGroups(ctx) && group !in unlocked

    fun unlock(group: String) {
        unlocked.add(group)
    }

    /** Cambia cuando cambia cualquier ajuste que afecta a lo que se muestra. */
    fun stateKey(ctx: Context): String =
        "${adultHidden(ctx)}|${lockedGroups(ctx).hashCode()}|${unlocked.hashCode()}"

    fun isAdult(ch: Channel): Boolean {
        val t = (ch.group + " " + ch.name).lowercase()
        if (t.contains("adult swim")) return false
        return ADULT.containsMatchIn(t)
    }

    /** Lista sin contenido adulto (si el filtro está activo). Las categorías bloqueadas siguen dentro. */
    fun visible(ctx: Context): List<Channel> {
        val all = Repo.all
        if (!adultHidden(ctx)) return all
        if (srcRef !== all) {
            cached = all.filter { !isAdult(it) }
            srcRef = all
        }
        return cached
    }

    /** Lo que se puede mostrar sin pedir PIN: sin adulto y sin categorías bloqueadas. */
    fun openList(ctx: Context): List<Channel> {
        val locked = lockedGroups(ctx)
        val v = visible(ctx)
        if (locked.isEmpty()) return v
        return v.filter { !(it.group in locked && it.group !in unlocked) }
    }

    fun allowed(ctx: Context, ch: Channel): Boolean =
        (!adultHidden(ctx) || !isAdult(ch)) && !isLocked(ctx, ch.group)

    // ---------- PIN ----------

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun savePin(ctx: Context, pin: String) {
        val salt = UUID.randomUUID().toString()
        prefs(ctx).edit().putString("pin_salt", salt).putString("pin_hash", hash(pin, salt)).apply()
        verifiedAt = System.currentTimeMillis()
    }

    private fun checkPin(ctx: Context, pin: String): Boolean {
        val p = prefs(ctx)
        val salt = p.getString("pin_salt", "") ?: ""
        return hash(pin, salt) == p.getString("pin_hash", "")
    }

    private fun pinInput(ctx: Context): EditText = EditText(ctx).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(InputFilter.LengthFilter(4))
        hint = "PIN de 4 dígitos"
        gravity = Gravity.CENTER
        textSize = 22f
    }

    private fun box(ctx: Context, input: EditText): LinearLayout {
        val pad = (20 * ctx.resources.displayMetrics.density).toInt()
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
    }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    /** Pide el PIN (si hay uno y no se ha introducido hace poco) y ejecuta la acción. */
    fun requirePin(a: AppCompatActivity, title: String, onOk: () -> Unit) {
        if (!hasPin(a)) {
            onOk()
            return
        }
        if (System.currentTimeMillis() - verifiedAt < VERIFY_MS) {
            onOk()
            return
        }
        val input = pinInput(a)
        AlertDialog.Builder(a)
            .setTitle(title)
            .setView(box(a, input))
            .setPositiveButton("Aceptar") { _, _ ->
                if (checkPin(a, input.text.toString())) {
                    verifiedAt = System.currentTimeMillis()
                    onOk()
                } else {
                    toast(a, "PIN incorrecto")
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun createPin(a: AppCompatActivity, onDone: () -> Unit) {
        val first = pinInput(a)
        AlertDialog.Builder(a)
            .setTitle("Crea un PIN")
            .setMessage("Elige 4 dígitos. Lo pedirá para abrir categorías bloqueadas y cambiar estos ajustes.")
            .setView(box(a, first))
            .setPositiveButton("Siguiente") { _, _ ->
                val p1 = first.text.toString()
                if (p1.length != 4) {
                    toast(a, "El PIN debe tener 4 dígitos")
                    return@setPositiveButton
                }
                val second = pinInput(a)
                AlertDialog.Builder(a)
                    .setTitle("Repite el PIN")
                    .setView(box(a, second))
                    .setPositiveButton("Guardar") { _, _ ->
                        if (second.text.toString() == p1) {
                            savePin(a, p1)
                            toast(a, "PIN guardado")
                            onDone()
                        } else {
                            toast(a, "Los PIN no coinciden")
                        }
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Bloqueo de categorías ----------

    /** Bloquea o desbloquea una categoría (mantener pulsada). Necesita PIN. */
    fun toggleLock(a: AppCompatActivity, group: String, onDone: (Boolean) -> Unit) {
        if (!hasPin(a)) {
            toast(a, "Crea primero un PIN en Listas → Control parental")
            return
        }
        requirePin(a, "PIN para cambiar el bloqueo") {
            val set = HashSet(lockedGroups(a))
            val nowLocked = if (group in set) {
                set.remove(group)
                false
            } else {
                set.add(group)
                true
            }
            unlocked.remove(group)
            prefs(a).edit().putStringSet("locked_groups", set).apply()
            onDone(nowLocked)
        }
    }

    // ---------- Menú ----------

    fun showMenu(a: AppCompatActivity, onChanged: () -> Unit) {
        requirePin(a, "Control parental") { showMenuUnlocked(a, onChanged) }
    }

    private fun showMenuUnlocked(a: AppCompatActivity, onChanged: () -> Unit) {
        val pin = hasPin(a)
        val options = ArrayList<String>()
        options.add(if (pin) "Cambiar PIN" else "Crear PIN")
        options.add("Ocultar contenido adulto: ${if (adultHidden(a)) "SÍ" else "NO"}")
        options.add("Categorías bloqueadas (${lockedGroups(a).size})")
        if (pin) options.add("Quitar PIN")
        AlertDialog.Builder(a)
            .setTitle("Control parental")
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> createPin(a) { onChanged() }
                    1 -> {
                        prefs(a).edit().putBoolean("hide_adult", !adultHidden(a)).apply()
                        toast(a, if (adultHidden(a)) "Contenido adulto oculto" else "Contenido adulto visible")
                        onChanged()
                    }
                    2 -> showLocked(a, onChanged)
                    else -> {
                        prefs(a).edit()
                            .remove("pin_hash").remove("pin_salt").remove("locked_groups").apply()
                        unlocked.clear()
                        toast(a, "PIN eliminado")
                        onChanged()
                    }
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showLocked(a: AppCompatActivity, onChanged: () -> Unit) {
        val names = lockedGroups(a)
        val msg = if (names.isEmpty()) {
            "Ninguna. Mantén pulsada una categoría en Películas, Series o TV en directo para bloquearla con tu PIN."
        } else {
            names.sorted().joinToString("\n") + "\n\nMantén pulsada una categoría para desbloquearla."
        }
        val b = AlertDialog.Builder(a)
            .setTitle("Categorías bloqueadas")
            .setMessage(msg)
            .setPositiveButton("Cerrar", null)
        if (names.isNotEmpty()) {
            b.setNeutralButton("Desbloquear todas") { _, _ ->
                prefs(a).edit().remove("locked_groups").apply()
                unlocked.clear()
                onChanged()
            }
        }
        b.show()
    }
}
