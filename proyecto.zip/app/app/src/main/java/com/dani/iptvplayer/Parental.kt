package com.dani.iptvplayer

import android.content.Context
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest
import java.util.UUID

/** Control parental: PIN, ocultar contenido adulto y categorías bloqueadas con PIN. */
object Parental {
    private const val VERIFY_MS = 5 * 60 * 1000L

    private val ADULT = Regex(
        "(?<![a-z0-9])(?:xxx|porn\\w*|adult\\w*|er[oó]tic\\w*|hentai|playboy|sexo|sexy|sex|\\+18|18\\+)(?![a-z0-9])"
    )

    private var verifiedAt = 0L
    private val unlocked = HashSet<String>()

    private var srcRef: List<Channel>? = null
    private var cacheSig = ""
    private var cached: List<Channel> = emptyList()

    private fun prefs(ctx: Context) = Repo.prefs(ctx)

    fun hasPin(ctx: Context): Boolean = !prefs(ctx).getString("pin_hash", "").isNullOrEmpty()

    fun adultHidden(ctx: Context): Boolean = prefs(ctx).getBoolean("hide_adult", true)

    fun lockedGroups(ctx: Context): Set<String> =
        prefs(ctx).getStringSet("locked_groups", emptySet()) ?: emptySet()

    /** Claves (Channel.key) de canales, películas y series ocultos con el control parental. */
    fun hiddenKeys(ctx: Context): Set<String> =
        prefs(ctx).getStringSet("hidden_items", emptySet()) ?: emptySet()

    fun isLocked(ctx: Context, group: String): Boolean =
        group in lockedGroups(ctx) && group !in unlocked

    fun unlock(group: String) {
        unlocked.add(group)
    }

    /** Cambia cuando cambia cualquier ajuste que afecta a lo que se muestra. */
    fun stateKey(ctx: Context): String =
        "${adultHidden(ctx)}|${lockedGroups(ctx).hashCode()}|${unlocked.hashCode()}|${hiddenKeys(ctx).hashCode()}"

    fun isAdult(ch: Channel): Boolean {
        val t = (ch.group + " " + ch.name).lowercase()
        if (t.contains("adult swim")) return false
        return ADULT.containsMatchIn(t)
    }

    /**
     * Lo que se puede mostrar: sin contenido adulto (si el filtro está activo), sin elementos ocultos
     * y sin categorías bloqueadas, que quedan totalmente ocultas hasta que se muestren desde
     * Control parental → Categorías bloqueadas.
     */
    fun visible(ctx: Context): List<Channel> {
        val all = Repo.all
        val adult = adultHidden(ctx)
        val hidden = hiddenKeys(ctx)
        val locked = lockedGroups(ctx)
        if (!adult && hidden.isEmpty() && locked.isEmpty()) return all
        val sig = "$adult|${hidden.hashCode()}|${locked.hashCode()}|${unlocked.hashCode()}"
        if (srcRef !== all || cacheSig != sig) {
            cached = all.filter {
                !(adult && isAdult(it)) && it.key !in hidden && !(it.group in locked && it.group !in unlocked)
            }
            srcRef = all
            cacheSig = sig
        }
        return cached
    }

    /** Igual que visible(): las categorías bloqueadas ya no se muestran en ninguna parte. */
    fun openList(ctx: Context): List<Channel> = visible(ctx)

    fun allowed(ctx: Context, ch: Channel): Boolean =
        (!adultHidden(ctx) || !isAdult(ch)) && ch.key !in hiddenKeys(ctx) && !isLocked(ctx, ch.group)

    // ---------- PIN ----------

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun savePin(ctx: Context, pin: String) {
        val salt = UUID.randomUUID().toString()
        prefs(ctx).edit().putString("pin_salt", salt).putString("pin_hash", hash(pin, salt)).apply()
        verifiedAt = System.currentTimeMillis()
    }

    private fun checkPin(ctx: Context, pin: String): Boolean {
        val p = prefs(ctx)
        val salt = p.getString("pin_salt", "") ?: ""
        return hash(pin, salt) == p.getString("pin_hash", "")
    }

    private fun pinInput(ctx: Context): EditText = EditText(ctx).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(InputFilter.LengthFilter(4))
        hint = "PIN de 4 dígitos"
        gravity = Gravity.CENTER
        textSize = 22f
    }

    private fun box(ctx: Context, input: EditText): LinearLayout {
        val pad = (20 * ctx.resources.displayMetrics.density).toInt()
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
    }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    /** Pide el PIN (si hay uno y no se ha introducido hace poco) y ejecuta la acción. */
    fun requirePin(a: AppCompatActivity, title: String, onOk: () -> Unit) {
        if (!hasPin(a)) {
            onOk()
            return
        }
        if (System.currentTimeMillis() - verifiedAt < VERIFY_MS) {
            onOk()
            return
        }
        val input = pinInput(a)
        AlertDialog.Builder(a)
            .setTitle(title)
            .setView(box(a, input))
            .setPositiveButton("Aceptar") { _, _ ->
                if (checkPin(a, input.text.toString())) {
                    verifiedAt = System.currentTimeMillis()
                    onOk()
                } else {
                    toast(a, "PIN incorrecto")
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun createPin(a: AppCompatActivity, onDone: () -> Unit) {
        val first = pinInput(a)
        AlertDialog.Builder(a)
            .setTitle("Crea un PIN")
            .setMessage("Elige 4 dígitos. Lo pedirá para abrir categorías bloqueadas y cambiar estos ajustes.")
            .setView(box(a, first))
            .setPositiveButton("Siguiente") { _, _ ->
                val p1 = first.text.toString()
                if (p1.length != 4) {
                    toast(a, "El PIN debe tener 4 dígitos")
                    return@setPositiveButton
                }
                val second = pinInput(a)
                AlertDialog.Builder(a)
                    .setTitle("Repite el PIN")
                    .setView(box(a, second))
                    .setPositiveButton("Guardar") { _, _ ->
                        if (second.text.toString() == p1) {
                            savePin(a, p1)
                            toast(a, "PIN guardado")
                            onDone()
                        } else {
                            toast(a, "Los PIN no coinciden")
                        }
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Bloqueo de categorías ----------

    /** Bloquea o desbloquea una categoría (mantener pulsada). Necesita PIN. */
    fun toggleLock(a: AppCompatActivity, group: String, onDone: (Boolean) -> Unit) {
        if (!hasPin(a)) {
            toast(a, "Crea primero un PIN en Listas → Control parental")
            return
        }
        requirePin(a, "PIN para cambiar el bloqueo") {
            val set = HashSet(lockedGroups(a))
            val nowLocked = if (group in set) {
                set.remove(group)
                false
            } else {
                set.add(group)
                true
            }
            unlocked.remove(group)
            prefs(a).edit().putStringSet("locked_groups", set).apply()
            onDone(nowLocked)
        }
    }

    // ---------- Ocultar canales / películas / series ----------

    /** Oculta un canal, película o serie concretos. Necesita PIN. */
    fun hideItem(a: AppCompatActivity, ch: Channel, onDone: () -> Unit) {
        if (!hasPin(a)) {
            toast(a, "Crea primero un PIN en Listas → Control parental")
            return
        }
        requirePin(a, "PIN para ocultar «${ch.name}»") {
            val set = HashSet(hiddenKeys(a))
            set.add(ch.key)
            prefs(a).edit().putStringSet("hidden_items", set).apply()
            toast(a, "Oculto: ${ch.name}")
            onDone()
        }
    }

    private fun showHidden(a: AppCompatActivity, onChanged: () -> Unit) {
        val keys = hiddenKeys(a)
        if (keys.isEmpty()) {
            AlertDialog.Builder(a)
                .setTitle("Elementos ocultos")
                .setMessage("Ninguno. Mantén pulsado un canal, película o serie y elige «Ocultar» para esconderlo.")
                .setPositiveButton("Cerrar", null)
                .show()
            return
        }
        // Nombres a partir de la lista completa (lo oculto sigue en Repo.all)
        val byKey = HashMap<String, Channel>()
        for (c in Repo.all) if (c.key in keys) byKey[c.key] = c
        val sorted = keys.sortedBy { (byKey[it]?.name ?: it).lowercase() }
        val labels = sorted.map { k ->
            val c = byKey[k]
            if (c == null) "(no está en la lista actual)" else {
                val kind = when (c.type) {
                    ContentType.LIVE -> "TV"
                    ContentType.MOVIE -> "Película"
                    ContentType.SERIES -> "Serie"
                }
                "${c.name}  ·  $kind"
            }
        }.toTypedArray()
        val checked = BooleanArray(sorted.size)
        AlertDialog.Builder(a)
            .setTitle("Ocultos: marca los que quieras mostrar de nuevo")
            .setMultiChoiceItems(labels, checked) { _, i, on -> checked[i] = on }
            .setPositiveButton("Mostrar marcados") { _, _ ->
                val set = HashSet(hiddenKeys(a))
                sorted.forEachIndexed { i, k -> if (checked[i]) set.remove(k) }
                prefs(a).edit().putStringSet("hidden_items", set).apply()
                onChanged()
            }
            .setNeutralButton("Mostrar todos") { _, _ ->
                prefs(a).edit().remove("hidden_items").apply()
                onChanged()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    // ---------- Menú ----------

    fun showMenu(a: AppCompatActivity, onChanged: () -> Unit) {
        requirePin(a, "Control parental") { showMenuUnlocked(a, onChanged) }
    }

    private fun showMenuUnlocked(a: AppCompatActivity, onChanged: () -> Unit) {
        val pin = hasPin(a)
        val options = ArrayList<String>()
        options.add(if (pin) "Cambiar PIN" else "Crear PIN")
        options.add("Ocultar contenido adulto: ${if (adultHidden(a)) "SÍ" else "NO"}")
        options.add("Categorías bloqueadas (${lockedGroups(a).size})")
        options.add("Canales y películas ocultos (${hiddenKeys(a).size})")
        if (pin) options.add("Quitar PIN")
        AlertDialog.Builder(a)
            .setTitle("Control parental")
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> createPin(a) { onChanged() }
                    1 -> {
                        prefs(a).edit().putBoolean("hide_adult", !adultHidden(a)).apply()
                        toast(a, if (adultHidden(a)) "Contenido adulto oculto" else "Contenido adulto visible")
                        onChanged()
                    }
                    2 -> showLocked(a, onChanged)
                    3 -> showHidden(a, onChanged)
                    else -> {
                        prefs(a).edit()
                            .remove("pin_hash").remove("pin_salt").remove("locked_groups").remove("hidden_items").apply()
                        unlocked.clear()
                        toast(a, "PIN eliminado")
                        onChanged()
                    }
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showLocked(a: AppCompatActivity, onChanged: () -> Unit) {
        val names = lockedGroups(a).sorted()
        if (names.isEmpty()) {
            AlertDialog.Builder(a)
                .setTitle("Categorías bloqueadas")
                .setMessage("Ninguna. Mantén pulsada una categoría en Películas, Series o TV en directo para bloquearla: quedará totalmente oculta.")
                .setPositiveButton("Cerrar", null)
                .show()
            return
        }
        val labels = names.map { if (it in unlocked) "$it  ·  visible ahora" else "$it  ·  oculta" }.toTypedArray()
        AlertDialog.Builder(a)
            .setTitle("Categorías bloqueadas (ocultas)")
            .setItems(labels) { _, i -> showLockedOptions(a, names[i], onChanged) }
            .setNeutralButton("Quitar todos los bloqueos") { _, _ ->
                prefs(a).edit().remove("locked_groups").apply()
                unlocked.clear()
                onChanged()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showLockedOptions(a: AppCompatActivity, group: String, onChanged: () -> Unit) {
        val temp = group in unlocked
        val options = arrayOf(
            if (temp) "Volver a ocultarla ahora" else "Verla hasta cerrar la app",
            "Quitar el bloqueo (se verá siempre)"
        )
        AlertDialog.Builder(a)
            .setTitle(group)
            .setItems(options) { _, which ->
                if (which == 0) {
                    if (temp) unlocked.remove(group) else unlocked.add(group)
                } else {
                    val set = HashSet(lockedGroups(a))
                    set.remove(group)
                    unlocked.remove(group)
                    prefs(a).edit().putStringSet("locked_groups", set).apply()
                }
                onChanged()
            }
            .setNegativeButton("Atrás") { _, _ -> showLocked(a, onChanged) }
            .show()
    }
}
