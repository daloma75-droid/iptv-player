package com.dani.iptvplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import kotlin.math.min

enum class CardKind { POSTER, LIVE, CONTINUE }

private fun View.dpPx(n: Int): Int = (n * resources.displayMetrics.density).toInt()

/** Tarjeta de una fila horizontal del inicio (carátula, canal o "seguir viendo"). */
class CardAdapter(
    private val kind: CardKind,
    private val items: List<Channel>,
    private val favorites: Set<String>,
    private val entries: List<Recents.Entry>?,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<CardAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val progress: ProgressBar = v.findViewById(R.id.progress)
        val name: TextView = v.findViewById(R.id.name)
        val sub: TextView = v.findViewById(R.id.sub)
        val star: TextView = v.findViewById(R.id.star)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_card, parent, false)
        v.zoomOnFocus(1.04f)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        val v = holder.itemView

        val widthDp: Int
        val heightDp: Int
        when (kind) {
            CardKind.POSTER -> { widthDp = 116; heightDp = 174 }
            CardKind.LIVE -> { widthDp = 156; heightDp = 88 }
            CardKind.CONTINUE -> { widthDp = 240; heightDp = 135 }
        }
        // El padding de la tarjeta suma 8dp
        val lp = v.layoutParams
        lp.width = v.dpPx(widthDp + 8)
        v.layoutParams = lp
        val img = holder.logo.layoutParams
        img.height = v.dpPx(heightDp)
        holder.logo.layoutParams = img

        val placeholder = if (kind == CardKind.LIVE) R.drawable.ic_tv else R.drawable.poster_empty
        if (kind == CardKind.LIVE) {
            holder.logo.scaleType = ImageView.ScaleType.FIT_CENTER
            holder.logo.setPadding(v.dpPx(16), v.dpPx(12), v.dpPx(16), v.dpPx(12))
        } else {
            holder.logo.scaleType = ImageView.ScaleType.CENTER_CROP
            holder.logo.setPadding(0, 0, 0, 0)
        }
        if (kind == CardKind.POSTER) TmdbPosters.load(v.context, holder.logo, c)
        else if (kind == CardKind.LIVE) Logos.load(holder.logo, c, placeholder, fade = true)
        else if (c.logo.isNotEmpty()) holder.logo.load(c.logo) {
            crossfade(true); placeholder(placeholder); error(placeholder)
        } else holder.logo.load(placeholder)

        holder.name.text = c.name
        holder.star.visibility = if (c.key in favorites) View.VISIBLE else View.GONE

        val e = if (kind == CardKind.CONTINUE) entries?.getOrNull(position) else null
        if (e != null && e.dur > 0) {
            holder.progress.visibility = View.VISIBLE
            holder.progress.progress = ((e.pos * 1000) / e.dur).toInt().coerceIn(0, 1000)
            val mins = ((e.dur - e.pos) / 60000L).coerceAtLeast(1L)
            holder.sub.visibility = View.VISIBLE
            holder.sub.text = if (mins >= 60) "${mins / 60}h ${mins % 60}m restantes" else "$mins min restantes"
        } else {
            holder.progress.visibility = View.GONE
            holder.sub.visibility = View.GONE
        }

        v.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
    }
}

/** Banner destacado a pantalla completa con título y botón de reproducir. */
class HeroAdapter(
    private val items: List<Channel>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<HeroAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.heroImage)
        val badge: TextView = v.findViewById(R.id.heroBadge)
        val title: TextView = v.findViewById(R.id.heroTitle)
        val sub: TextView = v.findViewById(R.id.heroSub)
        val play: View = v.findViewById(R.id.heroPlay)
        val card: View = v.findViewById(R.id.heroCard)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_hero, parent, false)
        val dm = parent.resources.displayMetrics
        val d = dm.density
        // En pantallas anchas (horizontal / TV) el banner no ocupa todo el ancho
        val wide = dm.widthPixels > 700 * d
        val w = if (wide) (560 * d).toInt() else dm.widthPixels
        val cardW = w - (24 * d).toInt()
        val h = min((cardW * 1.15f).toInt(), (dm.heightPixels * 0.62f).toInt())
        val lp = v.layoutParams
        lp.width = w
        lp.height = h
        v.layoutParams = lp
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        holder.title.text = c.name
        holder.sub.text = c.group
        holder.badge.text = when (c.type) {
            ContentType.MOVIE -> "PELÍCULA"
            ContentType.SERIES -> "SERIE"
            ContentType.LIVE -> "EN DIRECTO"
        }
        TmdbPosters.load(holder.itemView.context, holder.image, c)
        val click = View.OnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        holder.play.setOnClickListener(click)
        holder.card.setOnClickListener(click)
    }
}
