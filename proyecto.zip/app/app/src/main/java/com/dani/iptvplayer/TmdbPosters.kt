package com.dani.iptvplayer

import android.content.Context
import android.widget.ImageView
import coil.load
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Recupera carátulas ausentes o rotas mediante TMDB. La clave se configura en Ajustes. */
object TmdbPosters {
    private const val PREFS = "tmdb_posters"
    private const val KEY = "api_key"

    // Caché propia (versión 2). La anterior guardaba "sin resultado" también cuando la consulta
    // fallaba por la VPN o la red, y esa carátula ya no se volvía a pedir nunca.
    private const val CACHE = "tmdb_cache2"
    private const val NEGATIVE_TTL_MS = 3L * 24 * 60 * 60 * 1000

    private val executor = Executors.newFixedThreadPool(3)
    private val waiters = HashMap<String, MutableList<(String?) -> Unit>>()

    fun apiKey(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
    fun saveApiKey(context: Context, value: String) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, value.trim()).apply() }

    /** Olvida todo lo buscado en TMDB (aciertos y fallos) para volver a consultarlo. */
    fun clearCache(context: Context) {
        context.applicationContext.getSharedPreferences(CACHE, Context.MODE_PRIVATE).edit().clear().apply()
        // Restos de la caché antigua
        val old = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val e = old.edit()
        for (k in old.all.keys) if (k.startsWith("poster_")) e.remove(k)
        e.apply()
    }

    fun load(context: Context, image: ImageView, channel: Channel) {
        val token = channel.key
        image.tag = token
        val app = context.applicationContext
        val original = channel.logo.trim()

        fun loadOriginal(retryIfFails: Boolean) {
            image.load(original) {
                crossfade(true)
                error(R.drawable.poster_empty)
                listener(onError = { _, _ ->
                    find(app, channel) { url ->
                        image.post {
                            if (image.tag != token) return@post
                            if (!url.isNullOrBlank()) {
                                image.load(url) { crossfade(true) }
                            } else if (retryIfFails) {
                                // Fallo de red puntual (típico al cambiar la VPN): un segundo intento
                                image.postDelayed({ if (image.tag == token) loadOriginal(false) }, 3500)
                            }
                        }
                    }
                })
            }
        }

        if (original.isNotEmpty()) {
            loadOriginal(true)
        } else {
            image.load(R.drawable.poster_empty)
            find(app, channel) { url ->
                image.post { if (image.tag == token && !url.isNullOrBlank()) image.load(url) { crossfade(true) } }
            }
        }
    }

    private fun find(context: Context, channel: Channel, done: (String?) -> Unit) {
        if (channel.type == ContentType.LIVE) { done(null); return }
        val key = apiKey(context)
        if (key.isBlank()) { done(null); return }
        val cache = context.getSharedPreferences(CACHE, Context.MODE_PRIVATE)
        val cacheKey = "p_" + channel.key.hashCode().toUInt().toString(16)

        val cached = cache.getString(cacheKey, null)
        if (cached != null) {
            if (cached.startsWith("http")) { done(cached); return }
            // "-<momento>": no había coincidencia; se vuelve a intentar pasados unos días
            val t = cached.removePrefix("-").toLongOrNull() ?: 0L
            if (System.currentTimeMillis() - t < NEGATIVE_TTL_MS) { done(null); return }
        }

        synchronized(waiters) {
            val list = waiters[cacheKey]
            if (list != null) { list.add(done); return }
            waiters[cacheKey] = mutableListOf(done)
        }

        executor.execute {
            var result: String? = null
            try {
                val (title, year) = cleanTitle(channel.name)
                val tv = channel.type == ContentType.SERIES
                val endpoint = if (tv) "tv" else "movie"
                val yearParam = if (year != null) (if (tv) "&first_air_date_year=$year" else "&year=$year") else ""
                val url = "https://api.themoviedb.org/3/search/$endpoint?api_key=$key&language=es-ES" +
                    "&query=${URLEncoder.encode(title, "UTF-8")}&include_adult=false$yearParam"
                val req = Request.Builder().url(url).header("Accept", "application/json").build()
                Net.http.newCall(req).execute().use { response ->
                    if (response.isSuccessful) {
                        val results = JSONObject(response.body?.string().orEmpty()).optJSONArray("results")
                        if (results != null) {
                            for (i in 0 until minOf(results.length(), 5)) {
                                val path = results.getJSONObject(i).optString("poster_path", "")
                                if (path.isNotBlank() && path != "null") {
                                    result = "https://image.tmdb.org/t/p/w500$path"
                                    break
                                }
                            }
                        }
                        // Solo aquí es un "no hay carátula" de verdad. Los errores de red o HTTP no se guardan.
                        cache.edit().putString(cacheKey, result ?: "-${System.currentTimeMillis()}").apply()
                    }
                }
            } catch (_: Exception) {
            }
            val callbacks = synchronized(waiters) { waiters.remove(cacheKey) }.orEmpty()
            for (cb in callbacks) cb(result)
        }
    }

    /** Título limpio y año (si aparece) para buscar en TMDB. */
    private fun cleanTitle(raw: String): Pair<String, String?> {
        var t = raw
        val year = Regex("(?<!\\d)((?:19[5-9]|20[0-3])\\d)(?!\\d)").findAll(t).lastOrNull()?.value
        t = t.replace(Regex("^\\s*[\\[(|]?\\s*(ES|ESP|SPA|LAT|LATINO|CAST)\\s*[\\])|:-]+\\s*", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("[\\[(][^\\])]*[\\])]"), " ")
        t = t.replace(Regex("(?i)\\b(4k|uhd|fhd|hd|1080p|720p|480p|bluray|brrip|web-dl|webrip|hdtv|dual audio|castellano|latino|subtitulado)\\b"), " ")
        t = t.replace(Regex("[._]+"), " ")
        if (year != null) t = t.replace(Regex("\\s*-?\\s*$year\\s*$"), "")
        return Pair(t.replace(Regex("\\s+"), " ").trim().ifEmpty { raw.trim() }, year)
    }
}
