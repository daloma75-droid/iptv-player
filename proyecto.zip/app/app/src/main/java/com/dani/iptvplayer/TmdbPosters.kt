package com.dani.iptvplayer

import android.content.Context
import android.widget.ImageView
import coil.load
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Recupera carátulas ausentes o rotas mediante TMDB. La clave se configura en Ajustes. */
object TmdbPosters {
    private const val PREFS = "tmdb_posters"
    private const val KEY = "api_key"
    private val http = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS).build()
    private val executor = Executors.newFixedThreadPool(2)
    private val pending = ConcurrentHashMap.newKeySet<String>()

    fun apiKey(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
    fun saveApiKey(context: Context, value: String) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, value.trim()).apply() }

    fun load(context: Context, image: ImageView, channel: Channel) {
        val token = channel.key
        image.tag = token
        val original = channel.logo.trim()
        if (original.isNotEmpty()) {
            image.load(original) {
                crossfade(true)
                error(android.R.drawable.ic_menu_report_image)
                listener(onError = { _, _ -> find(context.applicationContext, channel) { url ->
                    image.post { if (image.tag == token && !url.isNullOrBlank()) image.load(url) { crossfade(true) } }
                } })
            }
        } else {
            image.load(R.drawable.poster_empty)
            find(context.applicationContext, channel) { url ->
                image.post { if (image.tag == token && !url.isNullOrBlank()) image.load(url) { crossfade(true) } }
            }
        }
    }

    private fun find(context: Context, channel: Channel, done: (String?) -> Unit) {
        if (channel.type == ContentType.LIVE) { done(null); return }
        val key = apiKey(context)
        if (key.isBlank()) { done(null); return }
        val cache = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val cacheKey = "poster_" + channel.key.hashCode().toUInt().toString(16)
        if (cache.contains(cacheKey)) { done(cache.getString(cacheKey, "")); return }
        if (!pending.add(cacheKey)) { done(null); return }
        executor.execute {
            var result: String? = null
            try {
                val title = cleanTitle(channel.name)
                val endpoint = if (channel.type == ContentType.SERIES) "tv" else "movie"
                val url = "https://api.themoviedb.org/3/search/$endpoint?api_key=$key&language=es-ES&query=${URLEncoder.encode(title, "UTF-8")}&include_adult=false"
                val req = Request.Builder().url(url).header("Accept", "application/json").build()
                http.newCall(req).execute().use { response ->
                    if (response.isSuccessful) {
                        val results = JSONObject(response.body?.string().orEmpty()).optJSONArray("results")
                        if (results != null && results.length() > 0) {
                            val path = results.getJSONObject(0).optString("poster_path", "")
                            if (path.isNotBlank() && path != "null") result = "https://image.tmdb.org/t/p/w500$path"
                        }
                    }
                }
                cache.edit().putString(cacheKey, result ?: "").apply()
            } catch (_: Exception) { }
            pending.remove(cacheKey)
            done(result)
        }
    }

    private fun cleanTitle(raw: String): String = raw
        .replace(Regex("(?i)\\b(4k|uhd|1080p|720p|480p|bluray|brrip|web-dl|webrip|hdtv|dual audio|castellano|latino)\\b"), " ")
        .replace(Regex("[._]+"), " ")
        .replace(Regex("\\s+"), " ").trim()
}
