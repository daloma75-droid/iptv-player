package com.dani.iptvplayer

import org.junit.Assert.assertEquals
import org.junit.Test

class ClassifierTest {

    @Test
    fun xtreamPathsDecideTheType() {
        assertEquals(ContentType.LIVE, Classifier.classify("http://h/live/u/p/1.ts", ""))
        assertEquals(ContentType.MOVIE, Classifier.classify("http://h/movie/u/p/1.mkv", ""))
        assertEquals(ContentType.SERIES, Classifier.classify("http://h/series/u/p/1.mkv", ""))
    }

    @Test
    fun videoFileIsMovieUnlessGroupSaysSeries() {
        assertEquals(ContentType.MOVIE, Classifier.classify("http://h/x/film.mp4", "Cine"))
        assertEquals(ContentType.SERIES, Classifier.classify("http://h/x/ep1.mkv", "Series ES"))
    }

    @Test
    fun hlsIsLiveEvenInMovieGroup() {
        assertEquals(ContentType.LIVE, Classifier.classify("http://h/x/canal.m3u8", "Pelis"))
    }

    @Test
    fun fallsBackToGroupName() {
        assertEquals(ContentType.SERIES, Classifier.classify("http://h/stream?id=1", "Temporada 2"))
        assertEquals(ContentType.MOVIE, Classifier.classify("http://h/stream", "Películas HD"))
        assertEquals(ContentType.LIVE, Classifier.classify("http://h/stream", "Deportes"))
    }
}
