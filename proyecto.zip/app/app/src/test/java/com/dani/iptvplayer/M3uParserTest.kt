package com.dani.iptvplayer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M3uParserTest {

    @Test
    fun parsesBasicEntry() {
        val text = """
            #EXTM3U
            #EXTINF:-1 tvg-id="a" tvg-logo="http://img/logo.png" group-title="Noticias",Canal Uno
            http://host/live/u/p/1.ts
        """.trimIndent()
        val list = M3uParser.parse(text)
        assertEquals(1, list.size)
        val c = list[0]
        assertEquals("Canal Uno", c.name)
        assertEquals("http://host/live/u/p/1.ts", c.url)
        assertEquals("Noticias", c.group)
        assertEquals("http://img/logo.png", c.logo)
        assertEquals(ContentType.LIVE, c.type)
    }

    @Test
    fun commaInsideQuotesDoesNotSplitTitle() {
        val text = "#EXTINF:-1 tvg-name=\"A, B\" group-title=\"Cine\",Nombre\nhttp://host/movie/u/p/2.mkv"
        val c = M3uParser.parse(text).single()
        assertEquals("Nombre", c.name)
        assertEquals(ContentType.MOVIE, c.type)
    }

    @Test
    fun readsVlcOptions() {
        val text = """
            #EXTINF:-1,Canal
            #EXTVLCOPT:http-user-agent=MiUA
            #EXTVLCOPT:http-referrer=http://ref.com
            http://x.com/a.m3u8
        """.trimIndent()
        val c = M3uParser.parse(text).single()
        assertEquals("MiUA", c.userAgent)
        assertEquals("http://ref.com", c.headers["Referer"])
        assertEquals("Sin grupo", c.group)
    }

    @Test
    fun readsKodiPipeHeaders() {
        val text = "#EXTINF:-1,Canal\nhttp://x.com/a.m3u8|User-Agent=Foo&Referer=http://r.com"
        val c = M3uParser.parse(text).single()
        assertEquals("http://x.com/a.m3u8", c.url)
        assertEquals("Foo", c.userAgent)
        assertEquals("http://r.com", c.headers["Referer"])
    }

    @Test
    fun normalizesMulticastUrls() {
        val c = M3uParser.parse("udp://@239.0.0.1:1234").single()
        assertEquals("udp://239.0.0.1:1234", c.url)
    }

    @Test
    fun toleratesBomAndBlankLines() {
        val text = "\uFEFF#EXTM3U\n\n#EXTINF:-1,Uno\n\nhttp://h/1.m3u8\n\n#EXTINF:-1,Dos\nhttp://h/2.m3u8\n"
        val list = M3uParser.parse(text)
        assertEquals(listOf("Uno", "Dos"), list.map { it.name })
    }

    @Test
    fun emptyInputGivesEmptyList() {
        assertTrue(M3uParser.parse("").isEmpty())
        assertTrue(M3uParser.parse("#EXTM3U\n").isEmpty())
    }
}
