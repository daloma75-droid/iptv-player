# IPTV Player

Reproductor IPTV para Android, móvil y TV box (mando a distancia).

- Interfaz estilo plataforma de streaming: banner destacado, filas horizontales ("Seguir viendo", "Mi lista", TV en directo y categorías), filtros en píldora y barra inferior de 5 pestañas (Inicio, Directo, Películas, Series, Buscar)
- **Orden de TV en directo**: primero las cadenas nacionales (La 1, La 2, Antena 3, Cuatro, Telecinco, laSexta, 24h, Clan…), después los canales de Movistar Plus+ (Plus+, Liga de Campeones, LaLiga, Deportes, Series, Cine…) y por último el resto en el orden de tu lista. Las categorías se ordenan igual. Los canales reconocidos usan su logotipo oficial (repositorio tv-logo/tv-logos) y, si no carga, el de tu lista (`ChannelOrder.kt`)
- **Control parental**: PIN de 4 dígitos, ocultar contenido adulto (por palabras clave) y bloquear categorías (mantén pulsada una categoría): las bloqueadas quedan totalmente ocultas y se gestionan en Control parental → Categorías bloqueadas; **ocultar canales, películas y series concretos** (mantén pulsado un elemento → «Ocultar»; se recuperan en Control parental → Canales y películas ocultos)
- **VPN al iniciar**: detecta si hay VPN activa; si no, abre Proton VPN y espera a que te conectes (Android no permite conectarla automáticamente; hay un botón para activar «VPN siempre activa» y que Android la conecte sola)
- **Seguir viendo**: películas y episodios retoman donde los dejaste
- Listas **M3U/M3U8** (URL o archivo, también .gz) y **Xtream Codes** (servidor, usuario y contraseña)
- Si pegas un enlace `get.php?username=…&password=…`, usa la API Xtream automáticamente
- En listas M3U separa directo / películas / series por la URL, la extensión y el grupo
- Episodios de series Xtream por temporadas
- Carátulas: se piden con User-Agent de navegador y se corrigen rutas relativas, "null" y URLs sin protocolo
- **Actualización de la lista**: manual (Listas → Actualizar lista ahora) y automática al abrir la app, por defecto cada 3 días (Ajustes → cambiar a cada día, semana o nunca). Las listas de archivo no se pueden actualizar solas
- **Vídeo de inicio** al abrir la app (`res/raw/intro.mp4`); se salta tocando la pantalla o con cualquier tecla del mando, y se puede desactivar en Ajustes
- **Idiomas**: al cargar una lista por primera vez la app analiza los idiomas (por el nombre de las categorías y de los canales: `ES |`, `[EN]`, «Latino»…) y pregunta cuáles quieres ver en TV, películas y series. Los demás quedan bloqueados y ocultos en el control parental (Control parental → Idiomas bloqueados; se pueden ver hasta cerrar la app o desbloquear). Se puede repetir desde Control parental → Elegir idiomas
- **Descargas** de películas y episodios: mantén pulsado un elemento → «Descargar» (en series, eliges episodios). Servicio en segundo plano con notificación, reanuda si se corta, prueba varios User-Agent. Se ven en Listas → Descargas y se reproducen sin conexión ni VPN. Solo archivos directos (no HLS/.m3u8). Se guardan en el almacenamiento de la app
- **VPN propia (WireGuard)**: se importa (o pega) el archivo `.conf` WireGuard que genera Proton VPN en la cuenta (Listas → Ajustes → VPN propia). Al abrir la app pregunta «¿Activar la VPN?» y, si dices que sí, conecta directamente sin abrir otras apps (Android pide un permiso de VPN solo la primera vez). Usa la librería oficial `com.wireguard.android:tunnel`; si no hay configuración, sigue funcionando el modo anterior de abrir Proton VPN
- Búsqueda, favoritos (pulsación larga / mantener OK) y logos
- Reproduce HLS, DASH, TS, MP4/MKV, RTSP, RTMP y UDP/multicast
- Reintenta solo con otros User-Agent si el servidor rechaza la conexión; el error muestra la causa
- Mando: ↑/↓ cambian de canal, ←/→ saltan 10 s en películas, OK muestra los controles

> La app es solo un reproductor: no incluye canales ni listas.

## Mejoras para Android TV / TV box

- **Selector de archivos**: si el dispositivo no tiene selector de documentos (habitual en TV box), la app ya no se cierra; avisa y propone usar URL, Xtream o «Pegar la configuración».
- **Reproductor con mando**: al mostrar los controles el foco va a reproducir/pausa; **Atrás** primero oculta los controles y, si ya están ocultos, sale del reproductor.
- **Teclas multimedia**: play/pausa, avance y retroceso rápido (±10 s en películas) y siguiente/anterior (cambia de canal o episodio).

- **Seguridad**: las credenciales (Xtream, clave TMDB, configuración WireGuard, PIN) se guardan cifradas con el Keystore de Android; las antiguas se migran solas. El PIN se bloquea temporalmente tras 5 fallos seguidos. Se desactivó la copia de seguridad automática porque los datos cifrados no se pueden restaurar en otro dispositivo.
- **Reproductor**: botón «Audio/Sub» para elegir pista de audio o subtítulos; si Android reinicia la app, se recupera el último título.
- **TV**: texto un 20 % mayor en TV y aviso (una vez) de cómo abrir el menú con el mando.
- **Calidad**: tests unitarios del parser M3U y del clasificador, y CI de GitHub Actions (tests, lint y APK).
- Icono adaptativo para Android 8+.

## Cambios de la versión 4.0.1

- Sin vídeo ni animación al abrir la app (se quitó `intro.mp4` y su ajuste).
- TV en directo: si un canal está repetido (SD/HD/FHD…) solo se deja la mejor versión, prefiriendo Full HD; en el resto de canales los Full HD van primero.
- Novedades: una sola fila «Novedades · Películas y series» ordenada por fecha de estreno. Películas y series (listas, categorías y filas) se ordenan por estreno: fecha del servidor Xtream (`releaseDate`/`year`), si no el año del título, si no la fecha de alta. La lista Xtream se vuelve a descargar una vez para obtener esas fechas.

## Novedades de la versión 4.0.0

- **Carátulas con la VPN activa**: ya no se quedan vacías. Cliente de red propio (`Net.kt`) con reintentos, DNS de respaldo (DNS sobre HTTPS) y conexiones que se renuevan al conectar o quitar la VPN; las pantallas vuelven a pedir las imágenes cuando cambia la VPN. Además, TMDB ya no guarda como «sin carátula» una consulta que falló por la red.
- **Tres botones en el inicio**: *Actualizar* (descarga la lista de nuevo y borra la caché de carátulas), *Conectar VPN / Quitar VPN* (conecta directamente la VPN propia WireGuard; hay que haber importado antes el `.conf`) y *Apagar* (desconecta la VPN propia y termina la app).
- **Orden por novedades** en Películas y Series: lo más nuevo primero, tanto en la lista como en las categorías y en las filas del inicio, con filas «Novedades». Se usa la fecha de alta del servidor Xtream; sin ella, el año del título; sin ninguno, el orden de la lista. Las listas Xtream guardadas con versiones anteriores se vuelven a descargar una vez para obtener las fechas.
- **TV en directo**: orden nacionales → Movistar Plus+ → resto, también cuando el nombre trae prefijo de país («ES| M+ LaLiga») o etiquetas como UHD/1080p. El logotipo prueba varios nombres de archivo del repositorio antes de usar el de tu lista.

## Carátulas automáticas con TMDB (versión 3.9.7)

- Entra en **Listas → Ajustes → Carátulas automáticas TMDB** e introduce tu clave API v3 gratuita de TMDB.
- Las carátulas originales de la lista IPTV se mantienen si cargan correctamente.
- Si falta una carátula o la imagen original falla, la app busca el título en TMDB (películas o series según el tipo) y carga el póster encontrado.
- Los resultados se guardan en caché; las búsquedas sin coincidencia se repiten pasados 3 días y los fallos de red no se guardan.
- La clave se guarda localmente en las preferencias de la aplicación. No se incluye ninguna clave API en el proyecto.

## Conseguir el APK

1. Sustituye `proyecto.zip` de tu repositorio por este y sube el cambio (rama `main`).
2. En **Actions** espera a que termine "Build APK" (3-5 min).
3. Descarga `app-debug.apk` desde **Releases → IPTV Player (última versión)**.
