# IPTV Player

Reproductor IPTV para Android, móvil y TV box (mando a distancia).

- Inicio estilo Smarters: **TV en directo**, **Películas** y **Series**, con categorías y carátulas
- Listas **M3U/M3U8** (URL o archivo, también .gz) y **Xtream Codes** (servidor, usuario y contraseña)
- Si pegas un enlace `get.php?username=…&password=…`, usa la API Xtream automáticamente
- En listas M3U separa directo / películas / series por la URL, la extensión y el grupo
- Episodios de series Xtream por temporadas
- Búsqueda, favoritos (pulsación larga / mantener OK) y logos
- Reproduce HLS, DASH, TS, MP4/MKV, RTSP, RTMP y UDP/multicast
- Reintenta solo con otros User-Agent si el servidor rechaza la conexión; el error muestra la causa
- Mando: ↑/↓ cambian de canal, ←/→ saltan 10 s en películas, OK muestra los controles

> La app es solo un reproductor: no incluye canales ni listas.

## Conseguir el APK

1. Sustituye `proyecto.zip` de tu repositorio por este y sube el cambio (rama `main`).
2. En **Actions** espera a que termine "Build APK" (3-5 min).
3. Descarga `app-debug.apk` desde **Releases → IPTV Player (última versión)**.
