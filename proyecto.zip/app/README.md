# IPTV Player

Reproductor de listas IPTV (M3U/M3U8) para Android y Android TV.

- Carga listas por URL, por **Xtream Codes** (servidor/usuario/contraseña) o desde un archivo
- Acepta M3U/M3U8 (también comprimidas en .gz), listas de URLs sueltas y enlaces directos a un stream HLS
- Respeta cabeceras por canal: `#EXTVLCOPT` (user-agent, referrer), `#KODIPROP` y el formato `url|User-Agent=…&Referer=…`
- Reproduce HLS, DASH, TS, MP4/MKV, RTSP, RTMP y UDP/multicast
- Búsqueda, filtro por grupos, favoritos (pulsación larga en un canal)
- Logos de canal, reproducción HLS/TS/MP4 con Media3 (ExoPlayer)
- Botones de canal anterior/siguiente y pantalla completa
- Recuerda la última lista (funciona sin recargarla)

> La app es solo un reproductor: no incluye canales ni listas.

## Conseguir el APK

1. Crea un repositorio en GitHub y sube todo este proyecto (rama `main`).
2. Ve a la pestaña **Actions** y espera a que termine "Build APK" (3-5 min).
3. Descarga `app-debug.apk` desde **Releases → IPTV Player (última versión)**.
4. Instálalo en el móvil (permite "instalar apps desconocidas").

Cada vez que hagas un cambio y lo subas, se genera un APK nuevo.
