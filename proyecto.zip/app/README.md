# IPTV Player

Reproductor IPTV para Android, móvil y TV box (mando a distancia).

- Interfaz estilo plataforma de streaming: banner destacado, filas horizontales ("Seguir viendo", "Mi lista", TV en directo y categorías), filtros en píldora y barra inferior de 5 pestañas (Inicio, Directo, Películas, Series, Buscar)
- **Control parental**: PIN de 4 dígitos, ocultar contenido adulto (por palabras clave) y bloquear categorías con PIN (mantén pulsada una categoría)
- **VPN al iniciar**: detecta si hay VPN activa; si no, abre Proton VPN y espera a que te conectes (Android no permite conectarla automáticamente; hay un botón para activar «VPN siempre activa» y que Android la conecte sola)
- **Seguir viendo**: películas y episodios retoman donde los dejaste
- Listas **M3U/M3U8** (URL o archivo, también .gz) y **Xtream Codes** (servidor, usuario y contraseña)
- Si pegas un enlace `get.php?username=…&password=…`, usa la API Xtream automáticamente
- En listas M3U separa directo / películas / series por la URL, la extensión y el grupo
- Episodios de series Xtream por temporadas
- Búsqueda, favoritos (pulsación larga / mantener OK) y logos
- Reproduce HLS, DASH, TS, MP4/MKV, RTSP, RTMP y UDP/multicast
- Reintenta solo con otros User-Agent si el servidor rechaza la conexión; el error muestra la causa
- Mando: ↑/↓ cambian de canal, ←/→ saltan 10 s en películas, OK muestra los controles

> La app es solo un reproductor: no incluye canales ni listas.

## Conseguir el APK

1. Sustituye `proyecto.zip` de tu repositorio por este y sube el cambio (rama `main`).
2. En **Actions** espera a que termine "Build APK" (3-5 min).
3. Descarga `app-debug.apk` desde **Releases → IPTV Player (última versión)**.
